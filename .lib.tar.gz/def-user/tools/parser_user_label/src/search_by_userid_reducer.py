#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   zhukaiwen@baidu.com
#Date  :   19/05/14 13:56:38
import sys
reload(sys)
sys.setdefaultencoding("gbk")

if __name__ == "__main__":
    for eachline in sys.stdin:
        print eachline.strip("\n")
