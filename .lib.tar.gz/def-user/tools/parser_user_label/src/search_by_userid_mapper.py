#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   zhukaiwen@baidu.com
#Date  :   19/05/14 13:53:55
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import json

if __name__ == "__main__":
    for eachline in sys.stdin:
        line = eachline.strip("\n").split("\t")
        result = json.loads(line[0])
        userid = result["info"]["userid"]
        ulevel = result["info"]["ulevel"]
        url = result["info"]["url"]
        company = result["info"]["company"]
        register = result["info"]["register"]
        isztc = result["info"]["isztc"]
        uname = result["info"]["uname"]
        optids = result["info"]["optids"]
        opts = result["info"]["opts"]
        user_model_evidence = result["user_model_evidence"]
        ue = []
        for e in user_model_evidence:
            if len(user_model_evidence[e]) != 0:
                ue.append(",".join(user_model_evidence[e]))

        check_result = result["check_result"]
        for cr in check_result:
            model_id = str(cr["model_id"])
            model_name = cr["model_name"]
            model_type = str(cr["model_type"])
            mr = cr["model_result"]
            label_name = mr["label_name"]
            label_list = mr["label_list"]
            label = str(mr["label"])
            evidence = mr["evidence"]
            e = []
            if type(evidence) == type(u""):
                e.append(evidence)
            else:
                for item in evidence:
                    if type(evidence[item]) == type(""):
                        if len(evidence[item]) == 0:
                            continue
                        e.append(evidence[item])
                    elif type(evidence[item]) == type([]):
                        if len(evidence[item]) == 0:
                            continue
                        try:
                            e.append(",".join(evidence[item]))
                        except Exception as ee:
                            e.append(str(evidence[item]))
            r = [userid, ulevel, url, company, register, isztc, uname, optids,
                    opts, model_id, model_name, label, label_name, 
                    "|".join(e), "|".join(ue), str(label_list)]
            print "\t".join(r).encode("gbk", "ignore")
