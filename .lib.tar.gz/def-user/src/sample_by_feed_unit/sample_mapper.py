#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   19/07/05 16:28:19
Desc  :   ��Ԥ���������ϰ�unit����
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os

def main(user_set, ignore=False):
    """�����Ѵ������Ĵ������� ����keyֵΪunit������
    """
    for line in sys.stdin:
        parts = line.strip("\n").split("\t")
        if len(parts) != 8:
            continue
        userid = parts[0]
        if ignore == False and userid not in user_set:
            continue
        planid = parts[1]
        unitid = parts[2]
        text = parts[5]
        text_seg = parts[6]
        url = parts[7]
        # ���unitid, userid, planid, text, text_seg, url
        print("\t".join([unitid, userid, planid, text, text_seg, url]))


if __name__ == "__main__":
    ignore = True
    user_set = set()
    user_info_file = "data/user_info.txt"
    with open(user_info_file, "r") as f:
        for eachline in f:
            line = eachline.strip("\n").split("\t")
            userid = line[0]
            user_set.add(userid)
    main(user_set, ignore)
