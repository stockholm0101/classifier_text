#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   19/07/05 17:49:27
Desc  :   ����Ԫ����
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import common.sampler as sampler
import conf


def gen_sample(key, sample_dict):
    """���ݵ�ǰ������� ���ɸ�key�ĳ������
    """
    idea_sample_list = sample_dict.get_sample_list()

    # �����key�д����ؼ���Ϊ�� ������
    if len(idea_sample_list) == 0:
        return

    idea_list, idea_seg_list, idea_url_list = zip(*idea_sample_list)

    print("\t".join([key,
            "\x01".join(idea_list),
            "\x01".join(idea_seg_list),
            "\x01".join(idea_url_list)]))


if __name__ == "__main__":
    previous_key = None
    sample_dict = sampler.Sampler(conf.FEED_IDEA_SAMPLE_BY_UNIT_NUM)

    for line in sys.stdin:
        # ����unitid, userid, planid, text, text_seg, url
        parts = line.strip("\n").split("\t")
        # key: userid, planid, unitid
        key = "\t".join([parts[1], parts[2], parts[0]])
        if key != previous_key:
            if previous_key is not None:
                gen_sample(previous_key, sample_dict)
            sample_dict.clear()
            previous_key = key
        text = parts[3]
        text_seg = parts[4]
        url = parts[5]
        sample_dict.put((text, text_seg, url))

    if previous_key is not None:
        gen_sample(previous_key, sample_dict)
