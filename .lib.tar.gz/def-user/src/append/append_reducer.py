#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   19/11/06 17:42:59
Desc  :   
"""
import sys
import json

if __name__ == "__main__":
    old_key = ""
    old_info = {}
    check_result = []
    for eachline in sys.stdin:
        line = eachline.strip("\n").split("\t")
        key = line[0]
        json_data = json.loads(line[1])
        if old_key == "" or old_key == key:
            check_result += json_data.get("check_result", [])
        else:
            old_info["check_result"] = check_result
            print json.dumps(old_info)
            check_result = json_data.get("check_result", [])
        old_info = json_data
        old_key = key

    if old_key != "":
        old_info["check_result"] = check_result
        print json.dumps(old_info)
