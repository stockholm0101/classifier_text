#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   19/11/06 14:52:46
Desc  :   
"""
import sys
import os
import json

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import conf
import review_object.review_object as review_object

if __name__ == "__main__":
    data_type = int(sys.argv[1])
    if data_type == conf.MODEL_TYPE_AD:
        for eachline in sys.stdin:
            r_obj = review_object.ReviewAdObj()
            r_obj.init_from_json(eachline.strip("\n"))
            print "\t".join([r_obj.id, eachline.strip("\n")])
    elif data_type == conf.MODEL_TYPE_UNIT:
        for eachline in sys.stdin:
            r_obj = review_object.ReviewUnitObj()
            r_obj.init_from_json(eachline.strip("\n"))
            print "\t".join([r_obj.unitid, eachline.strip("\n")])
    elif data_type == conf.MODEL_TYPE_USER:
        for eachline in sys.stdin:
            r_obj = review_object.ReviewUserObj()
            r_obj.init_from_json(eachline.strip("\n"))
            print "\t".join([r_obj.userid, eachline.strip("\n")])
    elif data_type == conf.MODEL_TYPE_CLICK_AD:
        for eachline in sys.stdin:
            r_obj = review_object.ReviewClickAdObj()
            r_obj.init_from_json(eachline.strip("\n"))
            print "\t".join(["_".join([r_obj.winfoid, r_obj.ideaid, r_obj.text]), eachline.strip("\n")])
    elif data_type == conf.MODEL_TYPE_METEOR_AD:
        for eachline in sys.stdin:
            r_obj = review_object.ReviewMeteorAdObj()
            r_obj.init_from_json(eachline.strip("\n"))
            print "\t".join(["_".join([r_obj.id, r_obj.ad_type, r_obj.text]), eachline.strip("\n")])
    elif data_type == conf.MODEL_TYPE_CLICK_USER:
        for eachline in sys.stdin:
            r_obj = review_object.ReviewClickUserObj()
            r_obj.init_from_json(eachline.strip("\n"))
            print "\t".join([r_obj.userid, eachline.strip("\n")])
    elif data_type == conf.MODEL_TYPE_URL:
        for eachline in sys.stdin:
            r_obj = review_object.ReviewUrlObj()
            r_obj.init_from_json(eachline.strip("\n"))
            print "\t".join([r_obj.url, eachline.strip("\n")])
    elif data_type == conf.MODEL_TYPE_FEED_AD:
        for eachline in sys.stdin:
            r_obj = review_object.ReviewFeedAdObj()
            r_obj.init_from_json(eachline.strip("\n"))
            print "\t".join(["_".join([r_obj.winfoid, r_obj.ideaid, r_obj.text]), eachline.strip("\n")])
    elif data_type == conf.MODEL_TYPE_FEED_USER:
        for eachline in sys.stdin:
            r_obj = review_object.ReviewFeedUserObj()
            r_obj.init_from_json(eachline.strip("\n"))
            print "\t".join([r_obj.userid, eachline.strip("\n")])
    elif data_type == conf.MODEL_TYPE_FEED_IDEA_AD:
        for eachline in sys.stdin:
            r_obj = review_object.ReviewFeedIdeaAdObj()
            r_obj.init_from_json(eachline.strip("\n"))
            print "\t".join(["_".join([r_obj.userid, r_obj.unitid, r_obj.ideaid]), eachline.strip("\n")])
    elif data_type == conf.MODEL_TYPE_FEED_IDEA_UNIT:
        for eachline in sys.stdin:
            r_obj = review_object.ReviewFeedUnitObj()
            r_obj.init_from_json(eachline.strip("\n"))
            print "\t".join([r_obj.unitid, eachline.strip("\n")])
    elif data_type == conf.MODEL_TYPE_FEED_IDEA_USER:
        for eachline in sys.stdin:
            r_obj = review_object.ReviewFeedIdeaUserObj()
            r_obj.init_from_json(eachline.strip("\n"))
            print "\t".join([r_obj.userid, eachline.strip("\n")])
    elif data_type == conf.MODEL_TYPE_URL_MONITOR:
        for eachline in sys.stdin:
            r_obj = review_object.ReviewURLMonitorObj()
            r_obj.init_from_json(eachline.strip("\n"))
            # ͬһurl �����ǲ�ͬ�˻�����ͬʱ��� ��ǰҪ���ֿ�
            key = "\x01".join([r_obj.url, r_obj.userid, str(r_obj.timestamp)])
            print "\t".join([key, eachline.strip("\n")])
