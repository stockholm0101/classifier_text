#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/07/30 11:11:11
Desc  :   ���˻�����
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

def split_word_idea(text):
    """click����ĵ�����ݸ�ʽΪword,idea
    """
    split_text = text.split(",")
    word = split_text[0]
    idea = ",".join(split_text[1:])
    return word, idea


if __name__ == "__main__":
    word_dict = dict()
    idea_dict = dict()

    for line in sys.stdin:
        try:
            file_name = os.environ["mapreduce_map_input_file"] if "mapreduce_map_input_file" in \
                    os.environ else os.environ["map_input_file"]
            data_type = "click" if "click-processed" in file_name else "meteor"
        except:
            data_type = sys.argv[1]

        parts = line.strip("\n").split("\t")
        if len(parts) != 8:
            continue

        if data_type == "meteor":
            print "\t".join(parts[:2] + parts[-3:])
        elif data_type == "click":
            userid = parts[0]
            wordid = parts[3]
            ideaid = parts[4]
            word, idea = split_word_idea(parts[5])
            wordseg, ideaseg = split_word_idea(parts[6])
            url = parts[7]

            # �Ե�����ݰ��չؼ��ʡ�����ȥ��
            key1 = "\t".join([userid, wordid])
            if key1 not in word_dict:
                word_dict[key1] = [word, wordseg, url]
            key2 = "\t".join([userid, ideaid])
            if key2 not in idea_dict:
                idea_dict[key2] = [idea, ideaseg, url]

    for key1 in word_dict:
        print "\t".join([key1.split("\t")[0], "word"] + word_dict[key1])

    for key2 in idea_dict:
        print "\t".join([key2.split("\t")[0], "idea"] + idea_dict[key2])

