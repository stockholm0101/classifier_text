#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   19/07/08 14:12:57
Desc  :   ���˻�����
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import common.sampler as sampler
import conf

IDEA = "idea"
WORD = "word"

def split_by_col(data_list):
    """���ɶ�Ԫ����ɵ��б��ֳ������б�
    """
    f_list = list()
    s_list = list()
    t_list = list()
    for data in data_list:
        f_list.append(data[0])
        s_list.append(data[1])
        t_list.append(data[2])
    return f_list, s_list, t_list


def gen_sample(key, sample_dict):
    """���ݵ�ǰ������� ���ɸ�key�ĳ������
    """
    word_sample_list = sample_dict[WORD].get_sample_list()
    idea_sample_list = sample_dict[IDEA].get_sample_list()

    ## �����key�д����ؼ���Ϊ�� ������
    if len(word_sample_list) == 0 or len(idea_sample_list) == 0:
        return

    word_list, word_seg_list, word_url_list = split_by_col(word_sample_list)
    idea_list, idea_seg_list, idea_url_list = split_by_col(idea_sample_list)

    print("\t".join([key,
            "\x01".join(idea_list),
            "\x01".join(word_list),
            "\x01".join(idea_seg_list),
            "\x01".join(word_seg_list), 
            "\x01".join(idea_url_list), 
            "\x01".join(word_url_list)]))


if __name__ == "__main__":
    previous_key = None
    sample_dict = {
            WORD: sampler.Sampler(conf.WORD_SAMPLE_BY_CLICK_NUM),
            IDEA: sampler.Sampler(conf.IDEA_SAMPLE_BY_CLICK_NUM)}

    for line in sys.stdin:
        # ����userid, data_type, text, text_seg
        parts = line.strip("\n").split("\t")
        # key: userid
        key = parts[0]
        if key != previous_key:
            if previous_key is not None:
                gen_sample(previous_key, sample_dict)
            sample_dict[WORD].clear()
            sample_dict[IDEA].clear()
            previous_key = key
        data_type = parts[1]
        text = parts[2]
        text_seg = parts[3]
        url = parts[4]
        sample_dict[data_type].put((text, text_seg, url))

    if previous_key is not None:
        gen_sample(previous_key, sample_dict)
