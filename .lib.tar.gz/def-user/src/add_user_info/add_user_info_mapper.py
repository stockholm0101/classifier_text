#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/05/08 15:00:00
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.merge_object as merge_object

if __name__ == "__main__":
    for eachline in sys.stdin:
        try:
            file_name = os.environ["mapreduce_map_input_file"] if "mapreduce_map_input_file" in \
                    os.environ else os.environ["map_input_file"]
            # 1. Ԥ����Ϣ 2. �˻���ϸ��Ϣ
            which_file = "1"
            if "user_all_info" in file_name:
                which_file = "2"
        except:
            which_file = sys.argv[1]

        if which_file == "1":
            merge_obj = merge_object.MergeObj()
            merge_obj.init_from_json(eachline.strip())
            print "\t".join([merge_obj.userid, "1", eachline.strip()])
        elif which_file == "2":
            line = eachline.strip("\n").split("\t")
            userid = line[0]
            info = "\t".join(line)
            print "%s\t2\t%s" % (userid, info)
