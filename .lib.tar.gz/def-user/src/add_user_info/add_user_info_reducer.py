#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/05/08 15:00:00
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import json

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object
import review_object.merge_object as merge_object

if __name__ == "__main__":
    old_userid = None
    merge_obj = merge_object.MergeObj()
    for eachline in sys.stdin:
        line = eachline.strip("\n").split("\t")
        userid = line[0]
        which_file = line[1]
        if which_file == "1":
            json_str = line[2]
            merge_obj.init_from_json(json_str)
            old_userid = userid
        elif which_file == "2":
            user_info_obj = review_object.ReviewUserInfoObj()
            user_info_obj.init(line[2:])
            if user_info_obj.userid != old_userid:
                continue
            else:
                info = user_info_obj.get_user_info()
                merge_obj.info = dict(merge_obj.info, **info)
                print json.dumps(merge_obj.merge_result())

