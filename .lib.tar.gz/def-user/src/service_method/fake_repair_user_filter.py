# -*- coding:gbk -*-
#Author:   zhanghao55@baidu.com
#Date  : 2019/05/15 15:55:10
import sys
reload(sys)
sys.setdefaultencoding("gbk")


class FakeRepairUserFilter(object):
    """ά�޷�ð�û�����
    """
    def check(self, s_obj, service_conf):
        """ҵ����
        [in]  s_obj: �������Ķ���
              service_conf: ҵ������
        [out] check_result: True/False,�Ƿ񳬹�ά�޷�ð������ֵ
        """
        check_result = False

        user_info = s_obj.user_info
        user_status = user_info["info"]["ustatus"]
        user_isztc = user_info["info"]["isztc"]
        models_result = user_info["check_result"]

        model_id  = service_conf["model_id"]
        label_id  = service_conf["label_id"]
        brand_num_threshold = service_conf["brand_num_threshold"]
        risk_threshold = service_conf["risk_threshold"]

         # �����˻�״̬��ֱͨ��
        if (user_status not in ["2", "3"]) or (user_isztc == "1"):
            return check_result, model_id

        for model in models_result:
            if model["model_id"] == model_id:
                if model["model_result"]["label"] == label_id:
                    try:
                        brand_num = model["model_result"]["evidence"]["brand_detected_num"]
                        risk_ratio = model["model_result"]["evidence"]["max_risk_ratio"]
                    except:
                        brand_num = 0
                        risk_ratio = 0.0
                    if  brand_num >= brand_num_threshold and risk_ratio >= risk_threshold:
                        check_result = True
        return check_result, model_id


if __name__ == "__main__":
    pass

