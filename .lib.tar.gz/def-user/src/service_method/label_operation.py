#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/10/17 16:12:59
Desc  :   ��ģ�ͱ�ǩ���ҵ�����,֧�ֱ�ǩ�����ƺͷ�����
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")

class LabelOperation(object):
    """��ǩ���ҵ����
    """
    def __init__(self):
        """init
        [in]  data/opt_conf.txt, һЩ����id����, ��������
        """
        self.opt_conf = self.load_opt_conf("data/opt_conf.txt")

    def load_opt_conf(self, file_name):
        """����data/opt_conf.txt
        [in]  file_name
        [out] opt_conf: <key, value> - <opttype, optid set>
        """
        opt_conf = {}
        with open(file_name, "r") as f:
            for eachline in f:
                if eachline.startswith("#"):
                    continue
                line = eachline.strip("\n").decode("gb18030", "ignore").split("\t")
                opttype = line[0]
                optid = line[1]
                if opttype not in opt_conf:
                    opt_conf[opttype] = set()
                opt_conf[opttype].add(optid)
        return opt_conf

    def check(self, s_obj, service_conf):
        """ҵ����
        [in]  s_obj: �������Ķ���
              service_conf: ҵ������
        [out] check_result: True/False,�Ƿ񴥷�ҵ���߼�
        """
        check_result = False

        user_info = s_obj.user_info
        user_status = user_info["info"]["ustatus"]
        user_isztc = user_info["info"]["isztc"]
        user_ulevel = user_info["info"]["ulevel"]
        user_register = user_info["info"]["register"]
        user_optids = set(user_info["info"]["optids"].split("||"))
        user_mainids = set(user_info["info"]["main_lice_ids"].split("||"))
        user_consume = float(user_info["info"]["consume"])
        user_product = user_info["info"]["product"]
        user_agent = set([user_info["info"]["agent"]])
        user_agent_type = set([user_info["info"]["agent_type"]])
        models_result = user_info["check_result"]

        # ��ǩ���
        intersection = service_conf.get("intersection", {})
        difference = service_conf.get("difference", {})
        opt_intersection = set(service_conf.get("opt_intersection", "").split("|")) - set([""])
        opt_difference = set(service_conf.get("opt_difference", "").split("|")) - set([""])
        main_intersection = set(service_conf.get("main_intersection", "").split("|")) - set([""])
        main_difference = set(service_conf.get("main_difference", "").split("|")) - set([""])
        opttype_intersection = set(service_conf.get("opttype_intersection", "").split("|")) - set([""])
        opttype_difference = set(service_conf.get("opttype_difference", "").split("|")) - set([""])
        agent_type_intersection = set(service_conf.get("agent_type_intersection", "").split("|")) - set([""])
        agent_type_difference = set(service_conf.get("agent_type_difference", "").split("|")) - set([""])

        for opttype in opttype_intersection:
            opt_intersection |= self.opt_conf.get(opttype, set())
        for opttype in opttype_difference:
            opt_difference |= self.opt_conf.get(opttype, set())

        # ��ģ��id��label id
        model_id = service_conf["model_id"]
        label_id  = service_conf["label_id"]
        label_ids = label_id.split("|")

        # ��ģ��id�뽻��ģ��id�ļ���
        model_id_dict = dict()
        model_id_dict[model_id] = False
        for m_id in intersection:
            model_id_dict[m_id] = False

        # ������������
        # 1. �����˻�״̬��ֱͨ��
        service_id = service_conf['service_id'][:-4]
        if service_id == "10011614": #�����йܿ�ȫ����Ч�˻�
            if (user_status in ["4"]) or (user_isztc == "1"):
                return check_result, model_id
        else:
            if (user_status not in ["2", "3"]) or (user_isztc == "1"):
                return check_result, model_id

        # 2. ���ƴ���С�ͻ�
        if "limit_ulevel" in service_conf and service_conf["limit_ulevel"] != user_ulevel:
            return check_result, model_id

        # 3. ����ע��ʱ��
        if "limit_time" in service_conf and user_register <= service_conf["limit_time"]:
            return check_result, model_id

        # x. ��������
        if "limit_consume" in service_conf and user_consume < service_conf["limit_consume"]:
            return check_result, model_id

        # x. ���Ʋ�Ʒ��
        if "limit_product" in service_conf and len(set(service_conf["limit_product"].split("|")) & \
                set(user_product.split("|"))) == 0:
            return check_result, model_id

        # 4. ��ǩ���; �������ģ��Ϊ��,��ʾ��ģ�����м�ΪTrue
        for model in models_result:
            m_id = model["model_id"]
            model_label_set= set(model["model_result"]["label"].split("|"))

            # model result�б�������ģ���Լ�����ģ��
            if m_id in model_id_dict:
                model_id_dict[m_id] = True

            # ��ģ��δ���У�����False
            if m_id == model_id and len(model_label_set & set(label_ids)) == 0:
                return check_result, model_id

            # ����δ���У�����False
            if m_id in intersection and len(model_label_set & set(intersection[m_id].split("|"))) == 0:
                return check_result, model_id

            # ���������У�����False
            if m_id in difference and len(model_label_set & set(difference[m_id].split("|"))) != 0:
                return check_result, model_id

            # ���ƿ�ѡ����δ����, ����False
            if len(opt_intersection) > 0 and len(opt_intersection & user_optids) == 0:
                return check_result, model_id

            # ���޿�ѡ��������, ����False
            if len(opt_difference & user_optids) > 0:
                return check_result, model_id

            # ������������δ����, ����False
            if len(main_intersection) > 0 and len(main_intersection & user_mainids) == 0:
                return check_result, model_id

            # ����������������, ����False
            if len(main_difference & user_mainids) > 0:
                return check_result, model_id

            # ���ƴ���������δ����, ����False
            if len(agent_type_intersection) > 0 and len(agent_type_intersection & user_agent_type) == 0:
                return check_result, model_id

            # ���޴�������������, ����False
            if len(agent_type_difference & user_agent_type) > 0:
                return check_result, model_id

        # 5. ��������
        check_result = True
        for m_id in model_id_dict:
            check_result &= model_id_dict[m_id]
        return check_result, model_id


if __name__ == "__main__":
    import os
    _cur_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.append("%s/../" % _cur_dir)

    import review_object.service_object as service_object

    service_conf = {"enable": True,
        "model_id": 10,
        "label_id": "3|6",
        "intersection": {3012: "2"},
        "difference": {},
        "limit_ulevel": "10101"
        }

    # ģ��10δ���в�����棬����False
    s_obj = service_object.ServiceResultObj()
    s_obj.user_info = {"userid": "1", 
            "info": {"optids": "1", "ustatus": "2", "isztc": "0", "ulevel": "10101", "register": "2000-01-01 00:00:00", \
                    "main_lice_ids": "", "consume": "1", "product": "", "agent": "", "agent_type": ""}, 
            "check_result": [{"model_id": 10, "model_result": {"label": "1"}}, \
                    {"model_id": 3012, "model_result": {"label": "2"}}], "user_model_evidence": {}}

    lo = LabelOperation()
    check_result, model_id = lo.check(s_obj, service_conf)
    assert not check_result

    # ģ��10�ǲ�����棬��ģ��3012���ҳ������˾��,����False
    s_obj.user_info = {"userid": "1", 
            "info": {"optids": "1", "ustatus": "2", "isztc": "0", "ulevel": "10101", "register": "2000-01-01 00:00:00", \
                    "main_lice_ids": "", "consume": "1", "product": "", "agent": "", "agent_type": ""}, 
            "check_result": [{"model_id": 10, "model_result": {"label": "6"}}, \
                    {"model_id": 3012, "model_result": {"label": "0"}}], "user_model_evidence": {}}

    lo = LabelOperation()
    check_result, model_id = lo.check(s_obj, service_conf)
    assert not check_result

    # ģ��10�ǲ�����棬ģ��3012���ҳ��������˾��, ���ڲ�У�����False
    service_conf["difference"] = {28: "1"}
    s_obj.user_info = {"userid": "1", 
            "info": {"optids": "1", "ustatus": "2", "isztc": "0", "ulevel": "10101", "register": "2000-01-01 00:00:00", \
                    "main_lice_ids": "", "consume": "1", "product": "", "agent": "", "agent_type": ""}, 
            "check_result": [{"model_id": 10, "model_result": {"label": "6"}}, \
                    {"model_id": 3012, "model_result": {"label": "2"}}, \
                    {"model_id": 28, "model_result": {"label": "1"}}], "user_model_evidence": {}}

    lo = LabelOperation()
    check_result, model_id = lo.check(s_obj, service_conf)
    assert not check_result

    # ģ��10�ǲ�����棬����Ϊ�գ�����True
    service_conf["intersection"] = {}
    s_obj.user_info = {"userid": "1", 
            "info": {"optids": "1", "ustatus": "2", "isztc": "0", "ulevel": "10101", "register": "2000-01-01 00:00:00", \
                    "main_lice_ids": "", "consume": "1", "product": "", "agent": "", "agent_type": ""}, 
            "check_result": [{"model_id": 10, "model_result": {"label": "6"}}, \
                    {"model_id": 3012, "model_result": {"label": "2"}}], "user_model_evidence": {}}

    lo = LabelOperation()
    check_result, model_id = lo.check(s_obj, service_conf)
    assert check_result

    # ģ��10�ǲ�����棬ģ��3012���ҳ��������˾��, ���ڲ�У�����True
    service_conf["intersection"] = {3012: "2"}
    service_conf["difference"] = {}
    s_obj.user_info = {"userid": "1", 
            "info": {"optids": "1", "ustatus": "2", "isztc": "0", "ulevel": "10101", "register": "2000-01-01 00:00:00", \
                    "main_lice_ids": "", "consume": "1", "product": "", "agent": "", "agent_type": ""}, 
            "check_result": [{"model_id": 10, "model_result": {"label": "6"}}, \
                    {"model_id": 3012, "model_result": {"label": "2"}}], "user_model_evidence": {}}

    lo = LabelOperation()
    check_result, model_id = lo.check(s_obj, service_conf)
    assert check_result

    # ģ��10�ǲ�����棬����model 3012������user info��û��3012ģ�ͣ�����False
    s_obj.user_info = {"userid": "1", 
            "info": {"optids": "1", "ustatus": "2", "isztc": "0", "ulevel": "10101", "register": "2000-01-01 00:00:00", \
                    "main_lice_ids": "", "consume": "1", "product": "", "agent": "", "agent_type": ""}, 
            "check_result": [{"model_id": 10, "model_result": {"label": "6"}}, \
                    {"model_id": 3013, "model_result": {"label": "2"}}], "user_model_evidence": {}}

    lo = LabelOperation()
    check_result, model_id = lo.check(s_obj, service_conf)
    assert not check_result

    service_conf = {"enable": True,
        "model_id": 33,
        "label_id": "1",
        "difference": {23: "7|37"},
        }

    # ģ��33��������� ģ��23���û���Ӫ��Χ ģ��33Ԥ��Ϊ�鱦��Ʒ ��ģ��23Ԥ��ľ�Ӫ��Χ��û���鱦��Ʒ������True
    s_obj.user_info = {"userid": "1", 
            "info": {"optids": "1", "ustatus": "2", "isztc": "0", "ulevel": "10101", "register": "2000-01-01 00:00:00", \
                    "main_lice_ids": "", "consume": "1", "product": "", "agent": "", "agent_type": ""}, 
            "check_result": [{"model_id": 33, "model_result": {"label": "1"}}, \
                    {"model_id": 23, "model_result": {"label": "2|29|55"}}], "user_model_evidence": {}}

    lo = LabelOperation()
    check_result, model_id = lo.check(s_obj, service_conf)
    assert check_result

    # ģ��33��������� ģ��23���û���Ӫ��Χ ģ��33Ԥ��Ϊ�鱦��Ʒ ģ��23Ԥ��ľ�Ӫ��Χ�����鱦��Ʒ������False
    s_obj.user_info = {"userid": "1", 
            "info": {"optids": "1", "ustatus": "2", "isztc": "0", "ulevel": "10101", "register": "2000-01-01 00:00:00", \
                    "main_lice_ids": "", "consume": "1", "product": "", "agent": "", "agent_type": ""}, 
            "check_result": [{"model_id": 33, "model_result": {"label": "1"}}, \
                    {"model_id": 23, "model_result": {"label": "2|29|37|55"}}], "user_model_evidence": {}}

    lo = LabelOperation()
    check_result, model_id = lo.check(s_obj, service_conf)
    assert not check_result

    # model 110203100100 ���������ͷ��޲���
    service_conf = {"enable": True,
        "model_id": "110203100100",
        "label_id": "1",
        "difference": {},
        "agent_type_difference": "KA"
        }

    s_obj = service_object.ServiceResultObj()
    s_obj.user_info = {"userid": "1", 
            "info": {"optids": "1", "ustatus": "2", "isztc": "0", "ulevel": "10101", "register": "2000-01-01 00:00:00", \
                    "main_lice_ids": "", "consume": "1", "product": "", "agent": "", "agent_type": ""}, 
            "check_result": [{"model_id": "110203100100", "model_result": {"label": "1"}}, \
                    {"model_id": 3012, "model_result": {"label": "2"}}], "user_model_evidence": {}}

    lo = LabelOperation()
    check_result, model_id = lo.check(s_obj, service_conf)
    assert check_result

    s_obj.user_info["info"]["agent_type"] = "KA"
    lo = LabelOperation()
    check_result, model_id = lo.check(s_obj, service_conf)
    assert not check_result
