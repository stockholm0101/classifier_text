#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   zhubenchang@baidu.com
#Date  :   19/04/28 16:37:19
import sys
reload(sys)
sys.setdefaultencoding("gbk")


class Risk_user(object):
    """ֱ��ʶ��Ϊ��Σ�˻�
    """
    def check(self, s_obj, service_conf):
        """ҵ����
        [in]  s_obj: �������Ķ���
              service_conf: ҵ������
        [out] check_result: True/False,�Ƿ񴥷��Ĳ��߼�
        """
        check_result = False

        user_info = s_obj.user_info
        user_status = user_info["info"]["ustatus"]
        user_isztc = user_info["info"]["isztc"]
        models_result = user_info["check_result"]

        model_label_dict  = service_conf["model_label_dict"]
        model_id = list(model_label_dict.keys())[0]

        # �˻�״̬��ֱͨ��ɸѡ
        if (user_status not in ["2", "3"]) or (user_isztc == "1"):
            return check_result, model_id

        for model in models_result:
            if model["model_id"] in model_label_dict:
                if model["model_result"]["label"] in \
                        model_label_dict[model["model_id"]].split("|") or \
                        model["model_result"]["evidence"].get("additional", {}).get("label", "") in \
                        model_label_dict[model["model_id"]].split("|"):
                    check_result = True
                    model_id = model["model_id"]

        return check_result, model_id


if __name__ == "__main__":
    import os
    _cur_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.append("%s/../" % _cur_dir)

    import review_object.service_object as service_object
    import conf

    s_obj = service_object.ServiceResultObj()
    s_obj.user_info = {"userid": "1", 
            "info": {"optids": "1", "ustatus": "2", "isztc": "0"}, 
            "check_result": [{"model_id": 2001, "model_result": {"label": "3"}}], 
            "user_model_evidence": {}}
    s_obj.check_result = []

    mq = Risk_user()
    assert not mq.check(s_obj, conf.service[12])

    s_obj.user_info = {"userid": "1", 
            "info": {"optids": " 1001", "ustatus": "2", "isztc": "0"}, 
            "check_result": [{"model_id": 18, "model_result": {"label": "1"}}], 
            "user_model_evidence": {}}

    assert mq.check(s_obj, conf.service[10])

