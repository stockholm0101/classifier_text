#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   19/07/22 22:38:07
Desc  :   
"""

import sys
reload(sys)
sys.setdefaultencoding("gbk")

class MedicalQualification(object):
    """ҽ��������ҵ����
    """
    def check(self, s_obj, service_conf):
        """ҵ����
        [in]  s_obj: �������Ķ���
              service_conf: ҵ������
        [out] check_result: True/False,�Ƿ񴥷��������߼�
        """
        check_result = False

        user_info = s_obj.user_info
        user_optids = user_info["info"]["optids"]
        user_status = user_info["info"]["ustatus"]
        user_isztc = user_info["info"]["isztc"]
        models_result = user_info["check_result"]

        model_id  = service_conf["model_id"]
        label_opt_dict = service_conf["label_opt_dict"]
        white_label = service_conf.get("white_label", {})
        label_need_opts = {}
        for k in label_opt_dict:
            ks = k.split("|")
            opts = set(label_opt_dict[k].split("|"))
            for label in ks:
                label_need_opts[label] = opts

        # �˻�״̬��ֱͨ��ɸѡ
        if (user_status not in ["2", "3"]) or (user_isztc == "1"):
            return check_result, model_id

        for model in models_result:
            m_id = model["model_id"]
            # ����Ƿ�Ӱ�, �������е�label��label_list��
            if m_id in white_label:
                labels = set(white_label[m_id].split("|"))
                for item in model["model_result"]["label_list"]:
                    if item[0] in labels:
                        check_result = False
                        return check_result, model_id

            if m_id != model_id or model["model_result"]["label"] not in label_need_opts:
                continue
            opts_need = label_need_opts[model["model_result"]["label"]]
            if len(set(user_optids.split("||")) & opts_need) == 0:
                check_result = True

        return check_result, model_id


if __name__ == "__main__":
    import os
    _cur_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.append("%s/../" % _cur_dir)

    import review_object.service_object as service_object
    import conf

    s_obj = service_object.ServiceResultObj()
    s_obj.user_info = {"userid": "1", 
            "info": {"optids": "1", "ustatus": "2", "isztc": "0"}, 
            "check_result": [{"model_id": 7, "model_result": {"label": "5001"}}], 
            "user_model_evidence": {}}
    s_obj.check_result = []

    mq = MedicalQualification()
    check_result, model_id = mq.check(s_obj, conf.service[27])
    assert not check_result

    s_obj.user_info = {"userid": "1", 
            "info": {"optids": " 1001", "ustatus": "2", "isztc": "0"}, 
            "check_result": [{"model_id": 7, "model_result": {"label": "8001"}}, 
                {"model_id": 27, "model_result": {"label_list": [["1", "", 0]]}}], 
            "user_model_evidence": {}}

    check_result, model_id = mq.check(s_obj, conf.service[27])
    assert not check_result

    s_obj.user_info = {"userid": "1", 
            "info": {"optids": " 1001", "ustatus": "2", "isztc": "0"}, 
            "check_result": [{"model_id": 7, "model_result": {"label": "8001"}}, 
                {"model_id": 27, "model_result": {"label_list": [["2", "", 0]]}}], 
            "user_model_evidence": {}}

    check_result, model_id = mq.check(s_obj, conf.service[26])
    assert check_result
