#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   zhuxiaodong01@baidu.com
#Date  :   19/04/28 16:37:19
import sys
reload(sys)
sys.setdefaultencoding("gbk")

class Qualification(object):
    """������ҵ����
    """
    def check(self, s_obj, service_conf):
        """ҵ����
        [in]  s_obj: �������Ķ���
              service_conf: ҵ������
        [out] check_result: True/False,�Ƿ񴥷��������߼�
        """
        check_result = False

        user_info = s_obj.user_info
        user_optids = user_info["info"]["optids"]
        user_status = user_info["info"]["ustatus"]
        user_isztc = user_info["info"]["isztc"]
        models_result = user_info["check_result"]

        model_id  = service_conf["model_id"]
        label_id  = service_conf["label_id"]
        label_ids = label_id.split("|")
        opt_need  = service_conf["opt_need"]
        white_label = service_conf.get("white_label", {})

        # �˻�״̬��ֱͨ��ɸѡ
        if (user_status not in ["2", "3"]) or (user_isztc == "1"):
            return check_result, model_id

        # �Ƿ����ע��ʱ������
        if "time_limit" in service_conf:
            time_limit = service_conf["time_limit"]
            user_register = user_info["info"]["register"]
            if user_register <= time_limit:
                return check_result, model_id

        for model in models_result:
            m_id = model["model_id"]
            if m_id in white_label:
                labels = set(white_label[m_id].split("|"))
                if model["model_result"]["label"] in labels:
                    check_result = False
                    return check_result, model_id

            if m_id != model_id or (model["model_result"]["label"] not in label_ids and model["model_result"]["evidence"].get("additional", {}).get("label", "") not in label_ids):
                continue

            if len(set(user_optids.split("||")) & set(opt_need.split("|"))) == 0:
                check_result = True

        return check_result, model_id


if __name__ == "__main__":
    pass

