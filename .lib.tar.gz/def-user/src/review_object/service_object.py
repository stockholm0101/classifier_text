#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   zhuxiaodong01@baidu.com
#Date  :   19/05/06 16:22:52
import sys
reload(sys)
sys.setdefaultencoding("gbk")

import json

class ServiceResultObj(object):
    """Base Class
    """
    def __init__(self):
        """init"""
        pass

    def init(self, line):
        """����û���Ϣ
        """
        self.user_info = json.loads(line)
        self.check_result = []

    def add_result(self, service_conf_info, check_result, model_id):
        """���ܸ�ģ�ͽ��, �ӵ�check_result��
        [in]  service_conf_info: ģ������
        [out] None
        """
        result = {}
        result["service_id"] = service_conf_info["service_id"]
        result["service_type"] = service_conf_info["service_type"]
        result["service_name"] = service_conf_info["service_name"]
        result["model_id"] = model_id
        result["is_hit"] = check_result
        self.check_result.append(result)

    def service_result(self):
        """�����û��ڸ���ҵ�����˽��
        """
        return {"userid": self.user_info["userid"],
                "info": self.user_info["info"],
                "check_result": self.user_info["check_result"],
                "user_model_evidence": self.user_info["user_model_evidence"],
                "service_result": self.check_result
            }
