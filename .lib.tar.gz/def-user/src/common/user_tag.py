#!/usr/bin/env python
# -*- coding: gbk -*-
 
"""
Author:   zhanghao55@baidu.com
Date  :   19/07/09 20:09:55
DESC  :   �û���ҵ��Ϣ��
"""

import singleton
import codecs


class UserTag(singleton.Singleton):
    """�û���ҵ��Ϣ��
    """
    _is_init = False
    def __init__(self, user_tag_path="data/user_tag.txt"):
        """�����û���Ϣ�ļ���ַ��ʼ��
        """
        if not self._is_init:
            self._user_tag_dict = self.load_user_tag(user_tag_path)
            self._is_init = True

    def get(self, key, default_value):
        """���ֵ��getһ��
        """
        return self._user_tag_dict.get(key, default_value)

    def load_user_tag(self, user_tag_path):
        """�����û�����ҵ��Ϣ 
        �����ƺͷ���ʱ��ҵ�����Ŷ�Ҫ��һ��, ��˷�������ҵset�洢
        Return:
            �û���ҵ�ʵ�
            user_tag_dict[userid] = (res_tag_set, exp_tag_set)
        """
        user_tag_dict = dict()
        with codecs.open(user_tag_path, "r", "gb18030") as rf:
            for line in rf:
                parts = line.strip("\n").split("\t")
                userid = parts[0]
                tag = parts[1]
                confidence = float(parts[2])
                if userid not in user_tag_dict:
                    user_tag_dict[userid] = (set(), set())
                res_tag_set, exp_tag_set = user_tag_dict[userid]
                res_tag_set.add(tag)
                if confidence >= 0.95:
                    exp_tag_set.add(tag)
        return user_tag_dict


if __name__ == "__main__":
    import psutil
    import time
    import os
    pid = os.getpid()
    p = psutil.Process(pid)
    def getMemInfo(info):
        """չʾ��ǰ�ڴ�ʹ�����
        """
        memory = p.memory_full_info().uss / float(1024 ** 2)
        print("[MEM = %.2fMB]:%s" % (memory, info.encode("gb18030", "ignoree")))

    getMemInfo("initial")
    start_time = time.time()
    test1 = UserTag()
    getMemInfo("test1 finish")
    print("cost time = %.4fs" % (time.time() - start_time))
    start_time = time.time()
    test2 = UserTag()
    getMemInfo("test2 finish")
    print("cost time = %.4fs" % (time.time() - start_time))
    print("test1 id = %s" % id(test1))
    print("test2 id = %s" % id(test2))
    print("test1 size = %d" % len(test1._user_tag_dict))
    print("test2 size = %d" % len(test2._user_tag_dict))
