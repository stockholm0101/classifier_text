#!/usr/bin/env python
# -*- coding: gbk -*-
########################################################################
# 
# Copyright (c) 2019 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: xgboost_model_tool.py
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2019/12/27 12:01:51
"""

import sys
import re
import numpy as np
import math

class load_predcit(object):
    """xgboost load model and predict
    """
    def __init__(self, model_file, model_feature_file, class_nums, iter_num):
        """
        [in]:
            model_file xgboost ģ���ļ�
            model_feature_file xgboost ģ�������ļ�
            class_nums ģ�����
            iter_num ģ��ѵ����������
        [out]:
            None
        """
        self.model_file = model_file
        self.model_feature_file = model_feature_file
        self.class_nums = class_nums
        self.iter_num = iter_num
        self.one_tree_start = "booster"
        self.one_node_contain = "missing"
        self.one_leaf_contain = "leaf"
        self.sign_of_operation = {}
        self.sign_of_operation['<'] = ""
        self.sign_of_operation['>'] = ""
        self.sign_of_operation['>='] = ""
        self.sign_of_operation['<='] = ""
        self.load_model(self.model_file, self.class_nums, self.iter_num)
        self._load_model_featrue(self.model_feature_file)
    
    def _load_model_featrue(self, model_feature_file):
        """����ģ������
        [in]:
            model_feature_file ģ�������ļ� 
        [out]:
            None
        """
        self.word_dict = {}
        with open(model_feature_file) as f:
            for line in f:
                one = line.strip("\n").decode("gbk").split("\t")
                one = filter(None,one)
                if len(one) == 2:
                    self.word_dict[one[0]] = int(one[1])

    def get_sentence_vec(self, sentence):
        """ ���ı�����ӳ��Ϊ����
        [in]:
            sentence �ı�����
        [out]:
            vec ��������
        """
        vec={}
        for word in sentence:
            site = self.word_dict.get(word, None)
            if site is None:
                continue
            vec[site] = 1.0
        return vec
    
    def _count_prob(self, score_list):
        """����������ĸ���ֵ
        [in]:
            score_list ����ع�ֵ�б�
        [out]:
            pro_dist ÿ���Ӧ�ĸ���ֵ
        """
        pro_list = []
        score_list = np.array(score_list)
        max_val = max(score_list)
        score_list = score_list - max_val
        exp_list = np.exp(score_list)

        esum = np.sum(exp_list)
        for score in exp_list:
            pro_list.append(score / esum)
        return np.array(pro_list)

    def _parse_one_node(self, str_one_node):
        """����xgboost���ķ�Ҷ�ӽڵ�
        [in]:
            str_one_node ��Ҷ�ӽڵ��ַ���
        [out]:
            a list ��Ҷ�ӽڵ����Ϣ
        """
        str_one_node = str_one_node.strip("\t")
        site_nodeid = str_one_node.find(':')
        node_id = int(str_one_node[0:site_nodeid])
    
        site_condition = str_one_node.find(']', site_nodeid + 2)
        str_condition = str_one_node[site_nodeid + 2 : site_condition]
        condition = '<'; #default <
        for sop, sop_code in self.sign_of_operation.items():
            if str_one_node.find(sop) >= 0 :
                condition = sop
                break

        str_condition = str_condition.replace('f', '')
        feat_id , condition_num = str_condition.split(condition)
        feat_id = int(feat_id)
        condition_num = float(condition_num)

        site_yes_left = str_one_node.find('yes=')
        site_yes_right = str_one_node.find(',', site_yes_left)
        if site_yes_right < 0:
            site_yes_right = len(str_one_node)
        yes = int(str_one_node[site_yes_left+4 : site_yes_right])

        site_no_left = str_one_node.find('no=')
        site_no_right = str_one_node.find(',', site_no_left)
        if site_no_right < 0:
            site_no_right = len(str_one_node)
        no = int(str_one_node[site_no_left+3 : site_no_right])

        site_missing_left = str_one_node.find('missing=')
        site_missing_right = str_one_node.find(',', site_missing_left)
        if site_missing_right < 0:
            site_missing_right = len(str_one_node)
        missing = int(str_one_node[site_missing_left + 8 : site_missing_right])
        return [node_id, feat_id, condition, condition_num, yes, no, missing]

    def _parse_one_leaf(self, str_leaf):
        """����xgboost����Ҷ�ӽڵ�
        [in]:
            str_leaf Ҷ�ӽڵ��ַ���
        [out]:
            a list Ҷ�ӽڵ����Ϣ
        """
        str_one_leaf = str_leaf.strip("\t")
        site_nodeid = str_one_leaf.find(':')
        node_id = int(str_one_leaf[0:site_nodeid])
    
        leaf_left = str_one_leaf.find('leaf=')
        leaf_right = str_one_leaf.find(',', leaf_left)
        if leaf_right < 0:
            leaf_right = len(str_one_leaf)
        leaf = float(str_one_leaf[leaf_left+5 : leaf_right])
        return [node_id, leaf]

    def load_model(self, xgboost_model_path, numclass, num_iter):
        """����xgboostģ��
        [in]:
            xgboost_model_path ģ��·���ļ�
            numclass ģ�ͷּ���
            num_iter ģ��ѵ����������
        [out]:
            None
        """
        one_tree_class = 0
        xgboost = []
        model = {}
        with open(xgboost_model_path) as f:
            for line in f:
                one = line.strip("\n").strip().strip("\t")
                if one.find(self.one_tree_start) >= 0:
                    tree_id_left = one.find('[')
                    tree_id_right = one.find(']')
                    tree_id = int(one[tree_id_left+1 : tree_id_right])
                    one_tree_class = tree_id % numclass 
                    if model:
                        xgboost.append(model)
                        model = {}
                    model["tree_info"] = one_tree_class
                    continue
                if one.find(self.one_node_contain) >= 0:
                    node_id, feat_id, condition, condition_num, yes, no, missing = self._parse_one_node(one)
                    model[node_id] = [feat_id, condition, condition_num, yes, no, missing]
                    continue

                if one.find(self.one_leaf_contain) >= 0:
                    node_id, leaf = self._parse_one_leaf(one)
                    model[node_id] = [leaf]
        xgboost.append(model)
        self.xgboost = xgboost

    def _tree_op(self, condition, condition_num, fea):
        """xgboost ���ڵ�����
        [in]:
            condition ��������
            condition_num ����ֵ
            fea ����ֵ
        [out]:
            ����Ϊ��ture, ����Ϊ��false
        """
        swith ={
                '<':fea < condition_num,
                '>':fea > condition_num,
                '>=':fea >= condition_num,
                '<=':fea <= condition_num
                }
        return swith[condition]

    def _predict_one_model(self, model, featrue):
        """xgboost ��������Ԥ��
        [in]:
            model һ����
            featrue ����
        [out]:
            Ԥ��ֵ
        """
        node_id = 0
        node_info = model.get(node_id, None)

        while node_info is not None and len(node_info) == 6:
            fea = featrue.get(node_info[0], None)
            if fea is not None:
                condition = node_info[1]
                condition_num = node_info[2]
                if self._tree_op(condition, condition_num, fea):
                    node_id = node_info[3]
                else:
                    node_id = node_info[4]
                node_info = model.get(node_id, None)
                continue
            else:
                node_id = node_info[5]
                node_info = model.get(node_id, None)
        if len(node_info) == 1:
            return node_info[0]
        return 0.0

    def _pre_one_class(self, xgboost, featrue, class_num):
        """��ĳ�������Ԥ��
        [in]:
            xgboost ģ��
            class_num ҪԤ���ĳһ��
        [out]:
            Ԥ��ֵ
        """
        sum_leaf = 0.0
        for model in xgboost:
            if model['tree_info'] == class_num:
                sum_leaf += self._predict_one_model(model, featrue)
        return sum_leaf

    def xgboost_predict(self, featrue):
        """ģ����Ԥ��
        [in]:
            featrue ��Ԥ��������ֵ�
        [out]:
            pro ÿ�����Ԥ��ֵ
        """
        xgboost = self.xgboost
        class_nums = self.class_nums
        pro = []
        for class_num in range(class_nums):
            pro.append(self._pre_one_class(xgboost, featrue, class_num))

        if class_nums == 1:
            pro[0] = 1/(1+math.exp(-pro[0]))
            return np.array(pro)
        pro = self._count_prob(pro)
        return pro

if __name__ == "__main__":
    pass 
