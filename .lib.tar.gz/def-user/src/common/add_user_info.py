#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
Author: zhubenchang@baidu.com
Date  : 2020/06/09 13:31:12
DESC  : �ϲ��˻���ϸ��Ϣ
"""

import sys
import os
import codecs
import argparse


class UserInfo():
    """�˻���Ϣ
    """
    def __init__(self, ucid_ztcid_path, opt_lice_path, main_lice_path, user_consume_path, \
            user_agent_path, all_user_path, user_all_info_path):
        """init
        """
        self.ucid_ztcid_path = ucid_ztcid_path
        self.opt_lice_path = opt_lice_path
        self.main_lice_path = main_lice_path
        self.user_consume_path = user_consume_path
        self.user_agent_path = user_agent_path
        self.all_user_path = all_user_path
        self.user_all_info_path = user_all_info_path

    def load_set(self, data_path, encoding="gb18030"):
        """ֻ�������Ʊ����ָ��ĵ�һ��
        """
        res = set()
        with codecs.open(data_path, "r", encoding) as rf:
            for line in rf:
                res.add(line.strip("\n").split("\t")[0])
        return res
    
    def load_dict(self, data_path, process_func, indexs, encoding="gb18030"):
        """�����ֵ� ֻ�ʺ�kֻ����һ�ε�ʱ�� k���ֶ�� ��v�ᱻ����
        """
        res = dict()
        with codecs.open(data_path, "r", encoding) as rf:
            for line in rf:
                k, v = process_func(line, indexs)
                res[k] = v
        return res

    def combine_on_indexs(self, line, indexs):
        """����ָ������Ϲ���
        """
        parts = line.strip("\n").split("\t")
        userid = parts[0]
        try:
            values_list = [parts[index] for index in indexs]
        except Exception as e:
            values_list = []
            sys.stderr.write("index %s is out of range 0-%d\n" % (str(indexs), len(line) - 1))
        return userid, "\t".join(values_list)

    def init(self):
        """load ���˻���Ϣ
        """
        # ����ֱͨ���˻���Ϣ
        self.ztc_user_set = self.load_set(self.ucid_ztcid_path)

        # �����˻���ѡ������Ϣ
        self.opt_lice_dict = self.load_dict(self.opt_lice_path, self.combine_on_indexs, [3, 4])

        # �����˻�����������Ϣ
        self.main_lice_dict = self.load_dict(self.main_lice_path, self.combine_on_indexs, [3, 4])

        # �����˻�������Ϣ
        self.user_consume_dict = self.load_dict(self.user_consume_path, self.combine_on_indexs, [1])

        #���ش�������Ϣ
        self.agent_user_dict = self.load_dict(self.user_agent_path, self.combine_on_indexs, [3, 4])

    def combine_userinfo(self):
        """�ϲ��˻���Ϣ
        """
        with codecs.open(self.all_user_path, "r", "gb18030") as rf, \
                codecs.open(self.user_all_info_path, "w", "gb18030") as wf:
            for line in rf:
                line = line.strip("\n")
                userid = line.split("\t")[0]
                # �ж��˻��Ƿ���ֱͨ���˻� 1����
                user_type = "1" if userid in self.ztc_user_set else "0"
                # ���ӿ�ѡ������Ϣ
                opt_lice_info = self.opt_lice_dict.get(userid, "NULL\tNULL")
                # ��������������Ϣ
                main_lice_info = self.main_lice_dict.get(userid, "NULL\tNULL")
                # ����������Ϣ
                consume_info = self.user_consume_dict.get(userid, "0.0")
                # ���Ӵ�������Ϣ
                agent_info = self.agent_user_dict.get(userid, "NULL\tNULL")

                wf.write("\t".join([line, user_type, opt_lice_info, main_lice_info, consume_info, agent_info]) + "\n")


def test():
    """���ز���
    """
    test_file_dic = {
            "ucid_ztcid_path": "data/ucid_ztcid.txt",
            "opt_lice_path": "data/all_user_optlice_eff_trade_eff.result",
            "main_lice_path": "data/all_user_mainlice_eff_trade_eff.result",
            "user_consume_path": "data/user_consume.txt",
            "user_agent_path": "data/user_agent.txt",
            "all_user_path": "data/alluser.txt",
            "user_all_info_path": "output/test_user_all_info.txt"
        }
    userinfo = UserInfo(test_file_dic["ucid_ztcid_path"], test_file_dic["opt_lice_path"], \
            test_file_dic["main_lice_path"], test_file_dic["user_consume_path"], \
            test_file_dic["user_agent_path"], test_file_dic["all_user_path"], \
            test_file_dic["user_all_info_path"])
    userinfo.init()
    userinfo.combine_userinfo()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description = "conbine user info")
    parser.add_argument("--ztc", action = "store", required = "True", help = "ֱͨ���˻��ļ���ַ", default = "None")
    parser.add_argument("--opt", action = "store", required = "True", help = "�˻������ļ���ַ", default = "None")
    parser.add_argument("--mainlice", action = "store", required = "True", help = "���������ļ���ַ", default = "None")
    parser.add_argument("--consume", action = "store", required = "True", help = "�˻������ļ���ַ", default = "None")
    parser.add_argument("--agent", action = "store", required = "True", help = "�˻��������ļ���ַ", default = "None")
    parser.add_argument("--alluser", action = "store", required = "True", help = "ȫ���˻��ļ���ַ", default = "None")
    parser.add_argument("--result_file", action = "store", required = "True", help = "����ļ���ַ", default = "None")

    args = parser.parse_args()

    ucid_ztcid_path = args.ztc
    opt_lice_path = args.opt
    main_lice_path = args.mainlice
    user_consume_path = args.consume
    user_agent_path = args.agent
    all_user_path= args.alluser
    user_all_info_path = args.result_file

    userinfo = UserInfo(ucid_ztcid_path, opt_lice_path, main_lice_path, \
            user_consume_path, user_agent_path, all_user_path, user_all_info_path)
    userinfo.init()
    userinfo.combine_userinfo()
    #test()
