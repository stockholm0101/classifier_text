#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   yemin02@baidu.com
Date  :   20/09/11 15:30:01
Desc  :   URL����/վ����� 
"""
import sys
import os
import sys

class GetDomain():
    """
    ����/վ�������
    """
    def __init__(self, tlds_path):
        # �������������ļ�
        tlds = set()
        f = open(tlds_path)
        for line in f:
            if line[0] not in "/\n":
                tlds.add(line.strip())
        self.tlds = tlds

    def validIP(self, elements):
        """validIP
        """
        if len(elements) != 4:
            return False
        for item in elements:
            if not 0 <= int(item) <= 255:
                return False
        return True
    
    def get_domain(self, netloc):
        """get_domain
        """
        url_elements = netloc.split(':')[0].split('.')
    
        for i in range(-len(url_elements), 0): 
            last_i_elements = url_elements[i:]
            candidate = ".".join(last_i_elements) 
            wildcard_candidate = ".".join(["*"] + last_i_elements[1:])
            exception_candidate = "!" + candidate
    
            # match tlds:-
            if (exception_candidate in self.tlds):
                return ".".join(url_elements[i:])
            if (candidate in self.tlds or wildcard_candidate in self.tlds):
                return ".".join(url_elements[i - 1:])
        
        if self.validIP(url_elements):
            return ".".join(url_elements)
        raise ValueError("Domain (%s) not in global list of TLDs" % netloc)
    
    
    def get_domain2(self, url):
        """get_domain2, ��������
        """
        url = url.strip()
        domain = ''
        try:
            if url.startswith("http://"):
                url = url[7:]
            if url.startswith("https://"):
                url = url[8:]
            if url.find('/') != -1:
                url = url.split('/', 1)[0]
            if url.find('?') != -1:
                url = url.split('?', 1)[0]
            if url.find('#') != -1:
                url = url.split('#', 1)[0]
            domain = self.get_domain(url)
        except ValueError as e:
            pass
        except IndexError as e:
            pass
        return domain
            
    
    def get_site(self, url):
        """get_site, ����վ��
        """
        url = url.strip()
        site = ''
        try:
            head = ''
            if url.startswith("http://"):
                head = url[:7]
                url = url[7:]
            if url.startswith("https://"):
                head = url[0:8]
                url = url[8:]
            if url.find('/') != -1:
                url = url.split('/', 1)[0]
            if url.find('?') != -1:
                url = url.split('?', 1)[0]
            if url.find('#') != -1:
                url = url.split('#', 1)[0]
            #site = "".join((head, url))
            site = url
        except ValueError as e:
            pass
        except IndexError as e:
            pass
        return site
    
    
if __name__ == "__main__":
    c_get_domain = GetDomain('./model/model_lp/effective_tld_names.dat')
    url = "http://bd.xinghuacun-fenjiu.cn/fqgh5/fenj-m/"
    domain = c_get_domain.get_domain2(url.strip())
    site = c_get_domain.get_site(url.strip())
    print domain
    print site
