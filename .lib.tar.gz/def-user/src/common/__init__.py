#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   19/04/29 17:08:16
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")

if __name__ == "__main__":
    pass


