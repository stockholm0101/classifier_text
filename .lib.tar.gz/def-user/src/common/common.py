#!/usr/bin/env python
# -*- coding:gb18030 -*-
#Author:   zhukaiwen@baidu.com
#Date  :   19/04/29 17:08:34
import sys
import os
import math
import random
import re
import numpy as np
import paddle.fluid as fluid
#import paddle.v2 as paddle
import urllib
import datetime
import subprocess
import json
import string
import collections
import requests
import tld

class Common(object):
    """һЩ���õķ���,����LR��CNNģ�ͻ�����������
    """
    @staticmethod
    def load_word_file(file_name):
        """
        [in]  file_name: str, �ļ���
        [out] word: set, Сд, unicode
        """
        word = set()
        with open(file_name, "r") as f:
            for eachline in f:
                line = eachline.lower().decode("gb18030", "ignore").strip("\n")
                word.add(line)
        return word

    @staticmethod
    def load_vocab(file_name):
        """CNNģ�͵Ĵʵ�
        [in]  file_name: str, �ļ���
        [out] vocab: dict, unicode
        """
        vocab = {}
        with open(file_name) as f:
            wid = 0
            for line in f:
                vocab[line.strip().decode("gb18030", "ignore")] = wid
                wid += 1
        vocab['<unk>'] = len(vocab)
        return vocab

    @staticmethod
    def load_send_user(user_path, max_send_day=30):
        """����send_id���������û�
        [in]  user_path: str, �������û��ĵ�ַ
        [out] user_done: dict, user_done[risk_type][userid] = set(push_time)
              user_today_send: dict, user_today_send[risk_type][userid] = 0. db, 1. new
        """
        user_done = collections.defaultdict(lambda: collections.defaultdict(set))
        user_today_send = collections.defaultdict(dict)
        with open(user_path) as f:
            for line in f:
                line = line.strip("\n")
                cols = line.split("\t")
                productid = cols[0]
                userid    = cols[1]
                isviolate = cols[2]
                source    = cols[3]
                type_id   = int(cols[4])
                send_day  = cols[5]
                timestr = datetime.datetime.strptime(send_day, '%Y-%m-%d %H:%M:%S')
                timenow = datetime.datetime.now()

                tdelta_days = (timenow - timestr).days
                if tdelta_days <= max_send_day:
                    user_done[type_id][userid].add(timestr.strftime("%Y-%m-%d"))

                push_time = timestr.strftime("%Y-%m-%d")
                now_time = timenow.strftime("%Y-%m-%d")
                if push_time == now_time:
                    user_today_send[type_id][userid] = 0

        return user_done, user_today_send

    @staticmethod
    def load_tuoguan_send_user(user_path, max_send_day=7):
        """�����йܵ��������û�
        [in]  user_path: str, �������û��ĵ�ַ
        [out] user_done: dict, user_done[risk_type][userid] = set(push_time)
              user_today_send: dict, user_today_send[risk_type][userid] = 0. db, 1. new
        """
        user_done = collections.defaultdict(lambda: collections.defaultdict(set))
        user_today_send = collections.defaultdict(dict)
        with open(user_path) as f:
            for line in f:
                line = line.strip("\n")
                cols = line.split("\t")
                userid       = cols[0]
                model_name   = cols[1] 
                service_id   = cols[2]
                send_day     = cols[-1] #ת'2020-08-21 12:00:00'
                timestr = datetime.datetime.strptime(send_day, '%Y-%m-%d %H:%M:%S')
                timenow = datetime.datetime.now()
                tdelta_days = (timenow - timestr).days
                if tdelta_days <= max_send_day:
                    user_done[service_id][userid].add(timestr.strftime("%Y-%m-%d"))
                
                push_time = timestr.strftime("%Y-%m-%d")
                now_time = timenow.strftime("%Y-%m-%d")
                if push_time == now_time:
                    user_today_send[service_id][userid] = 0
        return user_done, user_today_send


    @staticmethod
    def load_white_user(white_user_path):
        """���ؼӰ��˻�
        [in]  white_user_path: str, �Ӱ��˻����Ӱ���������
        [out] white_users: dict, white_users[service_id+userid/company] = type
        type: 1 �Ӱ��˻� 2 �Ӱ�����
        """
        white_users = dict()
        with open(white_user_path, "r") as f:
            for line in f:
                line = line.strip("\n").decode("gb18030", "ignore")
                cols = line.split("\t")
                service_id = cols[0]
                obj_type   = cols[1]
                obj_text   = cols[2]
                white_users[service_id + obj_text] = obj_type
        return white_users

    @staticmethod
    def load_user_screen(user_screen_path):
        """���ؼ��ƽ̨�˻�
        [in]  user_screen_path: str, ���ƽ̨��ͼ�˻�
        [out] screen_users: dict, screen_users[userid] = url_evidence
        """
        screen_users = dict()
        if not os.path.exists(user_screen_path):
            return screen_users

        with open(user_screen_path, "r") as f:
            for line in f:
                line = line.strip("\n").decode("gb18030", "ignore")
                cols = line.split("\t")
                session_id = cols[0]
                try:
                    task_id = session_id.split("_")[1]
                except Exception as e:
                    task_id = "none"
                userid   = cols[1]
                screen_users[userid] = "http://10.138.37.243:8080/url_monitor_show/?task_id=%s" % (task_id)
        return screen_users

    @staticmethod
    def add_send_user(user_path, send_id, userid):
        """�������ͳɹ����˻����ļ�
        [in]  user_path: str, �������û��ĵ�ַ
              send_id: int, �ɹ������û�������id
              userid, str, �ɹ����͵�userid
        [out] None
        """
        push_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(user_path, 'a') as f:
            f.write("%d\t%s\t%s\n" % (send_id, userid, push_time))

    @staticmethod
    def load_multiclass_lr_model_file(file_name):
        """
        [in]  file_name: str, ģ���ļ���
        [out] model_dict: dict, str(label) -> list[����]
              model_feature_num: int, ģ��������
        """
        label_list = []
        model_dict = {}
        with open(file_name, "r") as f:
            line_num = 0
            for eachline in f:
                line_num += 1
                if line_num == 3:
                    for item in eachline.strip().split(" ")[1:]:
                        model_dict[item] = []
                        label_list.append(item)
                if line_num <= 6:
                    continue
                line = eachline.strip().split(" ")
                if len(label_list) > 2:
                    for i in range(0, len(label_list)):
                        key = label_list[i]
                        model_dict[key].append(float(line[i]))
                else:
                    key = label_list[0]
                    model_dict[key].append(float(line[0]))
                    key = label_list[1]
                    model_dict[key].append(-1.0 * float(line[0]))
        model_feature_num = line_num - 6
        return model_dict, model_feature_num

    @staticmethod
    def load_class_id_file(file_name):
        """
        [in]  file_name: str, ������id�ļ�, ����, class_id, class_name
        [out] class_dict: dict, str(class_id) -> str(class_name)
        """
        class_dict = {}
        with open(file_name, "r") as f:
            for eachline in f:
                parts = eachline.strip().decode("gb18030", "ignore").split("\t")
                class_id = parts[0]
                class_name = parts[1]
                assert class_id not in class_dict, \
                        "class_id duplicate in class id file: %s, previous name = %s, cur name = %s" \
                        % (class_id, class_dict[class_id], class_name)
                class_dict[class_id] = class_name
        return class_dict

    @staticmethod
    def load_class_thres(file_name):
        """
        [in]  file_name: str, ������id�ļ�, ����������, class_id, class_name, [thres]
        [out] class_thres: dict, str(class_id) -> float(thres)
        ���Ϊ���У���ʾ��class_id��Ҫ������ֵ
        """
        class_thres = {}
        with open(file_name, "r") as f:
            for eachline in f:
                parts = eachline.strip().decode("gb18030", "ignore").split("\t")
                if len(parts) == 3:
                    class_thres[parts[0]] = float(parts[2])
        return class_thres

    @staticmethod
    def load_class_name_thres(file_name):
        """��ȡclass_id, class_name, class_threshold ����
        """
        class_name_threshold = {}
        with open(file_name, "r") as f:
            for eachline in f:
                parts = eachline.strip().decode("gb18030", "ignore").split("\t")
                if len(parts) == 3:
                    class_name_threshold[int(parts[0])] = [parts[1], float(parts[2])]
        return class_name_threshold

    @staticmethod
    def load_feature_id_file(file_name):
        """
        [in]  file_name: str, ����id�ļ���, featureid \t word ...
        [out] feature_dict: dict, str(word) -> featureid
        """
        feature_dict = {}
        with open(file_name, "r") as f:
            for eachline in f:
                line = eachline.strip("\n").decode("gb18030", "ignore").split("\t")
                fid = line[0]
                fword = line[1]
                assert fword not in feature_dict, \
                        "feature duplicate in feature id file: %s, previous id = %s, cur id = %s" \
                        % (fword, feature_dict[fword], fid)
                feature_dict[fword] = int(fid)
        return feature_dict

    @staticmethod
    def ngram(seg_list, n=5):
        """
        [in]  seg_list: �кôʵ�list
        [out] ngram: set, ��seg_list����ngram
        """
        word_num = len(seg_list)
        ngram = set()
        for i in range(0, word_num):
            ngram.add(seg_list[i])
            for j in range(1, n):
                if i + j > word_num:
                    break
                ngram.add("".join(seg_list[i: i + j]))
        return ngram

    @staticmethod
    def ngram_feature_text(word_segger, text, stopword):
        """
        [in]  word_segger: �д�
              text: ���дʵ��ı�
              stopword: ͣ�ôʼ���
        [out] ngram: �д�, ngram��ļ���
        """
        ngram = set()
        t = text.encode("gb18030", "ignore")
        if len(t.strip()) < 1:
            return
        t_seg = word_segger.seg_words(t) # gb18030

        skip_stopword = []
        for x in t_seg:
            if x in stopword:
                ngram |= Common.ngram(skip_stopword)
                skip_stopword = []
                continue
            skip_stopword.append(x)
        if len(skip_stopword) > 0:
            ngram |= Common.ngram(skip_stopword)

        ngram_unicode = set()
        for w in ngram:
            ngram_unicode.add(w.decode("gb18030", "ignore"))
        return ngram_unicode

    @staticmethod
    def ngram_feature(seg, stopword):
        """
        [in]  seg: list, �������Ĵ�(���к�, ��Ҫ����ngram)
              stopword: ͣ�ôʼ���
        [out] ngram: ngram��Ľ��
        """
        ngram = set()
        skip_stopword = []
        for x in seg:
            if x in stopword:
                ngram |= Common.ngram(skip_stopword)
                skip_stopword = []
                continue
            skip_stopword.append(x)
        if len(skip_stopword) > 0:
            ngram |= Common.ngram(skip_stopword)
        return ngram

    @staticmethod
    def cross_ngram_feature(token_list, stopword, 
            ngram=3, feature_min_length=2, duplicate=False):
        """�����б�����ngram��������ngram_feature�����������ǣ��ú�����Խ��stopword����ngram
        [in]  token_list: list[str], �����б�, unicode����
              stopword: set(str), ͣ�ôʼ���
              ngram: int, ngram��С
              feature_min_length: int, ������С����
              duplicate: bool, true�����ɵ�������ȥ��
        [out] features: list[str], �����б�, unicode����
        """
        feature_list = list()
        # ȥ��ͣ�ô�
        valid_token_list = [x for x in token_list if len(x.strip()) != 0 and x not in stopword]
        # ����ngram����
        for start_pos in range(len(valid_token_list)):
            cur_feature = ""
            for offset in range(min(len(valid_token_list)-start_pos, ngram)):
                cur_feature += valid_token_list[start_pos + offset]
                if len(cur_feature) >= feature_min_length:
                    feature_list.append(cur_feature)
        if duplicate:
            return feature_list
        else:
            return set(feature_list)

    @staticmethod
    def cal_multiclass_lr_predict(model_dict, model_feature_num, feature_dict, 
            class_dict, hit_feature):
        """��������Ԥ����, ����Ԥ��ֵ����0.03�Ľ��list, ÿ��Ԫ��[id, name, val]
        [in]  model_dict: ģ�Ͳ���
              model_feature_num: ģ��������
              feature_dict: ����
              class_dict: ����
              hit_feature: ���е�����
        [out] label_list: Ԥ����
        """
        predict_label = {}
        total = 0.0
        for k in model_dict:
            predict_label[k] = 0.0
            value = 0.0
            for w in hit_feature:
                fid = feature_dict[w]
                if fid > model_feature_num:
                    continue
                w = model_dict[k][fid - 1]
                value += -1.0 * w
            predict_label[k] += 1.0 / (1.0 + math.exp(value))
            total += predict_label[k]

        label_list = []
        for k, v in sorted(predict_label.items(), key = lambda d: d[1], reverse = True):
            val = "%.4f" % (v / total)
            if float(val) < 0.03:
                continue
            label_list.append([k, class_dict[k], val])
        return label_list

    @staticmethod
    def cal_multiclass_lr_predict_otherway(model_dict, model_feature_num, feature_dict, class_dict, hit_feature):
        """��������Ԥ����, ����Ԥ��ֵ���list, ÿ��Ԫ��[id, name, val]
        [in]  model_dict: ģ�Ͳ���
              model_feature_num: ģ��������
              feature_dict: ����
              class_dict: ����
              hit_feature: ���е�����
        [out] label_list: Ԥ����
        """
        predict_label = {}
        for k in model_dict:
            predict_label[k] = 0.0
            value = 0.0
            for w in hit_feature:
                fid = feature_dict[w]
                if fid > model_feature_num:
                    continue
                w = model_dict[k][fid - 1]
                value += -1.0 * w
            predict_label[k] += 1.0 / (1.0 + math.exp(value))
        label_list = []
        for k, v in sorted(predict_label.items(), key = lambda d: d[1], reverse = True):
            val = "%.4f" % (v)
            label_list.append([k, class_dict[k], val])
        return label_list

    @staticmethod
    def sample_list(word_list, deep=3):
        """��ˮ���㷨��list������Ĭ�����Ϊ3
        [in]  word_list: �����б�
              deep: ����������Ĭ��Ϊ3
        [out] word_sample_list: ��������б�
        """
        word_sample_list = []
        count = 0
        for word in word_list:
            if len(word_sample_list) < deep:
                word_sample_list.append(word)
            else:
                index = random.randint(0, count)
                if index < deep:
                    word_sample_list[index] = word
            count += 1
        return word_sample_list

    @staticmethod
    def process_list(word_list, stopword, del_stopword=True, del_nc=True):
        """ȥ���б��е�ͣ�ôʡ�������
        [in]  word_list: �дʺ���ı��б�
              stopword: set,ͣ�ôʼ���
              del_stopword: �Ƿ�ȥ��ͣ�ôʣ�Ĭ��True
              del_nc: �Ƿ�ȥ�������ģ�Ĭ��True
        [out] plist: ��������ı��б�
        """
        plist = word_list
        if del_stopword:
            plist = filter(lambda x:x not in stopword, word_list)
        if del_nc:
            chinese = re.compile(ur'^[\u4e00-\u9fa5]+$')
            plist = filter(lambda x:chinese.search(x), plist)
        return plist

    @staticmethod
    def data2tensor(data, place):
        """
        data2tensor
        """
        seq_lens = [len(seq) for seq in data]
        cur_len = 0
        lod = [cur_len]
        for l in seq_lens:
            cur_len += l
            lod.append(cur_len)
        flattened_data = np.concatenate(data, axis=0).astype("int64")
        flattened_data = flattened_data.reshape([len(flattened_data), 1])
        tensor_sequence = fluid.LoDTensor()
        tensor_sequence.set(flattened_data, place)
        tensor_sequence.set_lod([lod])
        return {"words": tensor_sequence}

    @staticmethod
    def data_map(word_list, vocab):
        """
        Convert word sequence into slot
        """
        unk_id = len(vocab)
        wids = [vocab[x] if x in vocab else unk_id
                        for x in word_list]
        return wids

    @staticmethod
    def combine_model_evidence(model_evidence):
        """�ϲ���Ԫ/�û��㼶��֤�ݷ��㴫��ƽ̨
        [in]  model_evidence: dict, { key1: val1,
                                      key2: val2,
                                      ...}
        [out] evidence_content: str, �ϲ���json��ʽ�ַ���
        """
        if model_evidence.get("additional", ""):
            model_evidence = model_evidence.get("additional")
        evidence_content = json.dumps(model_evidence, ensure_ascii=False, indent=4)
        return evidence_content

    @staticmethod
    def shell_execute(cmd_str):
        """ִ��shell������
        [in]  cmd_str: str, ������
        [out] ִ�н��
        """
        return subprocess.call(cmd_str, shell=True)

    @staticmethod
    def cal_timedelta(time_str, ret_type='days'):
        """����ʱ���
        [in] time_str: str
             ret_type: str����������('days, hours, minutes, seconds')
        [out] ����ʱ���
        """
        try:
            timestr = datetime.datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S')
            timenow = datetime.datetime.now()
            tdelta = timenow - timestr
            return getattr(tdelta, ret_type)
        except:
            return None
        return None

    @staticmethod
    def text_normalize(text):
        """��һ���ı�
        [in]  text: str, δ�������ı�
        [out] ���ع�һ�����ı�
        """
        text = urllib.unquote(text.lower())
        text = text.replace("\t", " ").replace("\n", " ").replace("\r", " ").replace("\x01", " ").replace("\x02", " ")
        return text

    @staticmethod
    def text_has_escape_string(text):
        """�ж��ַ������Ƿ���ת���ַ�
        """
        escape_list = ["\\", "\'", "\"", "\a", "\b", "\e", \
                       "\n", "\v", "\t", "\r", "\f"]
        for escape in escape_list:
            if escape in text:
                return True
        return False

    @staticmethod
    def load_business_scope_label(file_name):
        """���ؾ�Ӫ��Χ��ǩ
        [in]  file_name: ��Ӫ��Χ��ǩ�ļ���ַ
        [out] �����˻���Ӧ��Ӫ��Χ�ı�ǩ�ֵ�
        """
        user_business_scope_label = {}
        with open(file_name, "r") as f:
            for line in f:
                parts = line.strip("\n").split("\t")
                userid = parts[0]
                label_ids = parts[1]
                user_business_scope_label[userid] = label_ids

        return user_business_scope_label

    @staticmethod
    def check_material_empty(userid):
        """��֤userid�Ƿ�Ϊ�գ���Ϊ�շ���True
        """
        # userid����Ч�ؼ��ʺʹ�����������ɵ��ļ�����
        suffix = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(30))
        cmd_str = "echo %s > userid.txt && sh read_from_db.sh -i userid.txt -t -e -o %s" % (userid, suffix)
        Common.shell_execute(cmd_str)

        word_file = suffix + "/word_info.txt"
        idea_file = suffix + "/idea_info.txt"
        wordsize = os.path.getsize(word_file)
        ideasize = os.path.getsize(idea_file)

        # ɾ�������ļ�
        cmd_str = "rm -r userid.txt %s;" % suffix
        Common.shell_execute(cmd_str)
        if wordsize == 0 and ideasize == 0:
            return True

        return False

    @staticmethod
    def is_online_mapred():
        """�ж��Ƿ���ִ��mapred
        """
        ret = True
        try:
            file_name = os.environ["mapreduce_map_input_file"] if "mapreduce_map_input_file" in \
                    os.environ else os.environ["map_input_file"]
        except:
            ret = False
        return ret

    @staticmethod
    def get_online_opt(userid):
        """ʵʱ��ȡ�����ļ�
        """
        tradeid = set()
        tradename = set()
        post_dict = dict()
        online_url = "http://innerzizhi.baidu.com/custpermit/api/getlicetradeinfobyucidbatch"
        post_dict["product_id"] = 142
        post_dict["auth_key"] = "93413d9ba6fa1e5eb9049ae9835036ac"
        post_dict["ucids"] = str(userid)
        post_dict["ismain"] = 0
        post_dict["show_type"] = 1
        post_dict["show_trade_name"] = 1
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(online_url, post_dict, headers=headers)
        ret_dict = json.loads(response.text)
        if "data" not in ret_dict:
            return "NULL", "NULL"
        for opt_info in ret_dict["data"]:
            if opt_info["status"] in set(["2", "6"]):
                tradeid.add(opt_info["tradeid"])
                tradename.add(opt_info["tradename"])
        return "||".join(list(tradeid)), "||".join(list(tradename))

    @staticmethod
    def get_domain(url):
        """��ȡurl����
        [in]  url: str, δ������url, �� http://www.baidu.com/index.html
        [out] ����url������, �磺baidu.com
        """
        mod_url = url if url.startswith("http") else "http://" + url
        try:
            return tld.get_fld(mod_url)
        except tld.exceptions.TldDomainNotFound as e:
            return "/".join(mod_url.split("/")[0:3])
        except ValueError as e:
            return "/".join(mod_url.split("/")[0:3])

    @staticmethod
    def get_subdomain(url):
        """��ȡվ��
        [in] url:str, δ������url, ��http://www.123.baidu.com/index.html
        [out]����url��վ��, �磺www.123.baidu.com
        """
        mod_url = url if url.startswith("http") else "http://" + url
        subdomain = []
        try:
            res = tld.get_tld(mod_url, as_object=True)
            if res.subdomain:
                subdomain.append(res.subdomain)
            if res.fld:
                subdomain.append(res.fld)
            return ".".join(subdomain)
        except tld.exceptions.TldDomainNotFound as e:
            return "/".join(mod_url.split("/")[0:3])
        except ValueError as e:
            return "/".join(mod_url.split("/")[0:3])


class LpLrPredict(object):
    """ LRģ��Ԥ����.
    """
    def __init__(self, model_filename_path):
        """
        Args:
            model_filename_path : ģ���ļ�����·��.
        Returns:
            null
        """
        self.word_weight_list = []
        self.model_bias_list = []
        self.index_map_label = {}
        self.load_model_weight(model_filename_path)

    def load_model_weight(self, filename):
        """ ����ģ��Ȩ�ز���.
        Args:
            filename : id.weight.word�ļ�����·��.
        Returns:
            null
        """
        self.word_weight_list = []
        self.model_bais_list  = []
        with open(filename, 'r') as f:
            for line in f:
                line = line.strip("\n")
                cols = line.split("\t")
                if len(cols) == 1:
                    label_list = line.split(" ")
                    for index, label in enumerate(label_list):
                        self.index_map_label[index] = label
                    continue
                if len(cols) != 3:
                    continue
                id = cols[0]
                weight_list = cols[1].split("|")
                weight_list = map(lambda x: float(x), weight_list)
                word = cols[2].decode("gb18030", "ignore")
                if (id == "-1") and (word.split(";")[-1] == "bias"):
                    bias_list = weight_list
                    for bias in bias_list:
                        self.model_bias_list.append(bias)
                        self.word_weight_list.append({})
                    continue
                if (int(id) >= 0):
                    for class_id, weight in enumerate(weight_list):
                        self.word_weight_list[class_id][word] = weight

    def softmax(self, score_list):
        """ softmax.
        Args:
            score_list : ��ͬ����Ȩֵ.
        Returns:
            pro_dist : ���ʷֲ�.
        """
        pro_dist = []
        esum = 0.0
        for score in score_list:
            esum += math.exp(score)
        for score in score_list:
            score = math.exp(score)
            pro_dist.append(score / esum)
        return np.array(pro_dist)

    def predict(self, segwords):
        """ Ԥ�⺯��.
        Args:
            segwords : ����Ƭ�Σ�����Ϊunicode���.
            real_label : ��ʵ���.
        Returns:
            result_dict : Ԥ�����ֵ䣬���������ֶ�(unicode���):
                          Ԥ����ꣻ
                          ����������
        """
        result_dict = {}
        hit_list = []
        score_list = []
        for bias in self.model_bias_list:
            score_list.append(bias)
            hit_list.append([])
        for segword in set(segwords):
            for dict_index in range(len(self.word_weight_list)):
                if segword in self.word_weight_list[dict_index]:
                    score_list[dict_index] += self.word_weight_list[dict_index].get(segword)
                    weight = self.word_weight_list[dict_index].get(segword)
                    hit_list[dict_index].append(":".join([segword, str(weight)]))
        predict_pro = self.softmax(score_list)
        predict_index = np.argmax(predict_pro)
        predict_label = self.index_map_label[predict_index]
        result_dict = {
                "predict_pro": predict_pro, \
                "predict_label": predict_label, \
                "hit_features": hit_list[predict_index]
                }
        return result_dict, predict_index

