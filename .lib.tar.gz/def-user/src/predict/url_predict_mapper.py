#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/05/13 20:00:22
Desc  :   
"""
import os
import sys
import json

UNKNOWN = "0"
URL_CRAWL_RES = "1"
URL_WITH_EVIDENCE = "2"


def url_crawl_res_processor(line):
    """ץȡ��� ȡurl
    """
    try:
        res_obj = json.loads(line)
    except ValueError as e:
        return None
    url = res_obj["url"]
    return "\t".join([url, URL_CRAWL_RES, line])


def url_with_evidence_processor(line):
    """URLץȡʱ������֤����Ϣ
    """
    try:
        obj = json.loads(line)
    except ValueError as e:
        return None
    url = obj["url"]
    return "\t".join([url, URL_WITH_EVIDENCE, line])


def error(line):
    """����None
    """
    return None


def main():
    """�����
    """
    data_type = UNKNOWN
    try:
        file_name = os.environ["mapreduce_map_input_file"] if "mapreduce_map_input_file" in \
                os.environ else os.environ["map_input_file"]
        if "url_crawl_res" in file_name:
            data_type = URL_CRAWL_RES
        if "latest_crawled_url" in file_name:
            data_type = URL_WITH_EVIDENCE
    except Exception as e:
        if len(sys.argv) > 1:
            data_type = sys.argv[1]

    processor_dict = {
            URL_CRAWL_RES: url_crawl_res_processor,
            URL_WITH_EVIDENCE: url_with_evidence_processor,
            UNKNOWN: error,
            }

    cur_processor = processor_dict[data_type]

    for line in sys.stdin:
        line = line.strip("\n").decode("gb18030")
        data = cur_processor(line)
        if data is not None:
            print(data.encode("gb18030"))


if __name__ == "__main__":
    main()
