#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   19/02/21 02:03:26
Desc  :   Ԥ��
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import re
import math
import random
import json

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import word_seg
import conf

import common.common as common
import review_object.review_object as review_object

class Predicter(object):
    """Ԥ����, ��ʼ��ģ��, ����ģ��Ԥ��ӿ�
    """
    def __init__(self):
        """init"""
        pass

    def init(self, data_type, user_info_file, stopword_file, segdict_path):
        """��ʼ��ģ��
        [in]  data_type: 1, ad_info; 2, unit_info; 3, user_info
              user_info_file: �û���Ϣ�ļ�
              stopword_file: ͣ�ô��ļ�
              segdict_path: �дʴʵ�
        [out] None
        """
        self.stopword = common.Common.load_word_file(stopword_file)
        self.word_segger = word_seg.WordSeg(segdict_path)
        self.word_segger.init_wordseg_handle()

        # import models
        self.model_obj = {}
        for k in conf.models:
            model = conf.models[k]
            if not model["enable"] or data_type not in model["model_type"]:
                continue
            self.model_obj[k] = {}
            self.model_obj[k]["conf_model_info"] = model
            m_module = __import__(model["module_name"],fromlist = ['default'])
            m_class = getattr(m_module, model["class_name"])
            m_obj = m_class()
            self.model_obj[k]["obj"] = m_obj

        # init models
        self.init_models()

    def init_models(self):
        """���ε���ģ�ͳ�ʼ���ӿ�
        """
        for k in self.model_obj:
            model = self.model_obj[k]
            model_dir = model["conf_model_info"]["model_dir"]
            # ���ø�ģ�ͳ�ʼ���ӿ�
            model["obj"].init(self.word_segger, self.stopword, model_dir)

    def destroy(self):
        """
        �ͷ��д�
        """
        self.word_segger.destroy_wordseg_handle()


if __name__ == "__main__":
    segdict_path = "dict/chinese_gbk"
    user_info_file = "data/user_info.txt"
    stopword_file = "data/stopword.txt"

    #############local
    #segdict_path = "/home/users/zhukaiwen/util_dir/word_seg_dict/chinese_gbk"
    #user_info_file = "data/user_info.txt"
    #stopword_file = "data/stopword.txt"
    #############

    #############local
    #segdict_path = "/home/users/zhuxiaodong01/tool_set/chinese_gbk"
    #user_info_file = "data/user_info.txt"
    #stopword_file = "data/stopword.txt"
    #############
    data_type = int(sys.argv[1])

    p = Predicter()
    p.init(data_type, user_info_file, stopword_file, segdict_path)
    for eachline in sys.stdin:
        line = eachline.strip("\n").lower().decode("gbk", "ignore").split("\t")
        r_obj = None
        if data_type == conf.MODEL_TYPE_AD:
            r_obj_type = None
            try:
                file_name = os.environ["mapreduce_map_input_file"] if "mapreduce_map_input_file" in \
                        os.environ else os.environ["map_input_file"]
                if "idea-processed" in file_name:
                    r_obj_type = conf.IDEA
                if "word-processed" in file_name:
                    r_obj_type = conf.WORD
            except:
                if sys.argv[2] == "word":
                    r_obj_type = conf.WORD
                if sys.argv[2] == "idea":
                    r_obj_type = conf.IDEA
            r_obj = review_object.ReviewAdObj()
            r_obj.init(line, r_obj_type)
            for k in p.model_obj:
                model = p.model_obj[k]
                check_result = model["obj"].check(r_obj)
                if check_result is None:
                    continue
                r_obj.add_result(model["conf_model_info"], check_result)
            if len(r_obj.check_result) == 0:
                continue
        elif data_type == conf.MODEL_TYPE_UNIT:
            r_obj = review_object.ReviewUnitObj()
            r_obj.init(line)
            for k in p.model_obj:
                model = p.model_obj[k]
                check_result = model["obj"].check(r_obj)
                r_obj.add_result(model["conf_model_info"], check_result)
        elif data_type == conf.MODEL_TYPE_USER:
            r_obj = review_object.ReviewUserObj()
            r_obj.init(line)
            for k in p.model_obj:
                model = p.model_obj[k]
                check_result = model["obj"].check(r_obj)
                r_obj.add_result(model["conf_model_info"], check_result)
        elif data_type == conf.MODEL_TYPE_CLICK_AD:
            r_obj = review_object.ReviewClickAdObj()
            r_obj.init(line)
            for k in p.model_obj:
                model = p.model_obj[k]
                check_result = model["obj"].check(r_obj)
                if check_result is None:
                    continue
                r_obj.add_result(model["conf_model_info"], check_result)
        elif data_type == conf.MODEL_TYPE_METEOR_AD:
            r_obj = review_object.ReviewMeteorAdObj()
            r_obj.init(line)
            for k in p.model_obj:
                model = p.model_obj[k]
                check_result = model["obj"].check(r_obj)
                if check_result is None:
                    continue
                r_obj.add_result(model["conf_model_info"], check_result)
        elif data_type == conf.MODEL_TYPE_CLICK_USER:
            r_obj = review_object.ReviewClickUserObj()
            r_obj.init(line)
            for k in p.model_obj:
                model = p.model_obj[k]
                check_result = model["obj"].check(r_obj)
                r_obj.add_result(model["conf_model_info"], check_result)
        elif data_type == conf.MODEL_TYPE_URL:
            r_obj = review_object.ReviewUrlObj()
            r_obj.init(line)
            for k in p.model_obj:
                model = p.model_obj[k]
                check_result = model["obj"].check(r_obj)
                r_obj.add_result(model["conf_model_info"], check_result)
        elif data_type == conf.MODEL_TYPE_FEED_AD:
            r_obj = review_object.ReviewFeedAdObj()
            r_obj.init(line)
            for k in p.model_obj:
                model = p.model_obj[k]
                check_result = model["obj"].check(r_obj)
                if check_result is None:
                    continue
                r_obj.add_result(model["conf_model_info"], check_result)
            if len(r_obj.check_result) == 0:
                continue
        elif data_type == conf.MODEL_TYPE_FEED_USER:
            r_obj = review_object.ReviewFeedUserObj()
            r_obj.init(line)
            for k in p.model_obj:
                model = p.model_obj[k]
                check_result = model["obj"].check(r_obj)
                r_obj.add_result(model["conf_model_info"], check_result)
        elif data_type == conf.MODEL_TYPE_FEED_IDEA_AD:
            if len(line) != 8:
                continue
            r_obj = review_object.ReviewFeedIdeaAdObj()
            r_obj.init(line)
            for k in p.model_obj:
                model = p.model_obj[k]
                check_result = model["obj"].check(r_obj)
                if check_result is None:
                    continue
                r_obj.add_result(model["conf_model_info"], check_result)
            if len(r_obj.check_result) == 0:
                continue
        elif data_type == conf.MODEL_TYPE_FEED_IDEA_UNIT:
            r_obj = review_object.ReviewFeedUnitObj()
            r_obj.init(line)
            for k in p.model_obj:
                model = p.model_obj[k]
                check_result = model["obj"].check(r_obj)
                r_obj.add_result(model["conf_model_info"], check_result)
        elif data_type == conf.MODEL_TYPE_FEED_IDEA_USER:
            r_obj = review_object.ReviewFeedIdeaUserObj()
            r_obj.init(line)
            for k in p.model_obj:
                model = p.model_obj[k]
                check_result = model["obj"].check(r_obj)
                r_obj.add_result(model["conf_model_info"], check_result)

        result = r_obj.review_result()
        print "%d\t%s" % (random.randint(0, 100000), json.dumps(result))
    p.destroy()
