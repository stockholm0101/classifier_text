#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/05/13 20:00:22
Desc  :   
"""
import os
import sys
import re
import random
import json

import url_predict_mapper
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import word_seg
import conf

import common.common as common
import review_object.review_object as review_object


class Predictor(object):
    """Ԥ����, ��ʼ��ģ��, ����ģ��Ԥ��ӿ�
    """
    def __init__(self):
        """init"""
        pass

    def init(self, stream_type, user_info_file, stopword_file, segdict_path):
        """��ʼ��ģ��
        [in]  stream_type: conf�и��������
              user_info_file: �û���Ϣ�ļ�
              stopword_file: ͣ�ô��ļ�
              segdict_path: �дʴʵ�
        [out] None
        """
        self.stopword = common.Common.load_word_file(stopword_file)
        self.word_segger = word_seg.WordSeg(segdict_path)
        self.word_segger.init_wordseg_handle()

        # import models
        self.model_obj = {}
        for k in conf.models:
            model = conf.models[k]
            if not model["enable"] or stream_type not in model["model_type"]:
                continue
            self.model_obj[k] = {}
            self.model_obj[k]["conf_model_info"] = model
            m_module = __import__(model["module_name"], fromlist = ['default'])
            m_class = getattr(m_module, model["class_name"])
            m_obj = m_class()
            self.model_obj[k]["obj"] = m_obj

        # init models
        self.init_models()

    def init_models(self):
        """���ε���ģ�ͳ�ʼ���ӿ�
        """
        for k in self.model_obj:
            model = self.model_obj[k]
            model_dir = model["conf_model_info"]["model_dir"]
            # ���ø�ģ�ͳ�ʼ���ӿ�
            model["obj"].init(self.word_segger, self.stopword, model_dir)

    def destroy(self):
        """
        �ͷ��д�
        """
        self.word_segger.destroy_wordseg_handle()


def url_monitor_predict(predictor):
    """��url��timestampԤ��
    """
    previous_url = None
    res_obj_dict = dict()
    r_obj = review_object.ReviewURLMonitorObj()
    for line in sys.stdin:
        line = line.strip("\n").lower().decode("gb18030", "ignore")
        parts = line.split("\t")
        url = parts[0]
        data_type = parts[1]
        json_obj = json.loads(parts[2])
        # ��url�仯ʱ ���ץȡ����ֵ�
        if url != previous_url:
            res_obj_dict.clear()
            previous_url = url

        # ����data_type��������
        if data_type == url_predict_mapper.URL_CRAWL_RES:
            cur_timestamp = json_obj["timestamp"]
            res_obj_dict[cur_timestamp] = json_obj
        elif data_type == url_predict_mapper.URL_WITH_EVIDENCE:
            # ��data_typeΪURL_WITH_EVIDENCEʱ ˵��URL_CRAWL_RES�ѽ�����
            # ��ǰΪһ���˻� ����֮ǰ���ո�url������ץȡ�������Ԥ��
            for timestamp, res_obj in res_obj_dict.items():
                #print("cur info:\n%s" % line)
                r_obj.init(json_obj, res_obj, timestamp)
                #print("cur res:\n%s" %  json.dumps(r_obj.review_result()))
                predict(predictor, r_obj)
                result = r_obj.review_result()
                print(json.dumps(result))


def url_continuous_monitor_predict(predictor):
    """��url�ĸ�timestamp���Ԥ��
    """
    raise NotImplementedError("url_continuous_monitor_predict func has not implemented!")


def predict(predictor, r_obj):
    """���ø�ģ�Ͷ�r_objԤ��
    """
    for k in predictor.model_obj:
        model = predictor.model_obj[k]
        check_result = model["obj"].check(r_obj)
        if check_result is None:
            continue
        r_obj.add_result(model["conf_model_info"], check_result)


def main():
    """�����
    """
    segdict_path = "dict/chinese_gbk"
    user_info_file = "data/user_info.txt"
    stopword_file = "data/stopword.txt"

    stream_type = int(sys.argv[1])

    p = Predictor()
    p.init(stream_type, user_info_file, stopword_file, segdict_path)

    predict_func_dict = {
            conf.MODEL_TYPE_URL_MONITOR: url_monitor_predict,
            conf.MODEL_TYPE_URL_CONTINUOUS_MONITOR: url_continuous_monitor_predict,
            }

    predict_func_dict[stream_type](p)

    p.destroy()


if __name__ == "__main__":
    main()
