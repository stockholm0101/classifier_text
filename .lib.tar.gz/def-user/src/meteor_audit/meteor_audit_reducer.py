#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   zhukaiwen@baidu.com
#Date  :   19/05/17 11:51:31
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os
import json

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object
import review_object.merge_object as merge_object
import conf

def load_meteor_class_label(file_name):
    """"""
    class_dict = {}
    with open(file_name, "r") as f:
        for eachline in f:
            if eachline.startswith("#"):
                continue
            line = eachline.decode("gbk", "ignore").strip("\n").split("\t")
            model_id = line[0]
            label = line[1]
            label_name = line[2]
            if model_id not in class_dict:
                class_dict[model_id] = {}
            if label not in class_dict[model_id]:
                class_dict[model_id][label] = label_name
    return class_dict

def add_to_meteor_user(userid, meteor_ad, meteor_user):
    """ͳ���û�ά����Ϣ: ��������, ����������, �ܾ�������, ��ģ�;ܾ�����
    [in]  userid
          meteor_ad: һ��meteor��˼�¼
          meteor_user: �û�����˽��ͳ����
    [out] None
    """
    meteor_user.userid = userid
    meteor_user.total_ads_num += 1
    if meteor_ad.is_need_audit == "1":
        meteor_user.total_is_need_audit += 1
    else:
        return

    if meteor_ad.review_result == "DISAPPROVED":
        meteor_user.total_disapproved += 1
    else:
        return

    for k in conf.models:
        model = conf.models[k]
        if conf.MODEL_TYPE_METEOR not in model["model_type"]:
            continue

        # ��ʼ��, �洢�û�������meteor modelid�Ľ��
        model_id = model["model_id"]
        if model_id not in meteor_user.model_result:
            meteor_user.init_model_result_by_model(model)
        model_result_detail = meteor_user.model_result[model_id]

        # ͳ���������, �����Ӧ��֤������, �ؼ���10, ����3
        meteor_model_id = set(model["meteor_model_id"].split("|"))
        if meteor_ad.risk_model_id in meteor_model_id:
            model_result_detail["hit_ad_num"] += 1
            if meteor_ad.audit_type == "word":
                if len(model_result_detail["evidence"]["word"]) < 10:
                    model_result_detail["evidence"]["word"].add(meteor_ad.wordtext)
            elif meteor_ad.audit_type == "idea":
                if len(model_result_detail["evidence"]["idea"]) < 3:
                    model_result_detail["evidence"]["idea"].add(meteor_ad.idea)

def convert_meteor_user_to_merge_obj(meteor_user, meteor_model_obj):
    """��ͳ�Ƶ��û�ά�Ƚ��תΪmerge obj
    """
    merge_obj = merge_object.MergeObj()
    merge_obj.init(meteor_user.userid)

    # ÿ��meteor model, �ж��������
    for model_id in meteor_model_obj:
        model_obj = meteor_model_obj[model_id]
        ret, model_conf_info, model_merge_result = model_obj.check(meteor_user)
        if ret != 0:
            continue
        merge_obj.add_result(model_conf_info, model_merge_result.convert_to_dict(), conf.MODEL_TYPE_METEOR_AD)

    if len(merge_obj.check_result) == 0:
        return None
    return merge_obj


if __name__ == "__main__":
    class_file = os.path.join(conf.METEOR_MODEL_DIR, "class_id.txt")
    #local
    #class_file = "../model/model_meteor/class_id.txt"
    class_dict = load_meteor_class_label(class_file)

    meteor_model = {}
    for k in conf.models:
        model = conf.models[k]
        if conf.MODEL_TYPE_METEOR not in model["model_type"]:
            continue
        meteor_model[model["model_id"]] = model

    meteor_model_obj = {}
    # import models, init
    for model_id in meteor_model:
        model = meteor_model[model_id]
        if not model["enable"]:
            continue
        m_module = __import__(model["module_name"], fromlist = ["default"])
        m_class = getattr(m_module, model["class_name"])
        m_obj = m_class()
        m_obj.init(model, class_dict)
        meteor_model_obj[model_id] = m_obj

    old_userid = None
    meteor_user = review_object.MeteorUser()

    for eachline in sys.stdin:
        line = eachline.decode("gbk", "ignore").strip("\n").split("\t")
        meteor_ad = review_object.MeteorAd(line)
        # �Ƿﳲ, �ǻ���
        if meteor_ad.productid != "0" or meteor_ad.haudit_type != "-1":
            continue

        userid = line[0]
        if old_userid is None or old_userid == userid:
            # ����
            add_to_meteor_user(userid, meteor_ad, meteor_user)
        elif old_userid != userid:
            # ���user���
            merge_obj = convert_meteor_user_to_merge_obj(meteor_user, meteor_model_obj)
            if merge_obj is not None:
                print json.dumps(merge_obj.merge_result())

            # ��ʼ���¸�user��Ϣ
            meteor_user = review_object.MeteorUser()
            add_to_meteor_user(userid, meteor_ad, meteor_user)

        old_userid = userid

    if old_userid is not None:
        merge_obj = convert_meteor_user_to_merge_obj(meteor_user, meteor_model_obj)
        if merge_obj is not None:
            print json.dumps(merge_obj.merge_result())
