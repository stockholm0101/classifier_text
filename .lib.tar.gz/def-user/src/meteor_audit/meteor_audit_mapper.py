#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   19/05/16 16:55:10
Desc  :   meteor������˽��, ��ʽ�ο�wiki: 
          http://wiki.baidu.com/display/defEngineer/Galaxy_datalist_audit
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import re

if __name__ == "__main__":
    for eachline in sys.stdin:
        line = eachline.strip("\n").split("\t")
        if len(line) < 80:
            continue

        pipe_type = line[1]
        audit_type = line[2]     # word, idea, pair
        userid = line[3]
        unitid = line[4]
        planid = "0"             # ȱʧ
        winfoid = line[5]
        ideaid = line[7]
        wordtext = line[16].lower()
        wurl = line[17]
        title = line[19].lower()
        desc1 = line[20].lower()
        desc2 = line[21].lower()
        targeturl = line[22]
        productid = line[41]     # 0.fc
        audit_channel_type = line[74] # 1. ���� 3. һ��
        is_need_audit = line[75] # 1.����
        haudit_type = line[76]   # -1.����
        review_result = line[45] # APPROVED, DISAPPROVED
        risk_id = line[77]       # ����id
        risk_model_id = line[78] # ����ģ��id

        if audit_type != "word" and audit_type != "idea":
            continue

        if productid != "0" or audit_channel_type not in set(["1", "3"]) or pipe_type != "output-trad-fc":
            continue

        rex = u"{�ؼ���}|{Ͷ�ŵ���}|{����}|{|}"
        idea = "%s %s %s" % (title, desc1, desc2)
        idea = idea.replace("\t", " ").replace("\x01", " ").replace("\n", " ")
        idea = re.sub(rex, "", idea.decode("gbk", "ignore")).strip().encode("gbk", "ignore")

        wordtext = wordtext.replace("\t", " ").replace("\x01", " ").replace("\n", " ")
        wordtext = re.sub(rex, "", wordtext.decode("gbk", "ignore")).strip().encode("gbk", "ignore")

        print "\t".join([userid, productid, planid, unitid, audit_type, review_result,
            is_need_audit, haudit_type, winfoid, wordtext, wurl, ideaid, idea, 
            targeturl, risk_id, risk_model_id])
