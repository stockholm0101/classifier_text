#!/bin/bash

#===================================================
# Copyright (C) 2020 K All rights reserved.
# �ļ����ƣ�local_predict.sh
# �� �� �ߣ�zhuxiaodong01@baidu.com
# �������ڣ�2020��02��07��
# ��    ����sh local_predict.sh userid.txt
#===================================================

userids=${1}

# ======��ǰ����Ŀ¼=======
BASE_DIR=$(cd "$(dirname "$0")";pwd)
MODEL_DIR="${BASE_DIR}/../../model/"
SRC_DIR="${BASE_DIR}/../../src/"
EXE_DIR="${BASE_DIR}/../../"

# ������ʱĿ¼���ڴ���м��ļ�
LOCAL_DIR="${BASE_DIR}/local_dir/"
mkdir ${LOCAL_DIR}

# ��def_user�ĸ�Ŀ¼��ִ��
cd ${EXE_DIR}
cp ${BASE_DIR}/${userids} ${EXE_DIR}

# ======���ñ���python·��======
PYTHON_LOCAL="/home/users/zhukaiwen/workspace/git/baidu/fengkong/def-user/python/bin/python"

# ��ȡuserid�����߿�����
db=(
"10.233.31.50"
"10.173.251.50"
"10.175.131.150"
"10.193.84.35"
"10.193.89.36"
"10.193.90.21"
"10.193.90.51"
"10.193.91.36"
"10.193.92.31"
"10.173.251.45"
"10.175.131.147"
"10.195.185.24"
"10.175.193.141"
"10.176.124.145"
"10.193.87.35"
"10.193.86.50"
"10.193.88.50"
"10.173.246.14"
"10.173.246.23"
"10.175.131.142"
"10.193.84.34"
"10.207.160.58"
"10.176.124.152"
"10.176.124.147"
"10.173.251.32"
"10.175.131.44"
"10.173.251.28"
"10.173.251.27"
"10.173.251.35"
"10.173.251.38"
"10.173.251.37"
"10.176.124.166"
"10.173.251.40"
"10.153.97.19"
)
#db=()

for ((i=0;i<33;i++))
do
    name="fcdb5858000${i}-offline.xdb.all.serv"
    if [ ${i} -ge 10 -a ${i} -ne 32 ]; then
        name="fcdb585800${i}-offline.xdb.all.serv"
    elif [ ${i} -eq 32 ]; then
        name="fcdb58589999-offline.xdb.all.serv"
    fi
    host_name=`get_instance_by_service ${name}`
    db_ip=`nslookup ${host_name} | tail -2 | head -1 | awk -F": " '{print $NF}'`
    db[${#db[*]}]=${db_ip}
done

cat /dev/null > ${LOCAL_DIR}ideainfo.txt
cat /dev/null > ${LOCAL_DIR}wordinfo.txt
while read line
do
    userid=`echo ${line} | awk -F" " '{print $1}'`
    #shardnum=$[(${userid}&768)>>6|(${userid}&3)]
    shardnum=$[(${userid}&1792)>>6|(${userid}&3)]
    if [ $shardnum == 9999 ]; then
        shardnum=33
    fi
    tableid=$[(${userid}&28)>>2]
    echo ${tableid}

    sql="use FC_Word; set names gbk; select  a.ideaid, a.version, \
        a.unitid, a.planid, a.userid, a.isdel, 0, 0, 0, 0, \
        a.ideastat1, a.ideastat2, a.ideastat3, a.ideastat4, \
        a.ideastat5, a.ideastat6, a.modtime, b.ideatitle, \
        b.ideadesc, b.ideadesc2, b.ideaurl, b.ideashowurl, \
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, a.adtype, \
        a.ideatag from ideainfo${tableid} as a, \
        ideadesc${tableid} as b where a.userid=${userid} \
        and a.ideaid=b.ideaid limit 1000000"
    host=${db[$shardnum]}
    mysql -h$host -uleizihe -pYvIyVmNPU6ZdKdjod -P5858 -e "${sql}" >> \
        ${LOCAL_DIR}ideainfo.txt

    sql="use FC_Word; set names gbk; select * from wordinfo${tableid} \
        where userid=${userid} limit 1000000"
    host=${db[$shardnum]}
    mysql -h$host -uleizihe -pYvIyVmNPU6ZdKdjod -P5858 -e "${sql}" >> \
        ${LOCAL_DIR}wordinfo.txt
done < ${userids}

# ����Ԥ����
sed -i "/^winfoid/d" ${LOCAL_DIR}wordinfo.txt
sed -i "/^ideaid/d" ${LOCAL_DIR}ideainfo.txt
cat ${LOCAL_DIR}wordinfo.txt | \
    ${PYTHON_LOCAL} ${SRC_DIR}preprocess/preprocess_mapper.py word | \
    cut -f2-9 > ${LOCAL_DIR}wordprocess.txt
cat ${LOCAL_DIR}ideainfo.txt | \
    ${PYTHON_LOCAL} ${SRC_DIR}preprocess/preprocess_mapper.py idea | \
    cut -f2-9 > ${LOCAL_DIR}ideaprocess.txt
cat ${LOCAL_DIR}wordprocess.txt | \
    ${PYTHON_LOCAL} ${SRC_DIR}sample_by_unit/sample_mapper.py word > \
    ${LOCAL_DIR}wordunitmapper.txt
cat ${LOCAL_DIR}ideaprocess.txt | \
    ${PYTHON_LOCAL} ${SRC_DIR}sample_by_unit/sample_mapper.py idea > \
    ${LOCAL_DIR}ideaunitmapper.txt
cat ${LOCAL_DIR}wordprocess.txt | \
    ${PYTHON_LOCAL} ${SRC_DIR}sample_by_user/sample_mapper.py word > \
    ${LOCAL_DIR}wordusermapper.txt
cat ${LOCAL_DIR}ideaprocess.txt | \
    ${PYTHON_LOCAL} ${SRC_DIR}sample_by_user/sample_mapper.py idea > \
    ${LOCAL_DIR}ideausermapper.txt

# Ԥ��

# ��ԪԤ��
cat ${LOCAL_DIR}wordunitmapper.txt ${LOCAL_DIR}ideaunitmapper.txt | sort -k1,2 | \
    ${PYTHON_LOCAL} ${SRC_DIR}sample_by_unit/sample_reducer.py |\
    ${PYTHON_LOCAL} ${SRC_DIR}predict/predict_mapper.py 2 | \
    ${PYTHON_LOCAL} ${SRC_DIR}predict/predict_reducer.py | \
    ${PYTHON_LOCAL} ${SRC_DIR}merge_result_to_user/merge_mapper.py 2 | sort -k1 | \
    ${PYTHON_LOCAL} ${SRC_DIR}merge_result_to_user/merge_reducer.py 2 > \
    ${LOCAL_DIR}unitpredict.txt

# �˻�Ԥ��
cat ${LOCAL_DIR}wordusermapper.txt ${LOCAL_DIR}ideausermapper.txt | sort -k1,2 | \
    ${PYTHON_LOCAL} ${SRC_DIR}sample_by_user/sample_reducer.py |\
    ${PYTHON_LOCAL} ${SRC_DIR}predict/predict_mapper.py 3 | \
    ${PYTHON_LOCAL} ${SRC_DIR}predict/predict_reducer.py > \
    ${LOCAL_DIR}userpredict.txt

# �ϲ�����
cat ${LOCAL_DIR}unitpredict.txt | \
    ${PYTHON_LOCAL} ${SRC_DIR}merge_result_to_user/merge_model_result_mapper.py 2 > \
    ${LOCAL_DIR}unitmergedata
cat ${LOCAL_DIR}userpredict.txt | \
    ${PYTHON_LOCAL} ${SRC_DIR}merge_result_to_user/merge_model_result_mapper.py 3 > \
    ${LOCAL_DIR}usermergedata
cat ${LOCAL_DIR}unitmergedata ${LOCAL_DIR}usermergedata | sort -k1,2 | \
    ${PYTHON_LOCAL} ${SRC_DIR}merge_result_to_user/merge_model_result_reducer.py

# ��������
rm ${EXE_DIR}${userids}
cd -
rm -rf ${LOCAL_DIR}
