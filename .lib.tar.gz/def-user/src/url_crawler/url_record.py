#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/05/08 16:14:46
Desc  :   
"""

import codecs
import datetime
import json
import logging
import os
import sys
import time
from collections import defaultdict

# ��ʾ�ɹ��ķ�����
SUCC_RET_CODE = 200

# ��������
USER = "user"
URL  = "url"

# ���ּ�¼
SUBMIT_RECORD = "submit_record"
CRAWL_RECORD  = "crawl_record"
CHECK_RECORD  = "check_record"


class URLRecorder(object):
    """urlץȡ��¼��Ϣ��
    """
    def __init__(self):
        self.user_record = defaultdict(lambda: {
                SUBMIT_RECORD: set(),
                CHECK_RECORD: set(),
                })
        self.url_record = defaultdict(lambda: {
                SUBMIT_RECORD: set(),
                CHECK_RECORD: set(),
                CRAWL_RECORD: dict(),
                })

    def load_from_file_old(self, record_path):
        """��ԭ���ļ�¼�ļ�����ץȡ��¼
        """
        with codecs.open(record_path, "r", "gb18030") as rf:
            for line in rf:
                parts = line.strip("\n").split("\t")
                url = parts[0]
                record = json.loads(parts[1])
                self.url_record[url][SUBMIT_RECORD] = set(record["sumbit_record"])
                crawl_record = dict()
                for timestamp, (ret_code, _, _, format_time) in record["crawl_record"].items():
                    crawl_record[timestamp] = [format_time, ret_code]
                self.url_record[url][CRAWL_RECORD] = crawl_record

    def load_from_file(self, record_path):
        """�Ӽ�¼�ļ�����ץȡ��¼
        """
        with codecs.open(record_path, "r", "gb18030") as rf:
            for line in rf:
                record_obj = json.loads(line.strip("\n"))
                type = record_obj["type"]
                value = record_obj["value"]
                record_dict = {
                        CHECK_RECORD:set(record_obj[CHECK_RECORD]),
                        SUBMIT_RECORD:set(record_obj[SUBMIT_RECORD]),
                        }
                if type == USER:
                    self.user_record[value] = record_dict
                elif type == URL:
                    crawl_rcord = dict()
                    for cur_record in record_obj[CRAWL_RECORD]:
                        format_time, ret_code, timestamp = cur_record
                        crawl_rcord[timestamp] = [format_time, ret_code]
                    record_dict[CRAWL_RECORD] = crawl_rcord
                    self.url_record[value] = record_dict
                else:
                    raise ValueError("unknown record type: {}".format(type))

    def clear_record(self, longest_time):
        """������õļ�¼������longest_time�Ķ��������
        longest_time: datetime��
        """
        def check_format_time(cur_format_time):
            """���YYYYMMDDHH�ַ�����ʱ���Ƿ�����longest_time, true��ʾ����longest_time
            """
            cur_format_datetime = datetime.datetime.strptime(cur_format_time, "%Y%m%d%H")
            return cur_format_datetime >= longest_time

        def check_timestamp(cur_timestamp):
            """���ʱ�����Ӧ��ʱ���Ƿ�����longest_time, true��ʾ����longest_time
            """
            cur_datetime = datetime.datetime.fromtimestamp(cur_timestamp)
            return cur_datetime >= longest_time

        # ���url�й��õļ�¼
        for url, record_dict in self.url_record.items():
            record_dict[SUBMIT_RECORD] = filter(check_format_time, record_dict[SUBMIT_RECORD])
            record_dict[CHECK_RECORD] = filter(check_format_time, record_dict[CHECK_RECORD])
            reserved_crawl_record = \
                    filter(lambda x: check_timestamp(float(x)), record_dict[CRAWL_RECORD].keys())
            record_dict[CRAWL_RECORD] = {timestamp:record_dict[CRAWL_RECORD][timestamp] \
                    for timestamp in reserved_crawl_record}

        # ���user�й��õļ�¼
        for user, record_dict in self.user_record.items():
            record_dict[SUBMIT_RECORD] = filter(check_format_time, record_dict[SUBMIT_RECORD])
            record_dict[CHECK_RECORD] = filter(check_format_time, record_dict[CHECK_RECORD])

    def latest_crawl_time(self, url):
        """���url���һ��ץȡ�ɹ���ʱ��
        """
        crawl_timestamp_list = self.url_record[url][CRAWL_RECORD].keys()
        return 0 if len(crawl_timestamp_list) == 0 \
                else max(crawl_timestamp_list)

    def crawl_times(self, url):
        """��ø�url��ץȡ����
        """
        return len(self.url_record[url][CRAWL_RECORD])

    def save_to_file(self, record_path):
        """��¼���浽�ļ�
        """
        def str_2_int_sort(str_list, reverse=False):
            """���ַ����б�����תΪint��Ĵ�С����
            """
            return sorted(str_list, key=lambda x:int(x), reverse=reverse)

        def str_key_dict_sort(str_key_dict, reverse=False):
            """�����ַ���Ϊ�����ֵ䰴��ؼ���תΪint��Ĵ�С����
            """
            res = list()
            for key in str_2_int_sort(str_key_dict.keys(), reverse=reverse):
                format_time, ret_code = str_key_dict[key]
                res.append((format_time, ret_code, key))
            return res

        logging.info("save to file: %s" % record_path)
        start_time = time.time()
        with codecs.open(record_path, "w", "gb18030") as wf:
            #  ����url��Ϣ
            for url, record_dict in self.url_record.items():
                cur_url_record_info = {
                        "type": URL,
                        "value": url,
                        SUBMIT_RECORD: str_2_int_sort(record_dict[SUBMIT_RECORD], reverse=True),
                        CHECK_RECORD: str_2_int_sort(record_dict[CHECK_RECORD], reverse=True),
                        CRAWL_RECORD: str_key_dict_sort(record_dict[CRAWL_RECORD], reverse=True),
                        }
                cur_url_record_json = json.dumps(cur_url_record_info)
                wf.write(cur_url_record_json + "\n")

            #  ����user��Ϣ
            for user, record_dict in self.user_record.items():
                cur_user_record_info = {
                        "type": USER,
                        "value": user,
                        SUBMIT_RECORD: str_2_int_sort(record_dict[SUBMIT_RECORD], reverse=True),
                        CHECK_RECORD: str_2_int_sort(record_dict[CHECK_RECORD], reverse=True),
                        }
                cur_user_record_json = json.dumps(cur_user_record_info)
                wf.write(cur_user_record_json + "\n")
        logging.info("cost time: %.4fs" % (time.time() - start_time))

    def add_user_monitor_record(self, userid, batch_time):
        """�����˻��ļ�ؼ�¼
        """
        self.user_record[userid][SUBMIT_RECORD].add(batch_time)

    def add_url_monitor_record(self, url, batch_time):
        """�����˻��ļ�ؼ�¼
        """
        self.url_record[url][SUBMIT_RECORD].add(batch_time)

    def add_user_check_record(self, userid, batch_time):
        """�����˻�����˼�¼
        """
        self.user_record[userid][CHECK_RECORD].add(batch_time)

    def add_url_check_record(self, url, batch_time):
        """����url����˼�¼
        """
        self.url_record[url][CHECK_RECORD].add(batch_time)

    def add_url_crawl_record(self, url, timestamp, format_time, ret_code):
        """����url��ץȡ��¼
        """
        self.url_record[url][CRAWL_RECORD][timestamp] = (format_time, ret_code)


if __name__ == "__main__":
    pass


