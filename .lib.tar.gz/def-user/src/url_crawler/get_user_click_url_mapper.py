#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   20/04/28 15:26:15
Desc  :   
"""

import codecs
import json
import os
import sys
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object
from common.sampler import Sampler
import conf

def load_url_monitor_user(user_path):
    """������Ҫ���url���˻�
    """
    user_click_num_dict = dict()
    with codecs.open(user_path, "r", "gb18030") as rf:
        for line in rf:
            parts = line.strip("\n").split("\t")
            userid = parts[0]
            monitor_info = json.loads(parts[1])
            click_max_num = monitor_info["monitor_conf"].get("click", dict()).get("max_num", 0)
            if click_max_num > 0:
                # ��ֹ����click����ʱ���� ������Ϊ��󲻳���conf�����õ�����
                click_max_num = click_max_num if click_max_num < conf.USER_CLICK_URL_SAMPLE_MAX \
                        else conf.USER_CLICK_URL_SAMPLE_MAX
                user_click_num_dict[userid] = click_max_num
    return user_click_num_dict


def main():
    """��ȡָ���˻��������url
    """
    user_path = sys.argv[1]
    user_max_num_dict = load_url_monitor_user(user_path)
    r_obj = review_object.ReviewClickAdObj()
    user_click_sample_dict = dict()
    # ��ʼ����userid�ĳ�������
    for userid, max_num in user_max_num_dict.items():
        user_click_sample_dict[userid] = Sampler(max_num)

    for line in sys.stdin:
        parts = line.strip("\n").lower().decode("gb18030", "ignore").split("\t")
        r_obj.init(parts)
        if r_obj.userid not in user_click_sample_dict:
            continue
        user_click_sample_dict[r_obj.userid].put(r_obj.url)

    # �����������������
    for userid, user_click_url_sampler in user_click_sample_dict.items():
        for click_url in user_click_url_sampler.get_sample_list():
            print("\t".join([userid, click_url]).encode("gb18030"))


if __name__ == "__main__":
    main()
