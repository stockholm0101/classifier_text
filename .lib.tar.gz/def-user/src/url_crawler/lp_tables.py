#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
Author:   zhanghao55@baidu.com
Date  :   19/12/19 16:40:23
Desc  :   
"""
import chardet
import json
import os
import pytable
import re
import sys

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../lib/" % _cur_dir)

#LocalLpFeature����Ҫprotopy��������feature����table��ȡ���������ע�͵���
#from protopy import feature_common_pb2 as feature_common

# ����table��
TABLE_SOURCE = "table://andi.table.baidu.com:8111/fengkonglpdb/page_source_tbl"
TABLE_FEATURE = "table://andi.table.baidu.com:8111/fengkonglpdb/page_feature_tbl"
TABLE_SNAPSHOT = "table://andi.table.baidu.com:8111/fengkongbdyun/snapshot_info_tbl"
TABLE_RISKINFO = "table://andi.table.baidu.com:8111/fengkonglpdb/risk_info_tbl"

# ���table��
TABLE_OFFSITE_SOURCE = "table://andi.table.baidu.com:8111/fengkonglpdb/page_source_rcptspider_tbl"
TABLE_OFFSITE_CRAWL_INFO = "table://andi.table.baidu.com:8111/fengkonglpdb/crawl_info_rcptspider_tbl"

# ����ֵ
RET_SUCCESS = 0
RET_NULL_WISE = 1
RET_NULL_PC = 2
RET_JSON_FAIL = 3

# PC, WISE
PC = 0
WISE = 1

# ����ӳ��
encode_dict = {
        "GB2312": "gb18030",
        "gbk": "gb18030",
        }


def format_string(text):
    """ �淶���ı�
    """
    text = text.replace("\t", " ").replace("\n", " ").replace("  ", " ")
    while "  " in text:
        text = text.replace("  ", " ")
    text = text.strip()
    return text

class LpTable(object):
    """ץȡ��
    """
    def __init__(self, table_path):
        self.table = pytable.TableWrap(table_path)
        self.query_result = pytable.Result()
        self.query_cell = pytable.Cell()
        self.from_pc_wise = WISE


class OffsiteLpCrawlInfo(LpTable):
    """���ץȡ״̬��Ϣ
    """
    def get_result(self, row_key):
        """��ȡ���
        """
        self.url = row_key
        ret = self.table.get(row_key, ["ci:c0_1_0"], 0, 1, self.query_result)
        if not ret or self.query_result.size() == 0:
            self.from_pc_wise = PC
            ret = self.table.get(row_key, ["ci:c0_0_0"], 0, 1, self.query_result)
            if not ret or self.query_result.size() == 0:
                return RET_NULL_PC, self.from_pc_wise
        return RET_SUCCESS, self.from_pc_wise

    def parse_query_result(self):
        """�������
        """
        result = []
        while self.query_result.next(self.query_cell):
            cell_result = {}
            url_encoding = "NULL"

            try:
                query_result = json.loads(self.query_cell.value.decode("gbk", "ignore"))
            except Exception as e:
                detect = chardet.detect(self.query_cell.value)
                if "encoding" not in detect or detect is None:
                    continue

                url_encoding = detect["encoding"]
                if url_encoding in encode_dict:
                    url_encoding = encode_dict[url_encoding]

                try:
                    query_result = json.loads(self.query_cell.value.decode(url_encoding, "ignore"))
                    #sys.stderr.write("url(%s) decode with encoding %s.\n" % (self.url, url_encoding))
                except Exception as e:
                    continue

            #print("query_result: {}".format(query_result))
            crawl_time = query_result["gtime"]
            crawl_ret_code = query_result["res"]
            result.append((crawl_time, crawl_ret_code))
            # ��Ϊ֮��Ҳֻȡ��һ�� ��������ֱ��break ���Ҫ������ ��Ҫbreak
            # break
        return result


class OffsiteLpPageSource(LpTable):
    """���ץȡԴ����
    """
    def get_result(self, row_key, min_timestamp=0, max_timestamp=0, max_version=0):
        """��ȡ���
        """
        self.url = row_key
        ret = self.table.get2(row_key, ["ps:c0_1_0"], min_timestamp,
                max_timestamp, max_version, self.query_result)
        if not ret or self.query_result.size() == 0:
            self.from_pc_wise = PC
            ret = self.table.get2(row_key, ["ps:c0_0_0"], min_timestamp,
                    max_timestamp, max_version, self.query_result)
            if not ret or self.query_result.size() == 0:
                return RET_NULL_PC
        return RET_SUCCESS

    def parse_query_result(self):
        """�������
        """
        result = []
        while self.query_result.next(self.query_cell):
            cell_result = {}
            url_encoding = "NULL"

            try:
                cur_query_result = json.loads(self.query_cell.value.decode("gbk", "ignore"))
            except Exception as e:
                detect = chardet.detect(self.query_cell.value)
                if "encoding" not in detect or detect is None:
                    continue

                url_encoding = detect["encoding"]
                if url_encoding in encode_dict:
                    url_encoding = encode_dict[url_encoding]

                try:
                    cur_query_result = json.loads(self.query_cell.value.decode(url_encoding, "ignore"))
                    #sys.stderr.write("url(%s) decode with encoding %s.\n" % (self.url, url_encoding))
                except Exception as e:
                    continue

            cell_result["pc_or_wise"] = self.from_pc_wise
            cell_result["ret_code"] = cur_query_result["res"]
            cell_result["timestamp"] = cur_query_result["gtime"]
            cell_result["furl"] = cur_query_result["furl"]
            cell_result["src"] = format_string(cur_query_result["src"])
            cell_result["encoding"] = url_encoding
            cell_result["uatype"] = cur_query_result.get("uatype", "")
            result.append(cell_result)
            # ��Ϊ֮��Ҳֻȡ��һ�� ��������ֱ��break ���Ҫ������ ��Ҫbreak
            # break
        return result

    def get_feature_from_src(self, src):
        """������������
        """
        rex = re.compile(u"[\u4e00-\u9fa5]+")
        text_list = rex.findall(src)
        return " ".join(text_list)

class LocalLpPageSource(LpTable):
    """����ץȡԴ���
    """
    def get_result(self, row_key, min_timestamp=0, max_timestamp=0, max_version=0):
        """��ȡ���
        """
        self.url = row_key
        #ret = self.table.get(row_key, ["ps:c0_1_0"], 0, 1, self.query_result)
        ret = self.table.get2(row_key, ["ps:c0_1_0"], min_timestamp,
                max_timestamp, max_version, self.query_result)
        if not ret or self.query_result.size() == 0:
            self.from_pc_wise = PC
            #ret = self.table.get(row_key, ["ps:c0_0_0"], 0, 1, self.query_result)
            ret = self.table.get2(row_key, ["ps:c0_0_0"], min_timestamp,
                    max_timestamp, max_version, self.query_result)
            if not ret or self.query_result.size() == 0:
                return RET_NULL_PC
        return RET_SUCCESS

    def parse_query_result(self):
        """�������
        """
        result = []
        # print query_cell.value, query_cell.column, query_cell.timestamp
        while self.query_result.next(self.query_cell):
            cell_result = {}
            url_encoding = "NULL"

            try:
                cur_query_result = json.loads(self.query_cell.value.decode("gbk", "ignore"))
            except Exception as e:
                detect = chardet.detect(self.query_cell.value)
                if "encoding" not in detect or detect is None:
                    continue

                url_encoding = detect["encoding"]
                if url_encoding in encode_dict:
                    url_encoding = encode_dict[url_encoding]

                try:
                    cur_query_result = json.loads(self.query_cell.value.decode(url_encoding, "ignore"))
                    #sys.stderr.write("url(%s) decode with encoding %s.\n" % (self.url, url_encoding))
                except Exception as e:
                    continue

            #print("cur_query_result: {}".format(json.dumps(cur_query_result)))

            cell_result["pc_or_wise"] = self.from_pc_wise
            cell_result["ret_code"] = cur_query_result["res"]
            cell_result["timestamp"] = cur_query_result["gtime"]
            cell_result["session_id"] = cur_query_result["session_id"]
            cell_result["furl"] = cur_query_result["furl"]
            cell_result["src"] = format_string(cur_query_result["src"])
            cell_result["encoding"] = url_encoding
            cell_result["uatype"] = cur_query_result.get("uatype", "")
            result.append(cell_result)
            # ��Ϊ֮��Ҳֻȡ��һ�� ��������ֱ��break ���Ҫ������ ��Ҫbreak
            # break
        return result


class LocalLpFeature(LpTable):
    """ץȡ������
    ע�⣺��غͱ��ص�ץȡ����������ڸ�ץȡ�������� ֻ����һ���汾 ��˲��øÿ�
    """
    def get_result(self, row_key, min_timestamp=0, max_timestamp=0, max_version=0):
        """��ȡ���
        """
        #ret = self.table.get(row_key, ["pf:c0_1_0"], 0, 1, self.query_result)
        ret = self.table.get2(row_key, ["pf:c0_1_0"], min_timestamp,
                max_timestamp, max_version, self.query_result)
        if not ret or self.query_result.size() == 0:
            self.from_pc_wise = PC
            #ret = self.table.get(row_key, ["pf:c0_0_0"], 0, 1, self.query_result)
            ret = self.table.get2(row_key, ["pf:c0_0_0"], min_timestamp,
                    max_timestamp, max_version, self.query_result)
            if not ret or self.query_result.size() == 0:
                return RET_NULL_PC
        return RET_SUCCESS

    def parse_query_result(self):
        """�������
        """
        result = []
        feature_result = feature_common.MPageFeature()
        # print query_cell.value, query_cell.column, query_cell.timestamp
        while self.query_result.next(self.query_cell):
            cell_result = {}
            # ��pb
            feature_result.ParseFromString(self.query_cell.value)

            cell_result["timestamp"]           = feature_result.gtime
            cell_result["session_id"]           = feature_result.session_id
            cell_result["title"]               = format_string(feature_result.feature.title)
            cell_result["navigation"]          = format_string(feature_result.feature.navigation)
            cell_result["sem_central_content"] = format_string(feature_result.feature.sem_central_content)
            cell_result["keywords"]            = format_string(feature_result.feature.keywords)
            cell_result["abstract"]            = format_string(feature_result.feature.abstract)
            cell_result["inner_links"]         = format_string(feature_result.feature.inner_links)
            cell_result["links"]               = format_string(feature_result.feature.links)

            result.append(cell_result)

        return result

if __name__ == "__main__":
    import url_util
    ts = LocalLpPageSource(TABLE_SOURCE)
    tf = LocalLpFeature(TABLE_FEATURE)
    url_list = [
            "http://kai.lfcckj.com/",
            "http://www.weiling520.com/advertising/v3/?channel=mosheng-baidu-900336&channel_id=900336",
            "http://www.pinchuan.net",
            ]
    for url in url_list:
        print("process url: %s" % url)
        row_key = url_util.strip_url_cpp(url)
        feature_ret = tf.get_result(row_key)
        src_ret = ts.get_result(row_key)
        if feature_ret == RET_SUCCESS and src_ret == RET_SUCCESS:
            source_result = ts.parse_query_result()
            feature_result = tf.parse_query_result()
            for res in source_result:
                print(json.dumps(res, encoding="gb18030"))
            for res in feature_result:
                print(json.dumps(res, encoding="gb18030"))
