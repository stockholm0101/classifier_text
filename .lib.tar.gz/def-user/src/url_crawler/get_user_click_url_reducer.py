#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/05/12 11:47:10
Desc  :   
"""
import codecs
import json
import os
import sys
from collections import defaultdict
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

from common.sampler import Sampler
import conf


def load_url_monitor_user(user_path):
    """������Ҫ���url���˻�
    """
    user_click_num_dict = dict()
    with codecs.open(user_path, "r", "gb18030") as rf:
        for line in rf:
            parts = line.strip("\n").split("\t")
            userid = parts[0]
            monitor_info = json.loads(parts[1])
            click_max_num = monitor_info["monitor_conf"].get("click", dict()).get("max_num", 0)
            if click_max_num > 0:
                # ��ֹ����click����ʱ���� ������Ϊ��󲻳���conf�����õ�����
                click_max_num = click_max_num if click_max_num < conf.USER_CLICK_URL_SAMPLE_MAX \
                        else conf.USER_CLICK_URL_SAMPLE_MAX
                user_click_num_dict[userid] = click_max_num
    return user_click_num_dict


def output_click_url(userid, click_url_list):
    """���������click url
    """
    for click_url in click_url_list:
        print("\t".join([userid, click_url]))


def main():
    """��ȡָ���˻��������url
    """
    user_path = sys.argv[1]
    user_max_num_dict = load_url_monitor_user(user_path)
    previous_userid = None
    click_url_sampler = None

    for line in sys.stdin:
        parts = line.strip("\n").split("\t")
        userid = parts[0]
        click_url = parts[1]
        if userid != previous_userid:
            if previous_userid is not None:
                output_click_url(previous_userid, click_url_sampler.get_sample_list())
            # ��userid��click���޲�һ��
            click_url_sampler = Sampler(user_max_num_dict[userid])
            previous_userid = userid
        click_url_sampler.put(click_url)

    if previous_userid is not None:
        output_click_url(previous_userid, click_url_sampler.get_sample_list())


if __name__ == "__main__":
    main()
