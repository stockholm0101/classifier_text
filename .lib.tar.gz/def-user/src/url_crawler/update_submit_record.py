#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/05/08 21:44:42
Desc  :   
"""
import codecs
import sys
import url_record

def main():
    """����url�ύץȡ�ļ�¼��Ϣ
    """
    url_to_be_crawled_file = sys.argv[1]
    url_record_file = sys.argv[2]
    batch_time = sys.argv[3]

    # ����ץȡ��¼��Ϣ
    url_recorder = url_record.URLRecorder()
    url_recorder.load_from_file(url_record_file)

    with codecs.open(url_to_be_crawled_file, "r", "gb18030") as rf:
        for line in rf:
            url = line.strip("\n").split("\t")[0]
            url_recorder.add_submit_record(url, batch_time)

    url_recorder.save_to_file(url_record_file)


if __name__ == "__main__":
    main()

