#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   19/05/27 20:13:36
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.merge_object as merge_object
import numpy as np


class UnitMerge(object):
    """��Ȩ����unit-->user
    """
    def __init__(self):
        """init"""
        pass
    def init(self):
        """init"""
        pass
    def merge_method(self, model_id, user_result):
        """unit merge method, һ�ּ�Ȩ���㵥Ԫ���˻��ķ���
        [in]  model_id: conf�����õ���Ҫmerge��ģ��id
        [in]  user_result: list, ÿ��Ԫ����ReviewUnitObj
        [out] ���������ǩ��ֻҪ��һ����Ԫ�ڳ��ּ��ɡ� ����û�д������������ǩ���Ͱ��� �˻��� ��Ԫ��ǩռ�� ����
        """
        merge_labels = ["1006", "1007", "1104", "2201"]
        merge_unit_result_obj = merge_object.MergeUnitResultObj()

        total_unit_num = len(user_result)
        if total_unit_num <= 0:
            return merge_unit_result_obj.convert_to_dict()

        # key: model�е�label; value: [num, idea_list, word_list]
        result = {}
        for review_unit_obj in user_result:
            # ��Ԫά��, ÿ��ģ�͵�result
            for unit_check_result in review_unit_obj.check_result:
                m_id = unit_check_result["model_id"]
                if m_id != model_id:
                    continue
                m_result = unit_check_result["model_result"]
                m_label = m_result["label"]
                m_label_name = m_result["label_name"]
                label_list = m_result["label_list"]
                try:
                    m_pro = float(m_result["label_list"][0][2])
                except:
                    continue
                if m_label not in result:
                    result[m_label] = [0, m_label_name, [], [], []]
                result[m_label][0] += 1
                result[m_label][2].append(m_pro)
                result[m_label][3].append(review_unit_obj.idea_list)
                result[m_label][4].append(review_unit_obj.word_list)

        label_list = []
        for k, v in sorted(result.items(), key = lambda d: d[1][0], reverse = True):
            [num, m_label_name, pros, idea_list, word_list] = v
            val = (num + 0.0) / total_unit_num
            val = "%.4f" % val
            label_list.append([k, m_label_name, val])

        if len(label_list) == 0:
            return merge_unit_result_obj.convert_to_dict()

        label = label_list[0][0]
        label_name = label_list[0][1]
        evidence = {}
        evidence["idea"] = result[label][3][0]
        evidence["word"] = result[label][4][0]

        if len(set(result.keys()) & set(merge_labels)) != 0:
            max_score = 0
            max_label = "0"
            for merge_label in merge_labels:
                if merge_label in result:
                    [num, m_label_name, pros, idea_list, word_list] = result[merge_label]
                    if np.max(pros) > max_score:
                        max_score = np.max(pros)
                        max_label = merge_label

            [num, m_label_name, pros, idea_list, word_list] = result[max_label]

            score  = np.max(pros)
            if score > 0.5:
                evidence["additional"] = {}
                evidence["additional"]["label"] = max_label
                evidence["additional"]["idea"] = idea_list[pros.index(score)]
                evidence["additional"]["word"] = word_list[pros.index(score)]

        merge_unit_result_obj.init(label, label_name, label_list, evidence)
        return merge_unit_result_obj.convert_to_dict()

if __name__ == "__main__":
    pass
