#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   19/12/17 17:39:59
Desc  :   
"""
import os
import sys
import random

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)

import review_object.merge_object as merge_object
import conf

class UrlMerge(object):
    """url -> user, �˻�������UrlԤ��������Ϊ�˻���ǩ, һ��url���м�Ϊ����ģ��
    """
    def __init__(self):
        """init"""
        pass

    def init(self):
        """init"""
        pass

    def merge_method(self, model_id, user_result):
        """��һ��url����ģ�;ʹ��϶�Ӧ�ı�ǩ
        [in]  model_id: ���ϲ���model_id
              user_result: list, ÿ��Ԫ����ReviewURLMonitorObj
        [out] merge_url_result_obj: dict, ģ�ͽ���ϲ���תΪdict
        """
        merge_url_result_obj = merge_object.MergeUrlResultObj()

        # key: model�е�label(0��-1�Ǹ����ǩ), value: [num, idea_list, word_list(url)]
        result = {}
        for review_url_obj in user_result:
            # url, ÿ��ģ�͵�result
            for url_check_result in review_url_obj.check_result:
                m_id = url_check_result["model_id"]
                if m_id != model_id:
                    continue
                m_result = url_check_result["model_result"]
                m_label = m_result["label"]
                m_label_name = m_result["label_name"]
                if "|" not in m_label and int(m_label) <= 0:
                    continue
                l1 = len(m_label.split("|"))
                l2 = len(m_label_name.split("|"))
                assert l1 == l2
                for i in range(0, l1):
                    if m_label[i] not in result:
                        result[m_label[i]] = [0, m_label_name[i], None, None]
                    result[m_label[i]][0] += 1
                    result[m_label[i]][2] = []
                    result[m_label[i]][3] = [review_url_obj.url]

        if len(result) == 0:
            merge_url_result_obj.label = "-1"
            return merge_url_result_obj.convert_to_dict()

        labels = "|".join(result.keys())
        labels_name = []
        label_list = []
        ideas = [str(model_id)]
        words = []
        for k in result:
            labels_name.append(result[k][1])
            ideas += result[k][2]
            words += result[k][3]
            label_list.append([k, result[k][1], str(result[k][0])])

        label_name = "|".join(labels_name)

        evidence = {}
        evidence["idea"] = ideas if len(ideas) <= conf.URL_SAMPLE_NUM else \
                random.sample(ideas, conf.URL_SAMPLE_NUM)
        evidence["word"] = words if len(words) <= conf.URL_SAMPLE_NUM else \
                random.sample(words, conf.URL_SAMPLE_NUM)
        merge_url_result_obj.init(labels, label_name, label_list, evidence)

        return merge_url_result_obj.convert_to_dict()


if __name__ == "__main__":
    pass


