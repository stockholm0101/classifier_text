#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   19/07/18 15:58:19
Desc  :   feedԤ����ֱ�Ӻϲ����˻�
"""
import os
import sys

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.merge_object as merge_object
import common.sampler as sampler

class BaseMerger(object):
    """feed ad --> user
    """
    def __init__(self):
        """init"""
        pass

    def init(self):
        """init"""
        pass

    def merge_method(self, model_id, feed_res_list):
        """merge method, �ϲ�model_id�Ľ������feed����ֱ�Ӻϲ����˻�
        [in]  model_id: ���ϲ���model_id
              feed_res_list: list, ÿ��Ԫ����ReviewFeedAdObj
        [out] merge_feed_result_obj: dict, ģ�ͺϲ���תΪdict
        """
        merge_feed_result_obj = merge_object.MergeFeedResultObj()

        total_res_num = len(feed_res_list)
        if total_res_num <= 0:
            return merge_feed_result_obj.convert_to_dict()

        # result[���ID] = (����, ���������, ����֤��)
        result = {}
        for review_feed_obj in feed_res_list:
            # ÿ��feed����ģ�͵�result
            for feed_check_result in review_feed_obj.check_result:
                m_id = feed_check_result["model_id"]
                if m_id != model_id:
                    continue
                m_result = feed_check_result["model_result"]
                m_label = m_result["label"]
                m_label_name = m_result["label_name"]
                if m_label == "0":
                    continue
                if m_label not in result:
                    result[m_label] = [0, m_label_name, sampler.Sampler(20)]
                result[m_label][2].put(review_feed_obj.text)
                result[m_label][0] += 1

        # ����merge�ķ���
        result_sort = sorted(result.items(), key=lambda x:x[1][0], reverse=True)
        label_list = [(label_id, label_name, num) for label_id, (num, label_name, _) in result_sort if num > 1]

        if len(label_list) == 0:
            return merge_feed_result_obj.convert_to_dict()

        label = label_list[0][0]
        label_name = label_list[0][1]
        evidence = {"text": result_sort[0][1][2].get_sample_list()}
        merge_feed_result_obj.init(label, label_name, label_list, evidence)
        return merge_feed_result_obj.convert_to_dict()


if __name__ == "__main__":
    pass


