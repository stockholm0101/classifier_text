#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/02/10 14:24:31
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.merge_object as merge_object
import numpy as np

class BaseMerge(object):
    """unit -> user, ������ȡtop1��Ϊ��Ԫ��ǩ, �����˻���Ԫ��ǩ��Ϊ�˻���ǩ
    """
    def __init__(self):
        """init"""
        pass

    def init(self):
        """init"""
        pass

    def merge_method(self, model_id, user_result):
        """base merge method, �ϲ�ĳ��modelid�Ľ��
        [in]  model_id: ���ϲ���model_id
              user_result: list, ÿ��Ԫ����ReviewUnitObj
        [out] merge_unit_result_obj: dict, ģ�ͽ���ϲ���תΪdict
        """
        merge_unit_result_obj = merge_object.MergeUnitResultObj()

        total_unit_num = len(user_result)
        if total_unit_num <= 0:
            return merge_unit_result_obj.convert_to_dict()

        # key: model�е�label; value: [num, label_name, idea_list, word_list, url_list]
        result = {}
        for review_unit_obj in user_result:
            # ��Ԫά��, ÿ��ģ�͵�result
            for unit_check_result in review_unit_obj.check_result:
                m_id = unit_check_result["model_id"]
                if m_id != model_id:
                    continue
                m_result = unit_check_result["model_result"]
                multi_label = m_result["label"].split("|")
                multi_label_name = m_result["label_name"].split("|")
                for index in range(len(multi_label)):
                    m_label = multi_label[index]
                    if m_label not in result:
                        result[m_label] = [0, multi_label_name[index], None, None, None]
                    result[m_label][0] += 1
                    result[m_label][2] = review_unit_obj.idea_list
                    result[m_label][3] = review_unit_obj.word_list
                    result[m_label][4] = review_unit_obj.idea_url_list

        label_list = []
        for k, v in sorted(result.items(), key = lambda d: d[1][0], reverse = True):
            [num, m_label_name, idea_list, word_list, url_list] = v
            val = (num + 0.0) / total_unit_num
            if val < 0.03:
                continue
            val = "%.4f" % val
            label_list.append([k, m_label_name, val])

        if len(label_list) == 0:
            return merge_unit_result_obj.convert_to_dict()

        # ���max_label == 0, ֻ����0��ǩ
        # ���max_label > 0, label_listȥ��0��ǩ
        label_list_sort = sorted(label_list, key = lambda x: float(x[2]), reverse = True)
        label_list = []
        max_label = int(label_list_sort[0][0])
        if max_label == 0:
            label_list.append(label_list_sort[0])
        elif max_label > 0:
            for label_info in label_list_sort:
                if int(label_info[0]) > 0:
                    label_list.append(label_info)
        else:
            label_list = label_list_sort

        label = "|".join([label_list[i][0] for i in range(len(label_list))])
        label_name = "|".join([label_list[i][1] for i in range(len(label_list))])
        evidence = {}
        evidence["idea"] = []
        evidence["word"] = []
        evidence["url"] = []
        for i in range(len(label_list)):
            m_label = label_list[i][0]
            evidence["idea"].extend(result[m_label][2])
            evidence["word"].extend(result[m_label][3])
            evidence["url"].extend(result[m_label][4])
        merge_unit_result_obj.init(label, label_name, label_list, evidence)

        return merge_unit_result_obj.convert_to_dict()

class DirMultiMerge(object):
    """unit -> user, ������ȡtop1��Ϊ��Ԫ��ǩ, �������з�0�˻���Ԫ��ǩ��Ϊ�˻���ǩ
    """
    def __init__(self):
        """init"""
        pass

    def init(self):
        """init"""
        pass

    def merge_method(self, model_id, user_result):
        """base merge method, �ϲ�ĳ��modelid�Ľ��
        [in]  model_id: ���ϲ���model_id
              user_result: list, ÿ��Ԫ����ReviewUnitObj
        [out] merge_unit_result_obj: dict, ģ�ͽ���ϲ���תΪdict
        """
        merge_unit_result_obj = merge_object.MergeUnitResultObj()

        total_unit_num = len(user_result)
        if total_unit_num <= 0:
            return merge_unit_result_obj.convert_to_dict()

        # key: model�е�label; value: [num, label_name, idea_list, word_list, url_list]
        result = {}
        for review_unit_obj in user_result:
            # ��Ԫά��, ÿ��ģ�͵�result
            for unit_check_result in review_unit_obj.check_result:
                m_id = unit_check_result["model_id"]
                if m_id != model_id:
                    continue
                m_result = unit_check_result["model_result"]
                multi_label = m_result["label"].split("|")
                multi_label_name = m_result["label_name"].split("|")
                for index in range(len(multi_label)):
                    m_label = multi_label[index]
                    if m_label not in result:
                        result[m_label] = [0, multi_label_name[index], None, None, None]
                    result[m_label][0] += 1
                    result[m_label][2] = review_unit_obj.idea_list
                    result[m_label][3] = review_unit_obj.word_list
                    result[m_label][4] = review_unit_obj.idea_url_list

        label_list = []
        for k, v in sorted(result.items(), key = lambda d: d[1][0], reverse = True):
            [num, m_label_name, idea_list, word_list, url_list] = v
            val = (num + 0.0) / total_unit_num
            if val < 0.03:
                continue
            val = "%.4f" % val
            label_list.append([k, m_label_name, val])

        if len(label_list) == 0:
            return merge_unit_result_obj.convert_to_dict()
        label_list_sort = sorted(label_list, key = lambda x: float(x[2]), reverse = True)
        label_list = []
        for label_info in label_list_sort:
            if int(label_info[0]) > 0:
                label_list.append(label_info)

        label = "|".join([label_list[i][0] for i in range(len(label_list))])
        label_name = "|".join([label_list[i][1] for i in range(len(label_list))])
        evidence = {}
        evidence["idea"] = []
        evidence["word"] = []
        evidence["url"] = []
        for i in range(len(label_list)):
            m_label = label_list[i][0]
            evidence["idea"].extend(result[m_label][2])
            evidence["word"].extend(result[m_label][3])
            evidence["url"].extend(result[m_label][4])
        merge_unit_result_obj.init(label, label_name, label_list, evidence)

        return merge_unit_result_obj.convert_to_dict()


class MultiMergeNoFilter(object):
    """unit -> user, ������ȡtop1��Ϊ��Ԫ��ǩ, �������з�0�˻���Ԫ��ǩ��Ϊ�˻���ǩ(ֻҪ��������)
    """
    def __init__(self):
        """init"""
        pass

    def init(self):
        """init"""
        pass

    def merge_method(self, model_id, user_result):
        """base merge method, �ϲ�ĳ��modelid�Ľ��
        [in]  model_id: ���ϲ���model_id
              user_result: list, ÿ��Ԫ����ReviewUnitObj
        [out] merge_unit_result_obj: dict, ģ�ͽ���ϲ���תΪdict
        """
        merge_unit_result_obj = merge_object.MergeUnitResultObj()

        total_unit_num = len(user_result)
        if total_unit_num <= 0:
            return merge_unit_result_obj.convert_to_dict()

        # key: model�е�label; value: [num, label_name, idea_list, word_list, url_list]
        result = {}
        for review_unit_obj in user_result:
            # ��Ԫά��, ÿ��ģ�͵�result
            for unit_check_result in review_unit_obj.check_result:
                m_id = unit_check_result["model_id"]
                if m_id != model_id:
                    continue
                m_result = unit_check_result["model_result"]
                multi_label = m_result["label"].split("|")
                multi_label_name = m_result["label_name"].split("|")
                for index in range(len(multi_label)):
                    m_label = multi_label[index]
                    if m_label not in result:
                        result[m_label] = [0, multi_label_name[index], None, None, None]
                    result[m_label][0] += 1
                    result[m_label][2] = review_unit_obj.idea_list
                    result[m_label][3] = review_unit_obj.word_list
                    result[m_label][4] = review_unit_obj.idea_url_list
        
        label_list = []
        for k, v in sorted(result.items(), key = lambda d: d[1][0], reverse = True):
            [num, m_label_name, idea_list, word_list, url_list] = v
            val = (num + 0.0) / total_unit_num
            val = "%.4f" % val
            label_list.append([k, m_label_name, val])

        if len(label_list) == 0:
            return merge_unit_result_obj.convert_to_dict()
        label_list_sort = sorted(label_list, key = lambda x: float(x[2]), reverse = True)
        label_list = []
        for label_info in label_list_sort:
            if int(label_info[0]) > 0:
                label_list.append(label_info)

        label = "|".join([label_list[i][0] for i in range(len(label_list))])
        label_name = "|".join([label_list[i][1] for i in range(len(label_list))])
        evidence = {}
        evidence["idea"] = []
        evidence["word"] = []
        evidence["url"] = []
        for i in range(len(label_list)):
            m_label = label_list[i][0]
            evidence["idea"].extend(result[m_label][2])
            evidence["word"].extend(result[m_label][3])
            evidence["url"].extend(result[m_label][4])
        merge_unit_result_obj.init(label, label_name, label_list, evidence)

        return merge_unit_result_obj.convert_to_dict()

if __name__ == "__main__":
    pass
