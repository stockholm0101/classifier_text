#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/07/18 15:58:19
Desc  :   ���Ԥ����ֱ�Ӻϲ����˻�
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.merge_object as merge_object
import numpy as np

class ClickMerger(object):
    """click --> user
    """
    def __init__(self):
        """init"""
        pass

    def init(self):
        """init"""
        pass

    def merge_method(self, model_id, click_res_list):
        """merge method, �ϲ�model_id�Ľ�����ɵ��ֱ�Ӻϲ����˻�
        [in]  model_id: ���ϲ���model_id
              click_res_list: list, ÿ��Ԫ����ReviewClickObj
        [out] merge_click_result_obj: dict, ģ�ͺϲ���תΪdict
        """
        merge_click_result_obj = merge_object.MergeClickResultObj()

        total_res_num = len(click_res_list)
        if total_res_num <= 0:
            return merge_click_result_obj.convert_to_dict()

        result = {}
        for review_click_obj in click_res_list:
            # ÿ�����ģ�͵�result
            for click_check_result in review_click_obj.check_result:
                m_id = click_check_result["model_id"]
                if m_id != model_id:
                    continue
                m_result = click_check_result["model_result"]
                m_label = m_result["label"]
                m_label_name = m_result["label_name"]
                if m_label in ["2", "3", "4"] and len(m_result["label_list"]) > 0 and \
                        float(m_result["label_list"][0][2]) > 0.5:
                    if "1" not in result:
                        result["1"] = [0, u"�⽨����", None, None]
                    result["1"][0] += 1
                    result["1"][2] = [",".join(review_click_obj.text.split(",")[1:])]
                    result["1"][3] = [review_click_obj.text.split(",")[0]]
                else:
                    if "0" not in result:
                        result["0"] = [0, u"�Ƿ⽨����", None, None]
                    result["0"][0] += 1
                    result["0"][2] = [",".join(review_click_obj.text.split(",")[1:])]
                    result["0"][3] = [review_click_obj.text.split(",")[0]]

        label_list = []
        for k, v in sorted(result.items(), key = lambda d: d[1][0], reverse = True):
            [num, m_label_name, idea_list, word_list] = v
            val = (num + 0.0) / total_res_num
            if val < 0.03:
                continue
            val = "%.4f" % val
            label_list.append([k, m_label_name, val])

        if len(label_list) == 0:
            return merge_click_result_obj.convert_to_dict()

        label = label_list[0][0]
        label_name = label_list[0][1]
        evidence = {}
        evidence["idea"] = result[label][2]
        evidence["word"] = result[label][3]
        merge_click_result_obj.init(label, label_name, label_list, evidence)
        return merge_click_result_obj.convert_to_dict()


if __name__ == "__main__":
    pass


