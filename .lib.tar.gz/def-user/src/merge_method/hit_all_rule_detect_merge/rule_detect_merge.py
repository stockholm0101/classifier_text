#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   19/10/12 16:16:24
Desc  :   
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os
import collections

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)

import review_object.merge_object as merge_object
import review_object.review_object as review_object

class RuleMerger(object):
    """����ά�ȵĹ��������ϲ�, �����Ϻϲ�����Ԫ, �ӵ�Ԫ�ϲ����˻�
    """
    def __init__(self):
        """init"""
        pass

    def merge_method(self, model_id, ad_res_list):
        """
        ����(ֻ��ע����һ������)�ϲ�ʱ, ��ע�����label_list, ����עʵ�ʸ�����label
        [in]  ad_res_list: �б�, ÿ��Ԫ����review_object.ReviewAdObj
        [out] merge_ad_result_obj : merge_object.MergeAdResultObj
        ��Ԫ�ϲ�ʱ
        [in]  ad_res_list: �б�, ÿ��Ԫ����review_object.ReviewUnitObj
        [out] merge_unit_result_obj : merge_object.MergeUnitResultObj
        ������Ϻϲ�ʱ, �������ֱ�Ӻϲ���userά��
        [in]  ad_res_list: �б�, ÿ��Ԫ����review_object.ReviewClickAdObj
        [out] merge_click_result_obj : merge_object.MergeClickResultObj
        Ϊͳһ�ϲ���������ͳһʹ��merge_object.MergeResultObj
        """
        merge_result_obj = merge_object.MergeResultObj()

        if len(ad_res_list) <= 0:
            return merge_result_obj.convert_to_dict()

        hit_count = collections.defaultdict(int)
        # �ϲ�����Ԫ�������Ϻϲ����˻�, ֤�����ݲ�һ��
        is_unit_obj_or_click_obj = 0

        # ֤��, ֤�ݸ������еı�ǩ
        evidence = {"idea": [], "word": [], "idea_url": [], "word_url": []}
        # ֤�ݸ��ǵı�ǩ
        evidence_labels = set()

        # �ϲ������Ͻ��
        for ad_review_res in ad_res_list:
            if isinstance(ad_review_res, review_object.ReviewUnitObj):
                is_unit_obj_or_click_obj = 1
            elif isinstance(ad_review_res, review_object.ReviewClickAdObj) or \
                    isinstance(ad_review_res, review_object.ReviewFeedAdObj):
                is_unit_obj_or_click_obj = 2

            # �������ϵ�ģ�ͽ��
            for check_result in ad_review_res.check_result:
                m_id = check_result["model_id"]
                if m_id != model_id:
                    continue
                m_result = check_result["model_result"]
                m_label = m_result["label"]
                if "|" not in m_label and int(m_label) < 0:
                    continue

                # ֤��
                if is_unit_obj_or_click_obj == 1:
                    for l in m_label.split("|"):
                        if l not in evidence_labels:
                            evidence["idea"].append(ad_review_res.idea_list)
                            evidence["word"].append(ad_review_res.word_list)
                            evidence["idea_url"].append(ad_review_res.idea_url_list)
                            evidence["word_url"].append(ad_review_res.word_url_list)
                            evidence_labels.add(l)
                elif is_unit_obj_or_click_obj == 2:
                    for l in m_label.split("|"):
                        if l not in evidence_labels:
                            evidence["idea"].append(ad_review_res.text)
                            evidence["idea_url"].append(ad_review_res.url)
                            evidence_labels.add(l)

                # ��ǩ
                m_label_name = m_result["label_name"]
                m_label_list = m_result["label_list"]
                for item in m_label_list:
                    [label, label_name, count] = item
                    k = "%s\t%s" % (label, label_name)
                    hit_count[k] += count

        label_list = []
        for k, v in sorted(hit_count.items(), key = lambda d:d[1], reverse = True):
            label_list.append(k.split("\t") + [v])

        if len(label_list) == 0:
            merge_result_obj.label = "-10"
            merge_result_obj.label_name = u"δ����"
            return merge_result_obj.convert_to_dict()

        merge_result_obj.label = "|".join([x[0] for x in label_list])
        merge_result_obj.label_name = "|".join([x[1] for x in label_list])
        merge_result_obj.label_list = label_list
        merge_result_obj.evidence = evidence
        return merge_result_obj.convert_to_dict()


if __name__ == "__main__":
    pass
