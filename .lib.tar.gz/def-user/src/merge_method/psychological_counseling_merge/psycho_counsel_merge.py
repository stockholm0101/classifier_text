#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: psycho_counsel_merge.py
Author: workliu(workliu@baidu.com)
Date: 2020/03/12 15:03:26
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os
import collections

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)

import review_object.merge_object as merge_object
import review_object.review_object as review_object

class PsychoMerge(object):
    """����ά�ȵ�������ѯ����ϲ�, �����Ϻϲ�����Ԫ, �ӵ�Ԫ�ϲ����˻�
    """
    def __init__(self):
        """init"""
        pass

    def merge_method(self, model_id, ad_res_list):
        """
        ���Ϻϲ�ʱ, ��ע�����label, label_name, ����עʵ�ʸ�����label_list
        [in]  ad_res_list: �б�, ÿ��Ԫ����review_object.ReviewAdObj
        [out] merge_object.MergeResultObj
        ��Ԫ�ϲ�ʱ
        [in]  ad_res_list: �б�, ÿ��Ԫ����review_object.ReviewUnitObj
        [out] merge_object.MergeResultObj
        ������Ϻϲ�ʱ, �������ֱ�Ӻϲ���userά��
        [in]  ad_res_list: �б�, ÿ��Ԫ����review_object.ReviewClickAdObj
        [out] merge_object.MergeResultObj
        Ϊͳһ�ϲ���������ͳһʹ��merge_object.MergeResultObj
        """
        merge_result_obj = merge_object.MergeResultObj()

        if len(ad_res_list) <= 0:
            return merge_result_obj.convert_to_dict()

        hit_count = collections.defaultdict(int)
        # �ϲ�����Ԫ�������Ϻϲ����˻�, ֤�����ݲ�һ��
        is_unit_obj_or_click_obj = 0

        # ֤��, ֤�ݸ������еı�ǩ
        evidence = {"idea": [], "word": []}
        # ֤�ݸ��ǵı�ǩ
        evidence_labels = set()

        # �ϲ������Ͻ��
        for ad_review_res in ad_res_list:
            if isinstance(ad_review_res, review_object.ReviewUnitObj):
                is_unit_obj_or_click_obj = 1
            elif isinstance(ad_review_res, review_object.ReviewClickAdObj):
                is_unit_obj_or_click_obj = 2
                # ���ݵ��

            # �������ϵ�ģ�ͽ��
            for check_result in ad_review_res.check_result:
                m_id = check_result["model_id"]
                if m_id != model_id:
                    continue
                m_result = check_result["model_result"]
                m_label = m_result["label"]
                if "|" not in str(m_label) and int(m_label) < 0:
                    continue

                # ֤��
                if is_unit_obj_or_click_obj == 1:
                    for l in m_label.split("|"):
                        if l not in evidence_labels:
                            evidence["idea"].extend(ad_review_res.idea_list)
                            evidence["word"].extend(ad_review_res.word_list)
                            evidence_labels.add(l)
                elif is_unit_obj_or_click_obj == 2:
                    if str(m_label) not in evidence_labels:
                        evidence["idea"].extend(ad_review_res.text)
                        evidence_labels.add(str(m_label))

                # ��ǩ
                # ad����, ͬʱ���ݵ��
                is_ad_or_click = (is_unit_obj_or_click_obj == 2 or is_unit_obj_or_click_obj == 0)
                if "|" not in str(m_label) and 0 <= int(m_label) and is_ad_or_click:
                    label = m_label
                    label_name = m_result["label_name"]
                    k = "%s\t%s" % (str(label), label_name)
                    hit_count[k] += 1
                else:
                    #��Ԫ
                    m_label_list = m_result["label_list"]
                    for item in m_label_list:
                        [label, label_name, count] = item
                        k = "%s\t%s" % (str(label), label_name)
                        hit_count[k] += int(count)

        label_list = []
        for k, v in sorted(hit_count.items(), key = lambda d:d[1], reverse = True):
            label_list.append(k.split("\t") + [str(v)])

        if len(label_list) == 0:
            return merge_result_obj.convert_to_dict()

        merge_result_obj.label = "|".join([x[0] for x in label_list])
        merge_result_obj.label_name = "|".join([x[1] for x in label_list])
        merge_result_obj.label_list = label_list
        merge_result_obj.evidence = evidence
        return merge_result_obj.convert_to_dict()


if __name__ == "__main__":
    pass
