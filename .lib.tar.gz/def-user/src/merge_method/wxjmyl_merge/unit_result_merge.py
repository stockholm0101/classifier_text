#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   19/06/27 17:54:32
Desc  :   
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.merge_object as merge_object

class TradeUnitResultMerge(object):
    """merge unit result
    """
    def __init__(self):
        """init"""
        # ��Ԫ��ǩռ����ֵ
        self.unit_percent = 0.2
        # ��Ԫ��ǩ������
        self.unit_num = 10
        # Ĭ�ϱ�ǩlabel
        self.default_label = "-1"
        # Ĭ�ϱ�ǩ��
        self.default_label_name = u"������ҵ"

    def init(self):
        """init"""
        pass

    def merge_method(self, model_id, user_result):
        """�˻��µ�ԪԤ��label, ռ�ȴ�����ֵunit_percent, ��������������ֵunit_num, 
           ��Ϊ�˻��ж�Ӧ��ǩ, ֤��ѡtop3��ǩ�е�����
        [in]  model_id: ��merge��ģ��id
              user_result: list, ÿ��Ԫ����ReviewUnitObj
        [out] merge_unit_result_obj: �˻������е�Ԫ�ĺϲ����
        """
        merge_unit_result_obj = merge_object.MergeUnitResultObj()

        total_unit_num = len(user_result)
        if total_unit_num <= 0:
            return merge_unit_result_obj.convert_to_dict()

        # key: model�е�label; value: [num, idea_list, word_list]
        result = {}
        for review_unit_obj in user_result:
            # ��Ԫά��, ÿ��ģ�͵�result
            for unit_check_result in review_unit_obj.check_result:
                m_id = unit_check_result["model_id"]
                if m_id != model_id:
                    continue
                m_result = unit_check_result["model_result"]
                m_label = m_result["label"]
                m_label_name = m_result["label_name"]
                m_label_list = m_result["label_list"]

                if m_label not in result:
                    result[m_label] = [0, m_label_name, None, None]
                result[m_label][0] += 1
                result[m_label][2] = review_unit_obj.idea_list
                result[m_label][3] = review_unit_obj.word_list

        label_list = []
        default_label_list = []
        for k, v in sorted(result.items(), key = lambda d: d[1][0], reverse = True):
            [num, m_label_name, idea_list, word_list] = v
            val = (num + 0.0) / total_unit_num
            if num > self.unit_num or val > self.unit_percent:
                val = "%.4f" % val
                if k == self.default_label:
                    default_label_list.append([k, m_label_name, val, str(num)])
                else:
                    label_list.append([k, m_label_name, val, str(num)])

        if len(label_list) + len(default_label_list) == 0:
            return merge_unit_result_obj.convert_to_dict()

        label = [self.default_label]
        label_name = [self.default_label_name]
        evidence = {}
        evidence_num = 0
        if len(label_list) > 0:
            label = []
            label_name = []
            for item in label_list:
                label.append(item[0])
                label_name.append(item[1])
                if evidence_num < 3:
                    evidence["idea"] = evidence.get("idea", []) + result[item[0]][2]
                    evidence["word"] = evidence.get("word", []) + result[item[0]][3]
                    evidence_num += 1
        else:
            evidence["idea"] = result[self.default_label][2]
            evidence["word"] = result[self.default_label][3]

        merge_unit_result_obj.init("|".join(label), 
                "|".join(label_name), 
                label_list + default_label_list, 
                evidence)

        return merge_unit_result_obj.convert_to_dict()


if __name__ == "__main__":
    pass
