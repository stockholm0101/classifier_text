#!/usr/bin/env python
# -*- coding: gbk -*-
 
"""
Author:   zhanghao55@baidu.com
Date  :   19/05/06 16:55:19
DESC  :   ά����ҵ��ð�ٷ�����ʶ��
"""

import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.merge_object as merge_object

class FakeRepairUnitResultMerge(object):
    """��ά����ҵ��ð�ٷ��ĵ�Ԫʶ�������ܵ��û�
    """
    def __init__(self):
        """init"""
        self.evidence_numer = 10
        pass

    def init(self):
        pass

    def merge_method(self, model_id, user_result):
        """ֻҪ��һ�����յ�Ԫ�����û���Ϊ�����û���֤�����ϱ���������ߵĵ�Ԫ��
        [in]  user_result: list, ÿ��Ԫ����ReviewUnitObj
        [out]
        """
        merge_unit_result_obj = merge_object.MergeUnitResultObj()

        total_unit_num = len(user_result)
        if total_unit_num <= 0:
            return merge_unit_result_obj.convert_to_dict()

        # key: model�е�label; value: [num, label_name, idea_list, word_list, idea_risk_evidence, word_risk_evidence, max_risk_ratio]
        result = {}
        risk_unit_info = list()
        brand_detected_set = set()
        check_result_num = 0 
        for review_unit_obj in user_result:
            # ��Ԫά��, ÿ��ģ�͵�result
            for unit_check_result in review_unit_obj.check_result:
                m_id = unit_check_result["model_id"]
                if m_id != model_id:
                    continue
                m_result = unit_check_result["model_result"]
                m_label = m_result["label"]
                if m_label == "-100":
                    continue
                check_result_num += 1
                if m_label != "2":
                    continue
                m_label_name = m_result["label_name"]
                m_opt_info = m_result["opt"]
                m_risk_ratio = float(m_opt_info["high_risk_ratio"])
                brand_detected_set.update(m_opt_info["brand_detected"].split("\x01"))
                if m_label not in result:
                    result[m_label] = [0, m_label_name, None, None, None, None, 0]
                result[m_label][0] += 1
                # չ�ַ�����ߵ�unit�Ĺؼ��ʺʹ�����Ϣ
                if result[m_label][5] < m_risk_ratio:
                    result[m_label][2] = review_unit_obj.idea_list
                    result[m_label][3] = review_unit_obj.word_list
                    result[m_label][4] = m_opt_info["idea_risk_evidence"]
                    result[m_label][5] = m_opt_info["word_risk_evidence"]
                    result[m_label][6] = m_risk_ratio
                risk_unit_info.append([review_unit_obj.unitid,m_label,m_risk_ratio])


        label_list = []
        for k, v in sorted(result.items(), key = lambda d: d[1][0], reverse = True):
            [num, m_label_name, idea_list, word_list, idea_risk_evidence, word_risk_evidence, max_risk_ratio] = v
            val = (num + 0.0) / total_unit_num
            val = "%.4f" % val
            label_list.append([k, m_label_name, val])

        # ������û�û�м����ĵ�Ԫ ��˵��ģ��û�м����û�
        if  check_result_num == 0: 
            return merge_unit_result_obj.convert_to_dict()


        # ֻ��labelΪ2�Ĳ��������ط��յ� ���û��labelΪ2�� ���޷���
        if "2" not in result:
            label = "0"
            label_name =  u"���˻������ط�ð�ٷ�����"
            merge_unit_result_obj.init(label,label_name,[],{})
            return merge_unit_result_obj.convert_to_dict()

        # ������ ˵����labelΪ2�ĵ�Ԫ
        label = "2"
        label_name = u"���˻������ط�ð�ٷ�����"
        #label = label_list[0][0]
        #label_name = label_list[0][1]
        evidence = {}
        # �����մӴ�Сչ�ָ��û����з���unitid
        evidence["risk_info"] = [ "%s(%s:%.4f)"%(unitid,m_label,risk_ratio) for (unitid,m_label,risk_ratio) in sorted(risk_unit_info,key=lambda x:x[2],reverse=True) if m_label == "2"][:self.evidence_numer]
        evidence["brand_detected"] = "\x01".join(list(brand_detected_set)[:self.evidence_numer])
        evidence["brand_detected_num"] = len(brand_detected_set)
        evidence["idea"] = result[label][2]
        evidence["word"] = result[label][3]
        evidence["idea_risk_evidence"] = result[label][4]
        evidence["word_risk_evidence"] = result[label][5]
        evidence["max_risk_ratio"] = result[label][6]
        merge_unit_result_obj.init(label, label_name, label_list, evidence)

        return merge_unit_result_obj.convert_to_dict()


if __name__ == "__main__":
    pass
