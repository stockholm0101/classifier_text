#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/05/19 20:42:38
Desc  :   
"""
import os
import sys

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)

import review_object.merge_object as merge_object


class CatchFishInconsistentMerge(object):
    """url -> user, ֻҪ��һ��url��һ������˻����Ϻ�ע��ҳ��һ��
    ע�⣺��ģ��ֻʶ���˻����Ϻ���ע��ҳ����ע��ҳ�����ж��ʱ���ץȡ�����������Ҫmerge
    """
    def __init__(self):
        """init"""
        self.tar_label_id = u"1"
        self.exclude_label_set = set(["0", "-100"])

    def merge_method(self, model_id, url_res_list):
        """�ϲ����˻�����ע��ҳ�Ƿ�һ�µĽ��
        [in]  model_id: ���ϲ���model_id
              url_res_list: list, ÿ��Ԫ����ReviewURLMonitorObj
        [out] merge_url_monitor_result_obj: dict, ģ�ͽ���ϲ���תΪdict
        """
        merge_url_monitor_result_obj = merge_object.MergeURLMonitorResultObj()

        total_url_num = len(url_res_list)
        if total_url_num <= 0:
            return merge_url_monitor_result_obj.convert_to_dict()

        # label_dict[label] = [count, label_name, latest_timestamp, evidence_dict]
        label_dict = dict()
        for review_url_monitor_obj in url_res_list:
            # ��Ԫά��, ÿ��ģ�͵�result
            for check_result in review_url_monitor_obj.check_result:
                if check_result["model_id"] != model_id:
                    continue
                m_result = check_result["model_result"]
                m_label = m_result["label"]
                if m_label in self.exclude_label_set:
                    continue
                if m_label not in label_dict:
                    m_label_name = m_result["label_name"]
                    label_dict[m_label] = [0, m_label_name, 0, dict()]
                label_info = label_dict[m_label]
                label_info[0] += 1
                # ����ʱ��Խ����
                if review_url_monitor_obj.timestamp > label_info[2]:
                    label_info[2] = review_url_monitor_obj.timestamp
                    label_info[3] = m_result["opt"]

        label_list = []
        for k, v in sorted(label_dict.items(), key = lambda d: d[1][0], reverse = True):
            count, label_name, _, _ = v
            val = (count + 0.0) / total_url_num
            if val < 1e-5:
                continue
            val = "%.4f" % val
            label_list.append([k, label_name, val])

        if self.tar_label_id not in label_dict:
            return merge_url_monitor_result_obj.convert_to_dict()

        label = self.tar_label_id
        label_info = label_dict[self.tar_label_id]
        count, label_name, latest_timestamp, evidence_dict = label_info
        evidence_dict["timestamp"] = latest_timestamp
        merge_url_monitor_result_obj.init(label, label_name, label_list, evidence_dict)

        return merge_url_monitor_result_obj.convert_to_dict()
