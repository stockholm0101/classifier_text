#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/12/05 15:28:09
DESC  :   �������²���def-user
"""
import os
import re
import sys

import datetime
import argparse

######################################################################
#################### ���²�������,�ڴ����ú����Ƿ�ִ�� ###############
# ִ��˳��
exe_dict = {
    "all": [
            "init_dirs",
            "del_files",
            "get_files",
            "check_data",
            "tar_all_package",
            "upload_tar_package_1_shaolin_fengkong-galaxy-online_normal",
            "process_idea_1_shaolin_fengkong-patrol-online_normal",
            "process_word_1_shaolin_fengkong-patrol-online_normal",
            "sample_idea_kw_by_user_1_shaolin_fengkong-patrol-online_normal",
            "sample_idea_kw_by_unit_1_shaolin_fengkong-patrol-online_normal",
            "predict_trade_ad_1_shaolin_fengkong-patrol-online_normal",
            "append_trade_ad_1_shaolin_fengkong-galaxy-online_normal",
            "merge_trade_ad_1_shaolin_fengkong-galaxy-online_normal",
            "predict_trade_unit_1_shaolin_fengkong-patrol-online_normal",
            "append_trade_unit_1_shaolin_fengkong-patrol-online_normal",
            "merge_trade_unit_1_shaolin_fengkong-patrol-online_normal",
            "predict_trade_user_1_shaolin_fengkong-galaxy-online_normal",
            "append_trade_user_1_shaolin_fengkong-patrol-online_normal",
            "other_audit_result_1_shaolin_fengkong-galaxy-online_normal",
            "meteor_audit_result_1_shaolin_fengkong-patrol-online_normal",
            "merge_ad_unit_user_1_shaolin_fengkong-patrol-online_normal",
            "add_user_info_1_shaolin_fengkong-patrol-online_normal",
            "service_filter_1_shaolin_fengkong-patrol-online_normal",
            "service_filter_hit_record_1_shaolin_fengkong-patrol-online_normal",
            "send_risk",
            ],
    "click": [
            "init_dirs",
            "del_click_files",
            "get_files",
            "tar_all_package",
            "upload_tar_package_1_shaolin_fengkong-galaxy-online_normal",
            "process_click_1_shaolin_fengkong-galaxy-online_normal",
            "process_meteor_1_shaolin_fengkong-patrol-online_normal",
            "process_lppb_1_shaolin_fengkong-galaxy-online_normal",
            "sample_click_by_user_1_shaolin_fengkong-patrol-online_normal",
            "predict_trade_click_ad_1_shaolin_fengkong-galaxy-online_normal",
            "predict_trade_meteor_ad_1_shaolin_fengkong-galaxy-online_normal",
            "append_trade_click_ad_1_shaolin_fengkong-galaxy-online_normal",
            "append_trade_meteor_ad_1_shaolin_fengkong-galaxy-online_normal",
            "merge_trade_click_ad_1_shaolin_fengkong-galaxy-online_normal",
            "merge_trade_meteor_ad_1_shaolin_fengkong-galaxy-online_normal",
            "predict_trade_click_user_1_shaolin_fengkong-patrol-online_normal",
            "append_trade_click_user_1_shaolin_fengkong-patrol-online_normal",
            "merge_click_ad_user_1_shaolin_fengkong-galaxy-online_normal",
            "add_user_info_1_shaolin_fengkong-galaxy-online_normal",
            "service_filter_1_shaolin_fengkong-galaxy-online_normal",
            "service_filter_hit_record_1_shaolin_fengkong-galaxy-online_normal",
            #"send_risk",
            ],
    "feed": [
            "init_dirs",
            "del_feed_files",
            "get_files",
            "tar_all_package",
            "upload_tar_package_1_shaolin_fengkong-patrol-online_normal",
            "process_feed_1_shaolin_fengkong-patrol-online_normal",
            "predict_trade_feed_ad_1_shaolin_fengkong-patrol-online_normal",
            "append_trade_feed_ad_1_shaolin_fengkong-patrol-online_normal",
            "merge_trade_feed_ad_1_shaolin_fengkong-patrol-online_normal",
            "sample_feed_by_user_1_shaolin_fengkong-patrol-online_normal",
            "predict_trade_feed_user_1_shaolin_fengkong-patrol-online_normal",
            "append_trade_feed_user_1_shaolin_fengkong-patrol-online_normal",
            "merge_feed_ad_user_1_shaolin_fengkong-patrol-online_normal",
            "add_user_info_1_shaolin_fengkong-patrol-online_normal",
            "service_filter_1_shaolin_fengkong-patrol-online_normal",
            "service_filter_hit_record_1_shaolin_fengkong-patrol-online_normal",
            "service_filter_hit_offline_1_shaolin_fengkong-patrol-online_normal",
            #"send_risk",
            ],
    "feed_all": [
            "init_dirs",
            "del_feed_all_files",
            "get_files",
            "tar_all_package",
            "upload_tar_package_1_shaolin_fengkong-patrol-online_normal",
            "process_feed_idea_1_shaolin_fengkong-patrol-online_normal",
            "predict_trade_feed_idea_ad_1_shaolin_fengkong-patrol-online_normal",
            "append_trade_feed_idea_ad_1_shaolin_fengkong-patrol-online_normal",
            "merge_trade_feed_idea_ad_1_shaolin_fengkong-patrol-online_normal",
            "sample_feed_idea_by_unit_1_shaolin_fengkong-patrol-online_normal",
            "sample_feed_idea_by_user_1_shaolin_fengkong-patrol-online_normal",
            "predict_trade_feed_unit_1_shaolin_fengkong-patrol-online_normal",
            "append_trade_feed_unit_1_shaolin_fengkong-patrol-online_normal",
            "merge_trade_feed_unit_1_shaolin_fengkong-patrol-online_normal",
            "predict_trade_feed_idea_user_1_shaolin_fengkong-patrol-online_normal",
            "append_trade_feed_idea_user_1_shaolin_fengkong-patrol-online_normal",
            "merge_feed_ad_unit_user_1_shaolin_fengkong-patrol-online_normal",
            "add_user_info_1_shaolin_fengkong-patrol-online_normal",
            "service_filter_1_shaolin_fengkong-patrol-online_normal",
            "service_filter_hit_record_1_shaolin_fengkong-patrol-online_normal",
            #"send_risk",
            ],
    }

local_exe_set = set([
    "init_dirs",
    "get_files",
    "del_files",
    "del_feed_files",
    "del_feed_all_files",
    "del_click_files",
    "check_data",
    "tar_all_package",
    "send_risk",
    ])

######################################################################

class OfflineRunner(object):
    """����ִ�нű�
    """
    def __init__(self):
        """��ʼ��
        """
        # ���в�������
        self.args = self.parse_args()
        # ͳһִ������
        self.cmd_format = """
            python ./src/main.py \
                    --today={today} \
                    --time={time} \
                    --task_config_file={task_config_file} \
                    --exe_type={exe_type} \
                    --cluster={cluster} \
                    --queue={queue} \
                    --{func_name}
        """
        
        # ��������
        self.base_val = {"today": self.args.today, "time": self.args.time, \
                "task_config_file": "offline_conf_task.sh", "exe_type": self.args.exe_type}
        
        # ִ������ģʽ
        self.command_pattern = re.compile(r'(?P<func_name>.*)_\d+_(?P<cluster>(khan|mulan|shaolin))_' \
                '(?P<queue>(fengkong-patrol-online_normal|fengkong-galaxy-online_normal|fengkong|galaxy|spark-fengkong-batch))')

        # ����ʱ��Ҫ���ֵ�
        # self.to_hour_dict[ִ������]=ʱ���Ƿ�ȷ��Сʱ
        self.to_hour_dict = {
                "all": False,
                "click": True,
                "feed": True,
                "feed_all": True,
                }

    def parse_args(self):
        """�������в���
        ����: 1. ����/��� 2. today 3. time
        """
        parser = argparse.ArgumentParser(description = "def_user")
        parser.add_argument("-type", "--exe_type", \
                help = "def-user����Դ������ or ���/����/LP or FEED", \
                choices = exe_dict.keys(), \
                default = "all", \
                required = True)
        
        default_date = (datetime.datetime.now() + datetime.timedelta(days=0)).strftime("%Y%m%d")
        #default_time = (datetime.datetime.now() + datetime.timedelta(days=0)).strftime("%Y%m%d%H")
        default_time = (datetime.datetime.now() + datetime.timedelta(days=0)).strftime("%Y%m%d")
        parser.add_argument("--today", \
                help = "conf�е�TODAY", \
                default = default_date)
        
        parser.add_argument("--time", \
                help = "conf�е�TIME", \
                default = default_time)
        return parser.parse_args()

    def get_command(self, command_name):
        """������ȷ����ִ�в���
           ���Ƹ�ʽ:${������}_${ģ�ͷ���}_${��Ⱥ��}_${������}
           ע�⣺ģ�ͷ��������ͣ���Ⱥ��'mulan'��'khan'��ѡһ��
                 ������'fengkong'��'galaxy'��'spark-fengkong-batch'ѡһ
        """
        if command_name in local_exe_set:
            # ����Ǳ������е����� ���Ǹ����Ƹ�ʽ
            return self.cmd_format.format(**dict({
                "func_name": command_name,
                "cluster": "shaolin",
                "queue": "fengkong-galaxy-online_normal"}, **self.base_val))

        # ������밴�����Ƹ�ʽ��д
        # ��������д����Ⱥ�Ͷ���
        res = re.match(self.command_pattern, command_name)
        if res is None:
        #    # ˵����������������ûд������顢��Ⱥ���������� ������Щ��ȡĬ��ֵ
            raise ValueError("unknown command")
    
        res_dict = res.groupdict()
        print("func_name: %s, cluster: %s, queue: %s" % (res_dict["func_name"], res_dict["cluster"], res_dict["queue"]))
        return self.cmd_format.format(**dict({
                "func_name": res_dict["func_name"],
                "cluster": res_dict["cluster"],
                "queue": res_dict["queue"]}, **self.base_val))

    def os_system(self, command):
        """ִ�н��״̬
        """
        ret = os.system(command)
        if ret != 0:
            sys.exit(1)
    
    def validate_time(self, date_text, to_hour=False):
        """������֤ʱ���ַ����Ƿ�Ϲ�
        """
        try:
            if to_hour:
                datetime.datetime.strptime(date_text, '%Y%m%d%H')
                assert len(date_text) == 10
            else:
                datetime.datetime.strptime(date_text, '%Y%m%d')
                assert len(date_text) == 8
        except ValueError:
            raise ValueError("Incorrect data format")

    def run(self):
        """����ִ�������
        """
        to_hour = self.to_hour_dict[self.args.exe_type]
        self.validate_time(self.args.today)
        self.validate_time(self.args.time, to_hour)
        for cmd in exe_dict[self.args.exe_type]:
            print("exe: %s" % cmd)
            self.os_system(self.get_command(cmd))


if __name__ == "__main__":
    runner = OfflineRunner()
    runner.run()

