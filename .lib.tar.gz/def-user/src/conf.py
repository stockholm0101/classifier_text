#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   19/03/20 17:06:54
Desc  :   ģ�͡�ҵ������
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")

# �û���Ԫ����merge
USER_UNIT_SAMPLE_NUM = 10000

# def-userģ��ģ��
MODEL_TYPE_AD = 1
MODEL_TYPE_UNIT = 2
MODEL_TYPE_USER = 3
MODEL_TYPE_METEOR = 4
MODEL_TYPE_OTHER = 5
MODEL_TYPE_CLICK_AD = 6
MODEL_TYPE_CLICK_USER = 7
MODEL_TYPE_LP = 8
MODEL_TYPE_METEOR_AD = 9
MODEL_TYPE_URL = 10
MODEL_TYPE_FEED_AD = 11
MODEL_TYPE_FEED_USER = 12
MODEL_TYPE_URL_MONITOR = 13
MODEL_TYPE_URL_CONTINUOUS_MONITOR = 14
MODEL_TYPE_FEED_IDEA_UNIT = 15 #feed������Ԫ����
MODEL_TYPE_FEED_IDEA_USER = 16 #feed�����û�����
MODEL_TYPE_FEED_IDEA_AD =   17 #feed������������

# userά��ģ��ȡ֤����
USER_WORD_EVIDENCE_NUM = 20
USER_IDEA_EVIDENCE_NUM = 5

# def-userҵ��ģ��
QUALIFICATION = 1
RISK_USER = 2

# def-user����ģ��
SUPERVISE = 1
AUDIT = 2
EMAIL = 3
URL_MONITOR = 4
SEND_HDFS = 5

# URL_MONITOR�˻���Ҫץȡ��URL��Χ
CDC_URL = "cdc"
CLICK_URL = "click"
PC_URL = "pc"
WISE_URL = "wise"
WORD_URL = "word"
EVIDENCE_URL = "evidence"

# URL�������
LOCAL_CRAWL = "local"
OFFSITE_CRAWL = "offsite"
SNAPSHOT = "snapshot"

DEFAULT_MONITOR_CONF = {
    EVIDENCE_URL: {
        "monitor_type": [LOCAL_CRAWL, OFFSITE_CRAWL, SNAPSHOT],
        },
    CLICK_URL: {
        "monitor_type": [OFFSITE_CRAWL],
        },
    CDC_URL: {
        "max_num": 1,
        "hour_interval": 12,
        "monitor_type": [LOCAL_CRAWL],
        },
    PC_URL: {
        "max_num": 10,
        },
    WISE_URL: {
        "max_num": 10,
        },
    WORD_URL: {
        "max_num": 10,
        },
    "base_conf": {
        "max_num": 100,
        "hour_interval": 1,
        "monitor_type": [LOCAL_CRAWL],
        }
    }


# AD���ϵ�����
IDEA = 1
WORD = 2

#���������������

# ��Ԫά�ȳ�������
IDEA_SAMPLE_BY_UNIT_NUM = 3
WORD_SAMPLE_BY_UNIT_NUM = 20
FEED_IDEA_SAMPLE_BY_UNIT_NUM = 3

# �˻�ά�ȳ�������
IDEA_SAMPLE_BY_USER_NUM = 50
WORD_SAMPLE_BY_USER_NUM = 800

# ��������˻�ά�ȳ�������
IDEA_SAMPLE_BY_CLICK_NUM = 3
WORD_SAMPLE_BY_CLICK_NUM = 20

# feed��������˻�ά�ȳ���
FEED_SAMPLE_BY_USER_NUM = 10

# feed���������˻�ά�ȳ���
FEED_IDEA_SAMPLE_BY_USER_NUM = 50

# urlά��֤�ݳ�����
URL_SAMPLE_NUM = 3

# ÿ����˽���ץȡ��URL������
LATEST_URL_CRAWLED_MAX_NUM = 10000

# ÿ���ύ���ץȡ��URL������
LATEST_URL_TO_BE_CRAWLED_MAX_NUM = 20000

# ÿ���˻�����click_url��Ŀ����
USER_CLICK_URL_SAMPLE_MAX = 1000

# ��ͬ����URL������
DOMAIN_RESERVE = 3

# ץȡ��������
# ץȡ��¼�ﵽ�ô����Ĳ���ץȡ
CRAWL_TIME_MAX = 100

# ������Ϣ
# 1.ģ��
models = {}
# 2.�ϲ�
models_merge = []
# 3.ҵ��
service = {}
# 4.����
send = {}

#=====models[110207103200] begin=====
models['110207103200'] = {"enable": True, 
        "model_id": '110207103200', 
        "model_type": [MODEL_TYPE_URL_MONITOR], 
        "model_name": u"�������ϡ�ע��ҳ��һ��", 
        "model_dir": "model/model_110207103200_catch_fish_inconsistent/", 
        "module_name": "model.catch_fish_inconsistent.catch_fish_inconsistent", 
        "class_name": "CatchFishInconsistent"
        }

models_merge.append({"enable": True, 
        "model_id": '110207103200',
        "merge_type": [MODEL_TYPE_URL_MONITOR],
        "module_name": "merge_method.catch_fish_inconsistent.merge",
        "class_name": "CatchFishInconsistentMerge"
        })
#=====models[110207103200] end=====

#=====models[110202000000] begin=====
models['110202000000'] = {"enable": True, 
        "model_id": '110202000000', 
        "model_type": [MODEL_TYPE_USER], 
        "model_name": u"�û������ģ��-���", 
        "model_dir": "model/model_110202000000_bj/", 
        "module_name": "model.base_model.model", 
        "class_name": "CNNModel"
        }
#=====models[110202000000] end=====

#=====models[110201000100] begin=====
# key ����һ��
models['110201000100'] = {"enable": True, 
        "model_id": '110201000100', 
        "model_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER], 
        "model_name": u"��Ԫ�����ģ��-���ʶ��ģ��-�˲��н�", 
        "model_dir": "model/model_110201000100_rczj/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }

models_merge.append({"enable": True, 
        "model_id": '110201000100',
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.base_merge.merge", 
        "class_name": "UnitMerge"
        })
#=====models[110201000100] end=====

#=====models[110201105600] begin=====
# key ����һ��
models['110201105600'] = {"enable": True, 
        "model_id": '110201105600', 
        "model_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER, MODEL_TYPE_FEED_USER, 
                      MODEL_TYPE_FEED_IDEA_UNIT], 
        "model_name": u"��Ԫ�����ģ��-������Ʒ-��ˮ", 
        "model_dir": "model/model_110201105600_personal_jiu_unit/", 
        "module_name": "model.base_model.model", 
        "class_name": "IdeaNgramLRModel"
        }

models_merge.append({"enable": True, 
        "model_id": '110201105600',
        "merge_type": [MODEL_TYPE_UNIT, MODEL_TYPE_FEED_IDEA_UNIT],
        "module_name": "merge_method.base_merge.multi_merge", 
        "class_name": "DirMultiMerge"
        })
#=====models[110201105600] end=====

#=====models[110201105900] begin=====
# key ����һ��
models['110201105900'] = {"enable": True, 
        "model_id": '110201105900', 
        "model_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER, MODEL_TYPE_FEED_USER, 
                      MODEL_TYPE_FEED_IDEA_UNIT], 
        "model_name": u"��Ԫ�����ģ��-��������", 
        "model_dir": "model/model_110201105900_clwl_unit/", 
        "module_name": "model.base_model.model", 
        "class_name": "IdeaNgramLRModel"
        }

models_merge.append({"enable": True, 
        "model_id": '110201105900',
        "merge_type": [MODEL_TYPE_UNIT, MODEL_TYPE_FEED_IDEA_UNIT],
        "module_name": "merge_method.base_merge.multi_merge", 
        "class_name": "DirMultiMerge"
        })
#=====models[110201105900] end=====

##=====models[110201105901] begin=====
# key ����һ��
models['110201105901'] = {"enable": False, 
        "model_id": '110201105901', 
        "model_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER, MODEL_TYPE_FEED_USER, 
                      MODEL_TYPE_FEED_IDEA_UNIT], 
        "model_name": u"��Ԫ�����ģ��-��������", 
        "model_dir": "model/model_110201105900_cars_unit/", 
        "module_name": "model.base_model.model", 
        "class_name": "IdeaNgramLRModel"
        }

models_merge.append({"enable": False, 
        "model_id": '110201105901',
        "merge_type": [MODEL_TYPE_UNIT, MODEL_TYPE_FEED_IDEA_UNIT],
        "module_name": "merge_method.base_merge.multi_merge", 
        "class_name": "DirMultiMerge"
        })
#=====models[110201105901] end=====


#=====models[110201100001] begin=====
# key ����һ��
models['110201100001'] = {"enable": True, 
        "model_id": '110201100001', 
        "model_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER, MODEL_TYPE_FEED_USER, 
                      MODEL_TYPE_FEED_IDEA_UNIT], 
        "model_name": u"��Ԫ�����ģ��-ά��ģ��", 
        "model_dir": "model/model_110201100001_unit_wx/", 
        "module_name": "model.base_model.model", 
        "class_name": "IdeaNgramLRModel"
        }

models_merge.append({"enable": True, 
        "model_id": '110201100001',
        "merge_type": [MODEL_TYPE_UNIT, MODEL_TYPE_FEED_IDEA_UNIT],
        "module_name": "merge_method.base_merge.multi_merge", 
        "class_name": "DirMultiMerge"
        })
#=====models[110201100001] end=====

#=====models[110202101101] begin=====
# key ����һ��
models['110202101101'] = {"enable": True, 
        "model_id": '110202101101', 
        "model_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER, MODEL_TYPE_FEED_USER, 
                      MODEL_TYPE_FEED_IDEA_UNIT], 
        "model_name": u"��Ԫ�����ģ��-����ģ��", 
        "model_dir": "model/model_110202101101_unit_recycling/", 
        "module_name": "model.base_model.model", 
        "class_name": "IdeaNgramLRModel"
        }

models_merge.append({"enable": True, 
        "model_id": '110202101101',
        "merge_type": [MODEL_TYPE_UNIT, MODEL_TYPE_FEED_IDEA_UNIT],
        "module_name": "merge_method.base_merge.multi_merge", 
        "class_name": "DirMultiMerge"
        })
#=====models[110202101101] end=====

#=====models[110200101201] begin=====
# key ����һ��
models['110200101201'] = {"enable": True, 
        "model_id": '110200101201', 
        "model_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER, MODEL_TYPE_FEED_USER, 
                      MODEL_TYPE_FEED_IDEA_UNIT], 
        "model_name": u"��Ԫ�����ģ��-���̼���ģ��", 
        "model_dir": "model/model_110200101201_unit_zsjm/", 
        "module_name": "model.base_model.model", 
        "class_name": "IdeaNgramLRModel"
        }

models_merge.append({"enable": True, 
        "model_id": '110200101201',
        "merge_type": [MODEL_TYPE_UNIT, MODEL_TYPE_FEED_IDEA_UNIT],
        "module_name": "merge_method.base_merge.multi_merge", 
        "class_name": "DirMultiMerge"
        })
#=====models[110200101201] end=====

#=====models[110201105700] begin====
models["110201105700"] = {"enable": True, 
        "model_id": "110201105700", 
        "model_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER, MODEL_TYPE_FEED_USER, 
                       MODEL_TYPE_FEED_IDEA_UNIT], 
        "model_name": u"��Ԫģ��-����Ϊ���й��������͵���", 
        "model_dir": "model/model_110200100800_rule/", 
        "module_name": "model.rule_detect_model.rule_detector", 
        "class_name": "DomainDetector"
        }

models_merge.append({"enable": True, 
        "model_id": "110201105700",
        "merge_type": [MODEL_TYPE_UNIT, MODEL_TYPE_FEED_IDEA_UNIT],
        "module_name": "merge_method.hit_all_rule_detect_merge.rule_detect_merge",
        "class_name": "RuleMerger"
        })
#=====models[110201105700] end====

#=====models[110201105800] begin=====
# key ����һ��
models['110201105800'] = {"enable": True,
        "model_id": '110201105800',
        "model_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER, MODEL_TYPE_FEED_USER],
        "model_name": u"��Ԫ�����ģ��-��Ʒһе",
        "model_dir": "model/model_110201105800_spyx/",
        "module_name": "model.base_model.model",
        "class_name": "SpyxUnitLRModel"
        }

models_merge.append({"enable": True,
        "model_id": '110201105800',
        "merge_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER],
        "module_name": "merge_method.base_merge.multi_merge",
        "class_name": "DirMultiMerge"
        })
#=====models[110201105800] end=====

#=====models[110201106200] begin=====
# key ����һ��
models['110201106200'] = {"enable": True,
        "model_id": '110201106200',
        "model_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER, MODEL_TYPE_FEED_USER],
        "model_name": u"��Ԫ�����ģ��-ʳƷ����",
        "model_dir": "model/model_110201106200_food_drink/",
        "module_name": "model.base_model.model",
        "class_name": "FoodDrinkUnitLRModel"
        }

models_merge.append({"enable": True,
        "model_id": '110201106200',
        "merge_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER],
        "module_name": "merge_method.base_merge.multi_merge",
        "class_name": "DirMultiMerge"
        })
#=====models[110201106200] end=====

#=====models[110201000200] begin=====
# key ����һ��
models['110201000200'] = {"enable": True, 
        "model_id": '110201000200', 
        "model_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER, MODEL_TYPE_FEED_USER], 
        "model_name": u"��Ԫ�����ģ��-ҽ����ͼģ��", 
        "model_dir": "model/model_110201000200_yl/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }
models_merge.append({"enable": True, 
        "model_id": '110201000200',
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.wxjmyl_merge.unit_result_merge", 
        "class_name": "TradeUnitResultMerge"
        })
#=====models[110201000200] end=====

#=====models[110201100000] begin=====
# key ����һ��
models["110201100000"] = {"enable": True, 
        "model_id": "110201100000", 
        "model_type": [MODEL_TYPE_UNIT], 
        "model_name": u"��Ԫʶ��ģ��-ά����ҵ��ð�ٷ�����ʶ��", 
        "model_dir": "model/model_110201100000_wxfm/", 
        "module_name": "model.fake_repair_detect_model.fake_repair_unit_detector", 
        "class_name": "FakeRepairUnitDetector"
        }
models_merge.append({"enable": True,
        "model_id": "110201100000",
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.fake_repair_detect_model.unit_result_merge",
        "class_name": "FakeRepairUnitResultMerge"
        })
#=====models[110201100000] end=====

#=====models[110202100100] begin=====
models["110202100100"] = {"enable": True, 
        "model_id": "110202100100", 
        "model_type": [MODEL_TYPE_USER], 
        "model_name": u"�û������ģ��-�Ĳ�", 
        "model_dir": "model/model_110202100100_gamble/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }
#=====models[110202100100] end=====

#=====models[110201100100] begin=====
models["110201100100"] = {"enable": True, 
        "model_id": "110201100100", 
        "model_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER], 
        "model_name": u"��Ԫ�����ģ��-���ʶ��ģ��-�Ĳ�", 
        "model_dir": "model/model_110201100100_gamble_unit/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }

models_merge.append({"enable": True, 
        "model_id": "110201100100",
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.base_merge.multi_merge", 
        "class_name": "BaseMerge"
        })
#=====models[110201100100] end=====

#=====models[110201000300] begin=====
models["110201000300"] = {"enable": True, 
        "model_id": "110201000300", 
        "model_type": [MODEL_TYPE_UNIT], 
        "model_name": u"��Ԫ�����ģ��-����", 
        "model_dir": "model/model_110201000300_travel/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }

models_merge.append({"enable": True, 
        "model_id": "110201000300",
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.base_merge.merge", 
        "class_name": "BaseMerge"
        })
#=====models[110201000300] end=====

#=====models[110200100200] begin====
models["110200100200"] = {"enable": False, 
        "model_id": "110200100200", 
        "model_type": [MODEL_TYPE_AD], 
        "model_name": u"����ʶ��ģ��-Ʒ�Ƽ��", 
        "model_dir": "model/model_110200100200_brand_detect/", 
        "module_name": "model.brand_detect_model.brand_detector", 
        "class_name": "BrandDetector"
        }

models_merge.append({"enable": False, 
        "model_id": "110200100200",
        "merge_type": [MODEL_TYPE_AD, MODEL_TYPE_UNIT],
        "module_name": "merge_method.brand_merge.brand_merge", 
        "class_name": "BrandMerger"
        })
#=====models[110200100200] end======

#=====models[110200100300] begin====
models["110200100300"] = {"enable": True, 
        "model_id": "110200100300", 
        "model_type": [MODEL_TYPE_AD], 
        "model_name": u"����ʶ��ģ��-���Ƽ���", 
        "model_dir": "model/model_110200100300_zljs/", 
        "module_name": "model.med_tech_detect_model.med_tech_detector", 
        "class_name": "MedTechDetector"
        }

models_merge.append({"enable": True, 
        "model_id": "110200100300",
        "merge_type": [MODEL_TYPE_AD, MODEL_TYPE_UNIT],
        "module_name": "merge_method.med_tech_merge.med_tech_merge", 
        "class_name": "MedTechMerger"
        })
#=====models[110200100300] end======

#=====models[110200100400] begin====
models["110200100400"] = {"enable": True, 
        "model_id": "110200100400", 
        "model_type": [MODEL_TYPE_AD], 
        "model_name": u"����ʶ��ģ��-����Ԥ��", 
        "model_dir": "model/model_110200100400_relation_gamble/", 
        "module_name": "model.rule_model.gamble_detector", 
        "class_name": "GambleDetector"
        }

models_merge.append({"enable": True, 
        "model_id": "110200100400",
        "merge_type": [MODEL_TYPE_AD],
        "module_name": "merge_method.relation_merge.relation_merge_ad", 
        "class_name": "RelationMerger"
        })

models_merge.append({"enable": True, 
        "model_id": "110200100400",
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.relation_merge.relation_merge_unit", 
        "class_name": "RelationMerger"
        })

#=====models[110200100400] end======

#=====models[110200100500] begin====
models["110200100500"] = {"enable": True, 
        "model_id": "110200100500", 
        "model_type": [MODEL_TYPE_AD], 
        "model_name": u"����ʶ��ģ��-��������", 
        "model_dir": "model/model_110200100500_jbmc/", 
        "module_name": "model.disease_detect_model.disease_detector", 
        "class_name": "DiseaseDetector"
        }

models_merge.append({"enable": True, 
        "model_id": "110200100500",
        "merge_type": [MODEL_TYPE_AD, MODEL_TYPE_UNIT],
        "module_name": "merge_method.disease_merge.disease_merge", 
        "class_name": "DiseaseMerger"
        })

#=====models[110200100500] end======

#=====models[110200100600] begin====
models["110200100600"] = {"enable": True, 
        "model_id": "110200100600",
        "model_type": [MODEL_TYPE_CLICK_AD], 
        "model_name": u"���ʶ��ģ��-�⽨����", 
        "model_dir": "model/model_110200100600_fjmx/",
        "module_name": "model.click_model.click_feudal_model",
        "class_name": "ClickModel"
        }

models_merge.append({"enable": True, 
        "model_id": "110200100600",
        "merge_type": [MODEL_TYPE_CLICK_AD],
        "module_name": "merge_method.click_merge.fjmx_merge_update",
        "class_name": "ClickMerger"
        })
#=====models[110200100600] end====

#=====models[110202000400] begin====
models["110202000400"] = {"enable": True, 
        "model_id": "110202000400", 
        "model_type": [MODEL_TYPE_USER, MODEL_TYPE_FEED_USER], 
        "model_name": u"�˻���ҵϸ����-����", 
        "model_dir": "model/model_110202000400_financial_industry", 
        "module_name": "model.base_model.model", 
        "class_name": "CrossNgramLRModel"
        }
#=====models[110202000400] end======

#=====models[110200100700] begin====
models["110200100700"] = {"enable": True,
        "model_id": "110200100700",
        "model_type": [MODEL_TYPE_CLICK_AD], 
        "model_name": u"���ʶ��ģ��-�Ƿ�����", 
        "model_dir": "model/model_110200100700_fffw/", 
        "module_name": "model.click_model.click_model", 
        "class_name": "ClickModel"
        }

models_merge.append({"enable": True, 
        "model_id": "110200100700",
        "merge_type": [MODEL_TYPE_CLICK_AD],
        "module_name": "merge_method.click_merge.click_merge",
        "class_name": "ClickMerger"
        })
#=====models[110200100700] end====

#=====models[110200100800] begin====
models["110200100800"] = {"enable": True, 
        "model_id": "110200100800", 
        "model_type": [MODEL_TYPE_CLICK_AD], 
        "model_name": u"���ʶ��ģ��-������", 
        "model_dir": "model/model_110200100800_rule/", 
        "module_name": "model.rule_detect_model.rule_detector", 
        "class_name": "RuleDetector"
        }

models_merge.append({"enable": True, 
        "model_id": "110200100800",
        "merge_type": [MODEL_TYPE_CLICK_AD],
        "module_name": "merge_method.click_merge.click_rule_merge",
        "class_name": "ClickMerger"
        })
#=====models[110200100800] end====

#=====models[110201100900] begin=====
models["110201100900"] = {"enable": True, 
        "model_id": "110201100900", 
        "model_type": [MODEL_TYPE_UNIT], 
        "model_name": u"��Ԫ�����ģ��-���﷨���ڿ�pos��",
        "model_dir": "model/model_110201100900_wfqp/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }

models_merge.append({"enable": True, 
        "model_id": "110201100900",
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.base_merge.merge", 
        "class_name": "BaseMerge"
        })
#=====models[110201100900] end=====

#=====models[100100101000] begin=====
models["100100101000"] = {"enable": True, 
        "model_id": "100100101000", 
        "model_type": [MODEL_TYPE_USER, MODEL_TYPE_CLICK_USER], 
        "model_name": u"�û������ģ��-��Ӫ��Χ��ǩ", 
        "model_dir": "model/model_100100101000_business_scope_label/", 
        "module_name": "model.business_scople_label.business_scope_label", 
        "class_name": "BusinessScopeLabel"
        }
#=====models[100100101000] end=====

#=====models[110202101100] begin=====
models["110202101100"] = {"enable": True, 
        "model_id": "110202101100", 
        "model_type": [MODEL_TYPE_USER, MODEL_TYPE_FEED_USER], 
        "model_name": u"�û������ģ��-feed�û������ģ��-����", 
        "model_dir": "model/model_110202101100_recycling/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }
#=====models[110202101100] end=====

#=====models[110200101200] begin=====
models["110200101200"] = {"enable": True, 
        "model_id": "110200101200", 
        "model_type": [MODEL_TYPE_CLICK_AD], 
        "model_name": u"���ʶ��ģ��-���̼��˷�ð����Ʒ���˻�ʶ��",
        "model_dir": "model/model_110200101200_zsjmfm_file/", 
        "module_name": "model.fake_join_detect_model.fake_join_detector", 
        "class_name": "FakeJoinDetector"
        }

models_merge.append({"enable": True, 
        "model_id": "110200101200",
        "merge_type": [MODEL_TYPE_CLICK_AD],
        "module_name": "merge_method.fake_join_merge.fake_join_ad_merge", 
        "class_name": "FakeJoinMerge"
        })
#=====models[110200101200] end=====

#=====models[100100101300] begin=====
models["100100101300"] = {"enable": True, 
        "model_id": "100100101300", 
        "model_type": [MODEL_TYPE_USER, MODEL_TYPE_CLICK_USER, MODEL_TYPE_FEED_USER], 
        "model_name": u"���ʻ�������ģ��",
        "model_dir": "model/model_100100101300_white_user/", 
        "module_name": "model.white_user_model.white_user_model", 
        "class_name": "WhiteUserDetector"
        }
#=====models[100100101300] end=====

#=====models[110200100801] end=====
models["110200100801"] = {"enable": True, 
        "model_id": "110200100801", 
        "model_type": [MODEL_TYPE_AD, MODEL_TYPE_FEED_AD, MODEL_TYPE_FEED_AD, MODEL_TYPE_UNIT, 
                       MODEL_TYPE_CLICK_USER, MODEL_TYPE_FEED_USER, MODEL_TYPE_FEED_IDEA_UNIT],
        "model_name": u"����ʶ��ģ��-feed���Ϲ���ģ��-���е����й���", 
        "model_dir": "model/model_110200100800_rule/", 
        "module_name": "model.hit_all_rule_detect_model.rule_detector", 
        "class_name": "RuleDetector"
        }

models_merge.append({"enable": True, 
        "model_id": "110200100801",
        "merge_type": [MODEL_TYPE_AD, MODEL_TYPE_UNIT, MODEL_TYPE_FEED_AD, MODEL_TYPE_UNIT,
                       MODEL_TYPE_FEED_IDEA_UNIT],
        "module_name": "merge_method.hit_all_rule_detect_merge.rule_detect_merge", 
        "class_name": "RuleMerger"
        })
#=====models[110200100801] end====

#=====models[110201101400] begin=====
models["110201101400"] = {"enable": True, 
        "model_id": "110201101400", 
        "model_type": [MODEL_TYPE_UNIT], 
        "model_name": u"��Ԫ�����ģ��-�·��տ��ٵ���",
        "model_dir": "model/model_110201101400_nrisk/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }

models_merge.append({"enable": True, 
        "model_id": "110201101400",
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.base_merge.merge", 
        "class_name": "BaseMerge"
        })
#=====models[110201101400] end=====

#=====models[100100101500] begin====
models["100100101500"] = {"enable": True, 
        "model_id": "100100101500", 
        "model_type": [MODEL_TYPE_CLICK_AD], 
        "model_name": u"���ģ��-��ҽ������ʹ��ada����", 
        "model_dir": "model/model_110200100800_rule/", 
        "module_name": "model.hit_all_rule_detect_model.rule_detector", 
        "class_name": "RuleDetector"
        }

models_merge.append({"enable": True, 
        "model_id": "100100101500",
        "merge_type": [MODEL_TYPE_CLICK_AD],
        "module_name": "merge_method.hit_all_rule_detect_merge.rule_detect_merge",
        "class_name": "RuleMerger"
        })
#=====models[100100101500] end====

#=====models[110201000500] begin=====
models["110201000500"] = {"enable": True, 
        "model_id": "110201000500", 
        "model_type": [MODEL_TYPE_UNIT], 
        "model_name": u"��Ԫ��ҵ��ǩģ��-�������", 
        "model_dir": "model/model_110201000500_financial_service/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }

models_merge.append({"enable": True, 
        "model_id": "110201000500",
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.base_merge.merge", 
        "class_name": "BaseMerge"
        })
#=====models[110201000500] end=====

#=====models[110201000600] begin=====
models["110201000600"] = {"enable": True, 
        "model_id": "110201000600", 
        "model_type": [MODEL_TYPE_UNIT], 
        "model_name": u"��Ԫ��ҵ��ǩģ��-�������", 
        "model_dir": "model/model_110201000600_life_service/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }

models_merge.append({"enable": True, 
        "model_id": "110201000600",
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.life_server_merge.unit_merge", 
        "class_name": "UnitMerge"
        })
#=====models[110201000600] end=====

#=====models[110202000700] begin=====
models["110202000700"] = {"enable": True, 
        "model_id": "110202000700", 
        "model_type": [MODEL_TYPE_CLICK_USER], 
        "model_name": u"�û����ά����ҵ��ǩģ��-�������", 
        "model_dir": "model/model_110202000700_bag_clothes/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }

#=====models[110202000700] end=====

#=====models[110200101600] begin====
models["110200101600"] = {"enable": True, 
        "model_id": "110200101600", 
        "model_type": [MODEL_TYPE_METEOR_AD], 
        "model_name": u"������Ʊʶ��ģ��-������", 
        "model_dir": "model/model_110200100800_rule/", 
        "module_name": "model.rule_detect_model.word_rule_detector", 
        "class_name": "RuleDetector"
        }

models_merge.append({"enable": True, 
        "model_id": "110200101600",
        "merge_type": [MODEL_TYPE_METEOR_AD],
        "module_name": "merge_method.click_merge.click_rule_merge",
        "class_name": "ClickMerger"
        })
#=====models[110200101600] end====

#=====models[110201101700] begin=====
models["110201101700"] = {"enable": True, 
        "model_id": "110201101700", 
        "model_type": [MODEL_TYPE_UNIT], 
        "model_name": u"��Ԫ��ҵ��ǩģ��-������ƷʳƷ���۵�", 
        "model_dir": "model/model_110201101700_ntag/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }

models_merge.append({"enable": True, 
        "model_id": "110201101700",
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.base_merge.merge", 
        "module_file": "merge",
        "class_name": "BaseMerge"
        })
#=====models[110201101700] end=====

#=====models[110201101800] begin=====
models["110201101800"] = {"enable": True, 
        "model_id": "110201101800", 
        "model_type": [MODEL_TYPE_UNIT, MODEL_TYPE_CLICK_USER], 
        "model_name": u"��Ԫģ��-���ʶ��-SEOӰ��Ͷ��", 
        "model_dir": "model/model_110201101800_seo/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }

models_merge.append({"enable": True, 
        "model_id": "110201101800",
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.base_merge.merge", 
        "class_name": "BaseMerge"
        })
#=====models[110201101800] end=====

#=====models[110201101900] begin====
models["110201101900"] = {"enable": True, 
        "model_id": "110201101900", 
        "model_type": [MODEL_TYPE_UNIT], 
        "model_name": u"��Ԫģ��-SEOģ��", 
        "model_dir": "model/model_110201101900_SEO/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }

models_merge.append({"enable": True, 
        "model_id": "110201101900",
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.base_merge.multi_merge",
        "class_name": "BaseMerge"
        })
#=====models[110201101900] end====

#=====models[120200102000] begin====
models["120200102000"] = {"enable": True, 
        "model_id": "120200102000", 
        "model_type": [MODEL_TYPE_CLICK_AD, MODEL_TYPE_FEED_AD], 
        "model_name": u"�������ʶ��ģ��-feed����ʶ��ģ��-ֱ������ʶ��", 
        "model_dir": "model/model_120200102000_live_broadcast/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }

models_merge.append({"enable": True, 
        "model_id": "120200102000",
        "merge_type": [MODEL_TYPE_CLICK_AD],
        "module_name": "merge_method.click_merge.click_merge",
        "class_name": "ClickMerger"
        })

models_merge.append({"enable": True,
        "model_id": "120200102000",
        "merge_type": [MODEL_TYPE_FEED_AD],
        "module_name": "merge_method.feed_merge.base_merge",
        "class_name": "BaseMerger"
        })
#=====models[120200102000] end====

#=====models[100100102100] begin=====
models["100100102100"] = {"enable": True, 
        "model_id": "100100102100", 
        "model_type": [MODEL_TYPE_METEOR_AD], 
        "model_name": u"��Σ�豸��-��������", 
        "model_dir": "model/model_100100102100_risk_device/", 
        "module_name": "model.risk_device_meteor_model.risk_device_meteor", 
        "class_name": "RiskDeviceMeteor"
        }

models_merge.append({"enable": True, 
        "model_id": "100100102100",
        "merge_type": [MODEL_TYPE_METEOR_AD],
        "module_name": "merge_method.click_merge.click_merge",
        "class_name": "ClickMerger"
        })
#=====models[100100102100] end=====

#=====models[110202102200] begin=====
models["110202102200"] = {"enable": True, 
        "model_id": "110202102200", 
        "model_type": [MODEL_TYPE_USER], 
        "model_name": u"�û�ά����ҵ��ǩģ��-�������ޡ�����", 
        "model_dir": "model/model_110202102200_car_rent_purchase/", 
        "module_name": "model.base_model.model", 
        "class_name": "BaseModel"
        }

#=====models[110202102200] end=====

#=====models[110201102300] begin=====
models["110201102300"] = {"enable": True,
        "model_id": "110201102300",
        "model_type": [MODEL_TYPE_UNIT, MODEL_TYPE_FEED_AD],
        "model_name": u"���Ͼ����ð����ʶ��",
        "model_dir": "model/model_110201102300_liquor_unit/",
        "module_name": "model.base_model.model",
        "class_name": "BaseModel"
        }

models_merge.append({"enable": True,
        "model_id": "110201102300",
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.base_merge.merge",
        "class_name": "BaseMerge"
        })

models_merge.append({"enable": True,
        "model_id": "110201102300",
        "merge_type": [MODEL_TYPE_FEED_AD],
        "module_name": "merge_method.feed_merge.base_merge",
        "class_name": "BaseMerger"
        })

#=====models[110201102300] end=====

#=====models[110200102400] begin=====
models["110200102400"] = {"enable": True, 
        "model_id": "110200102400", 
        "model_type": [MODEL_TYPE_AD], 
        "model_name": u"����ʶ��ģ��-������ѯϸ��ǩʶ��", 
        "model_dir": "model/model_110200102400_psychological_counseling/", 
        "module_name": "model.psychological_counseling.psychological_counsel", 
        "class_name": "PysCounselingPredict"
        }

models_merge.append({"enable": True, 
        "model_id": "110200102400",
        "merge_type": [MODEL_TYPE_AD, MODEL_TYPE_UNIT],
        "module_name": "merge_method.psychological_counseling_merge.psycho_counsel_merge", 
        "class_name": "PsychoMerge"
        })
#=====models[110200102400] end====

#=====models[110200102500] begin=====
models["110200102500"] = {"enable": True, 
        "model_id": "110200102500", 
        "model_type": [MODEL_TYPE_AD], 
        "model_name": u"����ʶ��ģ��-������ѯ������", 
        "model_dir": "model/model_110200102400_psychological_counseling/", 
        "module_name": "model.psychological_counseling_unqualified.counselling_unqualified", 
        "class_name": "CounselingUnqualifiedPredict"
        }

models_merge.append({"enable": True, 
        "model_id": "110200102500",
        "merge_type": [MODEL_TYPE_AD, MODEL_TYPE_UNIT],
        "module_name": "merge_method.psychological_counseling_merge.psycho_counsel_merge", 
        "class_name": "PsychoMerge"
        })
#=====models[110200102500] end====

#=====models[110201102600] begin=====
models["110201102600"] = {"enable": True,
        "model_id": "110201102600",
        "model_type": [MODEL_TYPE_UNIT],
        "model_name": u"unit_������ѧ�н�ģ��",
        "model_dir": "model/model_110201102600_study_abroad/",
        "module_name": "model.base_model.model",
        "class_name": "BaseModel"
        }

models_merge.append({"enable": True,
        "model_id": "110201102600",
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.base_merge.merge",
        "class_name": "BaseMerge"
        })
#=====models[110201102600] end=====

#=====models[110201103100] begin=====
models["110201103100"] = {"enable": True,
        "model_id": "110201103100",
        "model_type": [MODEL_TYPE_UNIT],
        "model_name": u"unit_���Թ���ʶ��ģ��",
        "model_dir": "model/model_110201103100_hunter_tool/",
        "module_name": "model.hunter_tool_model.model",
        "class_name": "HunterPredict"
        }

models_merge.append({"enable": True,
        "model_id": "110201103100",
        "merge_type": [MODEL_TYPE_UNIT],
        "module_name": "merge_method.base_merge.merge",
        "class_name": "BaseMerge"
        })
#=====models[110201103100] end=====

#=====models[120202105200] begin=====
models["120202105200"] = {"enable": True,
        "model_id": "120202105200",
        "model_type": [MODEL_TYPE_FEED_USER],
        "model_name": u"С˵��ҵģ��",
        "model_dir": "model/model_120202105200_novel",
        "module_name": "model.base_model.model",
        "class_name": "BaseModel"
        }
#=====models[120202105200] end=====

#=====meteor models begin=====
# meteor�и�ģ�͵Ľ�����ܵ��˻���, ��ռ��, ȡռ����ߵĽ��, ����ռ����ֵ
METEOR_MODEL_DIR = "model/model_meteor/"
models["100101100600"] = {"enable": True, 
        "model_id": "100101100600", 
        "model_type": [MODEL_TYPE_METEOR], 
        "model_name": u"METEOR-100101100600-�⽨����", 
        "meteor_model_id": "1024|20016", 
        "module_name": "model.meteor_model.meteor_model", 
        "class_name": "MeteorModel", 
        "opt_args": {"percent_thres": 0.7, "adnum_thres": 10}
        }
#=====meteor models end=====

#=====other models begin=====
OTHER_MODEL_DIR = "model/model_other/"
models["110203100700"] = {"enable": True,
        "model_id": "110203100700",
        "model_type": [MODEL_TYPE_OTHER],
        "model_name": u"OTHER-110203100700-�Ƿ�����",
        "hostname": "szth-ecom-darwin06-39605.szth.baidu.com",
        "file_path": "/home/matrix/containers/1.def-kg.DARWIN.szth" + \
                "/home/work/zhuxiaodong01/model_auditor/model_110203100700/"
        }

OTHER_MODEL_DIR = "model/model_other/"
models["110203102700"] = {"enable": True,
        "model_id": "110203102700",
        "model_type": [MODEL_TYPE_OTHER],
        "model_name": u"OTHER-110203102700-��ֱ��������̵�",
        "hostname": "szth-ecom-darwin06-39605.szth.baidu.com",
        "file_path": "/home/matrix/containers/1.def-kg.DARWIN.szth" + \
                "/home/work/zhuxiaodong01/model_auditor/model_110203102700/"
        }

OTHER_MODEL_DIR = "model/model_other/"
models["110203100100"] = {"enable": True,
        "model_id": "110203100100",
        "model_type": [MODEL_TYPE_OTHER],
        "model_name": u"OTHER-110203100100-����ضĲ��ʻ�",
        "hostname": "szth-ecom-darwin06-39605.szth.baidu.com",
        "file_path": "/home/matrix/containers/1.def-kg.DARWIN.szth" + \
                "/home/work/zhubenchang/develope/def-relation/data/"
        }
#=====other models end=====

#=====url models begin=====
#=====models[110205102800] begin=====
models["110205102800"] = {"enable": False,
        "model_id": "110205102800",
        "model_type": [MODEL_TYPE_URL],
        "model_name": u"URL-110205102800-������ͼģ��",
        "model_dir": "model/model_110205102800_lp_intention/", 
        "module_name": "model.lp_intention_detect_model.lp_intention_detector", 
        "class_name": "LpIntentionDetector"
        }

models_merge.append({"enable": False, 
        "model_id": "110205102800",
        "merge_type": [MODEL_TYPE_URL],
        "module_name": "merge_method.url_merge.merge", 
        "class_name": "UrlMerge"
        })
#=====models[110205102800] end=====

#=====models[110205102900] begin=====
models["110205102900"] = {"enable": False,
        "model_id": "110205102900",
        "model_type": [MODEL_TYPE_URL],
        "model_name": u"URL-110205102900-����ģ��",
        "model_dir": "model/model_110205102900_lp_softtext/",
        "module_name": "model.lp_softtext_model.lp_softtext_model",
        "class_name": "LrPredict"
        }

models_merge.append({"enable": False, 
        "model_id": "110205102900",
        "merge_type": [MODEL_TYPE_URL],
        "module_name": "merge_method.url_merge.merge", 
        "class_name": "UrlMerge"
        })
#=====models[110205102900] end=====

#=====models[110204103000] begin=====
models["110204103000"] = {"enable": True, 
        "model_id": "110204103000",
        "model_type": [MODEL_TYPE_URL],
        "model_name": u"URL-110204103000-seo����/�����ת",
        "model_dir": "model/model_110204103000_lptextrule/",
        "module_name": "model.lp_textrule_model.lp_textrule_model",
        "class_name": "LpTextRule"}

models_merge.append({"enable": True, 
        "model_id": "110204103000",
        "merge_type": [MODEL_TYPE_URL],
        "module_name": "merge_method.url_merge.merge", 
        "class_name": "UrlMerge"
        })
#=====models[110204103000] end=====

#=====models[110205100100] begin=====
models["110205100100"] = {"enable": True, 
        "model_id": "110205100100",
        "model_type": [MODEL_TYPE_URL],
        "model_name": u"URL-110205100100-LP�Ĳ�",
        "model_dir": "model/model_110205100100_lp_gamble/",
        "module_name": "model.lp_base_model.model",
        "class_name": "LpBaseModel"}

models_merge.append({"enable": True, 
        "model_id": "110205100100",
        "merge_type": [MODEL_TYPE_URL],
        "module_name": "merge_method.url_merge.merge", 
        "class_name": "UrlMerge"
        })
#=====models[110205100100] end=====

#=====models[110205104700] begin=====
models["110205104700"] = {"enable": False, 
        "model_id": "110205104700",
        "model_type": [MODEL_TYPE_URL],
        "model_name": u"URL-110205104700-LP�̱�����",
        "model_dir": "model/model_110205104700_lp_brand/",
        "module_name": "model.lp_brand_model.lp_brand_model",
        "class_name": "LpBrandRule"}

models_merge.append({"enable": False, 
        "model_id": "110205104700",
        "merge_type": [MODEL_TYPE_URL],
        "module_name": "merge_method.url_merge.merge", 
        "class_name": "UrlMerge"
        })
#=====models[110205104700] end=====

#=====models[110205104800] begin=====
models["110205104800"] = {"enable": False, 
        "model_id": "110205104800",
        "model_type": [MODEL_TYPE_URL],
        "model_name": u"URL-110205104800-LP��˾����",
        "model_dir": "model/model_110205104800_lp_company/",
        "module_name": "model.lp_company_model.lp_company_model",
        "class_name": "LpCompanyRule"}

models_merge.append({"enable": False, 
        "model_id": "110205104800",
        "merge_type": [MODEL_TYPE_URL],
        "module_name": "merge_method.url_merge.merge", 
        "class_name": "UrlMerge"
        })
#=====models[110205104800] end=====

#=====url models end=====

#=====models[110207105100] begin=====
models['110207105100'] = {"enable": True, 
        "model_id": '110207105100', 
        "model_type": [MODEL_TYPE_URL_MONITOR], 
        "model_name": u"���ҳ����ĳ�ı�", 
        "model_dir": "model/model_110204103000_lptextrule/", 
        "module_name": "model.lp_textrule_model_new.lp_textrule_model",
        "class_name": "LpTextRule"
        }

models_merge.append({"enable": True, 
        "model_id": '110207105100',
        "merge_type": [MODEL_TYPE_URL_MONITOR],
        "module_name": "merge_method.url_merge.merge",
        "class_name": "UrlMerge"
        })
#=====models[110207105100] end=====

#####������-�˲��н������ҵ 10020321 start####
service["10020321"] = {
        "enable": True,
        "service_id": "10020321",
        "service_name": "������-�˲��н������ҵ",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"�˲��н�������--����-��׬",
              "model_id": '110201000100',
              "label_id": "6",
              "opt_need": "1051|1104|1092|1012|1097",
              "sub_send": [
                  { "send_name": u"���ģ��-�˲��н�������(100203211000)",
                    "product_id": 1
                    },
                  { "enable": False,
                    "send_name": u"���ģ��-�˲��н�������(100203211000)",
                    "push_user_num_max": 20,
                    "product_id": 1,
                    "deal_group": "1",
                    "send_day_interval": 5
                    }] },
            { "service_id": "1001",
              "service_name": u"��׬/��ְ",
              "model_id": "110201000100",
              "label_id": "3|6",
              "opt_need": "1051|1104|1092|1012|1097",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"���ģ��-�˲��н�������(100203211001)",
                    "push_user_num_max": 30,
                    "product_id": 1,
                    "deal_group": "1",
                    "send_day_interval": 5
                    }] },
            { "service_id": "1002",
              "service_type": RISK_USER,
              "service_name": u"�˲��н��˻�url���",
              "service_module": "service_method.label_operation",
              "service_class": "LabelOperation",
              "model_id": "110201000100",
              "label_id": "3|6",
              "sub_send": [
                  { "send_type": URL_MONITOR,
                    "send_name": u"���ģ��-�˲��н������ʼ��(100203211002)",
                    "push_user_num_max": 500,
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.qualification",
            "service_class": "Qualification"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "is_evidence_exist": 1,
            "risk_type": 10020321,
            "evidence_type": 1
            }
        }

#####������-�˲��н������ҵ 10020321 end####

#####�Ĳ��ʻ� 10010501 start####
service["10010501"] = {
        "enable": True,
        "service_id": "10010501",
        "service_name": "�Ĳ��ʻ�",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"�˻�-�Ĳ�",
              "model_label_dict": {"110202100100": "2"},
              "sub_send": [
                  { "send_name": u"���ģ��-�Ĳ���(100105011000)",
                    "product_id": 1,
                    "evidence_type": 1
                    }] },
            { "service_id": "1001",
              "service_name": u"��Ԫ-�Ĳ�",
              "service_module": "service_method.label_operation",
              "service_class": "LabelOperation",
              "model_id": "110201100100",
              "label_id": "1|2|5",
              "intersection": {},
              "difference": {},
              "opt_intersection": "",
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"���ģ��-�Ĳ���(100105011001)",
                    "product_id": 1,
                    "evidence_type": 1
                    }] },
            { "service_id": "1002",
              "service_name": u"����-�Ĳ�/��Ʊ",
              "model_label_dict": {"110200100800": "1"},
              "sub_send": [
                  { "send_name": u"���ģ��-�Ĳ�/��Ʊ(100105011002)",
                    "product_id": 1,
                    "evidence_type": 1
                    }] },
            { "service_id": "1003",
              "service_name": u"���ҳ�Ĳ�(��)",
              "model_label_dict": {"110205100100": "2|3|6"},
              "sub_send": [
                  { "send_name": u"���ҳ�Ĳ�(����OCR)(100105011003)",
                    "product_id": 1,
                    "is_evidence_exist": 2,
                    "push_user_num_max": 130
                    }] },
            { "service_id": "1004",
              "service_name": u"���ҳ�Ĳ�(��)",
              "model_label_dict": {"110208100100": "1|2"},
              "sub_send": [
                  { "send_name": u"���ҳ�Ĳ�(OCR)(100105011004)",
                    "product_id": 1,
                    "is_evidence_exist": 2,
                    "push_user_num_max": 150
                    }] },
            { "service_id": "1005",
              "service_name": u"����-�Ĳ�/��Ʊ",
              "model_label_dict": {"110200101600": "1"},
              "sub_send": [
                  { "send_name": u"����-�Ĳ�/��Ʊ(100105011005)",
                    "product_id": 1,
                    "evidence_type": 1
                    }] },
            { "service_id": "1006",
              "service_name": u"LP-�Ĳ�",
              "service_module": "service_method.label_operation",
              "service_class": "LabelOperation",
              "model_id": "110205100100",
              "label_id": "1|2|5",
              "sub_send": [
                  { "send_name": u"LP-�Ĳ�(100105011006)",
                    "product_id": 1,
                    "is_evidence_exist": 2
                    }] },
            { "service_id": "1007",
              "service_name": u"�Ĳ��˻�url���2",
              "service_module": "service_method.label_operation",
              "service_class": "LabelOperation",
              "model_id": "110202100100",
              "label_id": "1",
              "sub_send": [
                  { "send_type": URL_MONITOR,
                    "send_name": u"�Ĳ��˻�url���2(100105011007)",
                    "push_user_num_max": 500,
                    "evidence_type": 1
                    }] },
            { "service_id": "1008",
              "service_name": u"�Ĳ��˻�url���3",
              "service_module": "service_method.label_operation",
              "service_class": "LabelOperation",
              "model_id": "110201100100",
              "label_id": "1",
              "sub_send": [
                  { "send_type": URL_MONITOR,
                    "send_name": u"�Ĳ��˻�url���3(100105011008)",
                    "push_user_num_max": 500,
                    "evidence_type": 1
                    }] },
            { "service_id": "1009",
              "service_name": u"�Ĳ���Ʊ�ʻ�-�˻�url���",
              "service_module": "service_method.label_operation",
              "service_class": "LabelOperation",
              "model_id": "100100101500",
              "label_id": "1",
              "sub_send": [
                  { "send_type": URL_MONITOR,
                    "send_name": u"ʹ��ada�����˻�url���(100105011009)",
                    "push_user_num_max": 500,
                    "evidence_type": 1
                    }] },
            { "service_id": "1010",
              "service_name": u"����ʶĲ��ʻ�",
              "model_id": "110203100100",
              "label_id": "1",
              "service_module": "service_method.label_operation",
              "service_class": "LabelOperation",
              "difference": {"100100101300": "3"},
              "agent_type_difference": "KA",
              "sub_send": [
                  { "send_name": u"����ʶĲ��ʻ�(100105011010)",
                    "product_id": 1,
                    "evidence_type": 1,
                    "deal_group": "1"
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.risk_user",
            "service_class": "Risk_user"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "is_evidence_exist": 1,
            "push_user_num_max": 300,
            "risk_type": 10010501
            }
    }
#####�Ĳ��ʻ� 10010501 end####

#####������-������������ 10020324 start####
service["10020324"] = {
        "enable": True,
        "service_id": "10020324",
        "service_name": "����������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"����������",
              "model_id": "110202100100",
              "label_id": "4",
              "opt_need": "1102",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"�����������-��پ�Ӫ��Χ��һ��(100203241000)",
                    "deal_group": "1"
                    }] },
            { "service_id": "1001",
              "service_type": RISK_USER,
              "service_name": u"����������",
              "service_module": "service_method.label_operation",
              "service_class": "LabelOperation",
              "model_id": "110201100100",
              "label_id": "4",
              "intersection": {},
              "difference": {},
              "opt_intersection": "",
              "opt_difference": "1102",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"���ģ��-����������(click)(100203241001)"
                    }] },
            { "service_id": "1002",
              "service_type": RISK_USER,
              "service_name": u"����������",
              "service_module": "service_method.label_operation",
              "service_class": "LabelOperation",
              "model_id": "110201100100",
              "label_id": "4",
              "intersection": {},
              "difference": {},
              "opt_intersection": "",
              "opt_difference": "1102",
              "limit_consume": 0.00001,
              "sub_send": [
                  { "send_name": u"���ģ��-����������(all)(100203241002)",
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.qualification",
            "service_class": "Qualification"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020324,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 30
            }
        }
#####������-������������ 10020324 end####

#####��ð����Ʒ�Ƽ���վ 10011501 start####
service["10011501"] = {
        "enable": True,
        "service_id": "10011501",
        "service_name": "��ð����Ʒ�Ƽ���վ",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"ά����ҵ��ð�ٷ��˻�",
              "model_id": "110201100000",
              "label_id": "2",
              "brand_num_threshold": 2,
              "risk_threshold": 0.2,
              "sub_send": [
                  { "enable": False,
                    "send_name": u"���ģ��-ά����ҵ��ð�ٷ�(100115011000)"
                    }] },
            { "service_id": "1001",
              "service_name": u"��ð����Ʒ��-���̼���",
              "model_label_dict": {"110200101200": "1"},
              "service_module": "service_method.risk_user",
              "service_class": "Risk_user",
              "sub_send": [
                  { "send_name": u"��ð����Ʒ��-���̼���(100201011001)",
                    "deal_group": "1",
                    "send_day_interval": 1
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.fake_repair_user_filter",
            "service_class": "FakeRepairUserFilter"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10011501,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 50
            }
        }
#####��ð����Ʒ�Ƽ���վ 10011501 end####

#####������-���η��� 10020326 start####
service["10020326"] = {
        "enable": True,
        "service_id": "10020326",
        "service_name": "������-���η���",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"����������",
              "model_id": "110201000300",
              "label_id": "1|2",
              "opt_need": "1033|1035|1073|1110|1172|1119|1120|1121|1122|1123|1124|1125",
              "white_label": {"100100101300": "2"},
              "sub_send": [
                  { "enable": False,
                    "send_name": u"����������-������ҵ(100203261000)",
                    "deal_group": "1"
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.qualification",
            "service_class": "Qualification"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020326,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 10
            }
        }
#####������-���η��� 10020326 end####

#####������-ҽ�������� 10020390 start####
service["10020390"] = {
        "enable": True,
        "service_id": "10020390",
        "service_name": "������-ҽ����������",
        "sub_service": [
            { "service_id": "1000",
              "label_id": "5120",
              "opt_difference": "1055",
              "opttype_difference": "2|3|4",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"���ģ��-ҽ�ƻ���������(100203901000)"
                    }] },
            { "service_id": "1001",
              "label_id": "5001",
              "opttype_difference": "1|2",
              "sub_send": [
                  { "send_name": u"���ģ��-ҽ�ƻ���������(100203901001)"
                    }] },
            { "service_id": "1002",
              "label_id": "5021|5126",
              "opttype_difference": "2|3|4",
              "sub_send": [
                  { "send_type": URL_MONITOR,
                    "send_name": u"���ģ��-ҽ�ƻ��������ʼ��(100203901002)",
                    "push_user_num_max": 500,
                    }] },
            { "service_id": "1003",
              "model_id": "110207105100",
              "label_id": "3",
              "opttype_difference": "2|3|4",
              "intersection": {"110201000200": "5021|5126"},
              "sub_send": [
                  { "send_name": u"���ģ��-ҽ�ƻ���������(100203901003)",
                    "is_evidence_exist": 2
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation",
            "service_name": u"������-ҽ����������",
            "model_id": "110201000200"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020390,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 20
            }
        }
#####������-ҽ�������� 10020390 end####

#####�⽨���ŷ��� 10011310 start####
service["10011310"] = {
        "enable": True,
        "service_id": "10011310",
        "service_name": "�⽨���ŷ���",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"�⽨����",
              "model_label_dict": {"110200100600": "1"},
              "sub_send": [
                  {
                    "send_name": u"���ģ��-�⽨����(100113101000)",
                    "push_user_num_max": 10,
                    "evidence_type": 1
                    }] },
            { "service_id": "1001",
              "service_name": u"�⽨����",
              "model_label_dict": {"110205100600": "1"},
              "sub_send": [
                  { "enable": False,
                    "send_name": u"���ģ��-���ҳ�⽨����(100113101001)",
                    "is_evidence_exist": 2,
                    "push_user_num_max": 50
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.risk_user",
            "service_class": "Risk_user"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10011310,
            "is_evidence_exist": 1
            }
        }
#####�⽨���ŷ��� 10011310 end####

#####��Ʊ�ࣨ�ǹ����Ʋ�Ʊ��10011701 start####
service["10011701"] = {
        "enable": True,
        "service_id": "10011701",
        "service_name": "��Ʊ�ࣨ�ǹ����Ʋ�Ʊ��",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"��ֹ�ƹ�-��Ʊ��",
              "model_label_dict": {"110201100100": "5"},
              "sub_send":[
                  { "send_name": u"���ģ��-��ֹ�ƹ��Ʊ��(100117011000)",
                    "product_id": 1
                    }] },
            { "service_id": "1001",
              "service_name": u"�������˻�url���",
              "service_module": "service_method.label_operation",
              "service_class": "LabelOperation",
              "model_id": "110200100800",
              "label_id": "1",
              "sub_send":[
                  { "send_type": URL_MONITOR,
                    "send_name": u"�������˻�url���(100117011001)",
                    "push_user_num_max": 500,
                    }] },
            { "service_id": "1002",
              "service_name": u"������Ʊ�˻�url���",
              "service_module": "service_method.label_operation",
              "service_class": "LabelOperation",
              "model_id": "110200101600",
              "label_id": "1",
              "sub_send":[
                  { "send_type": URL_MONITOR,
                    "send_name": u"������Ʊ�˻�url���(100117011102)",
                    "push_user_num_max": 500,
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.risk_user",
            "service_class": "Risk_user"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "risk_type": 10011701,
            "push_user_num_max": 50
            }
        }

#####��Ʊ�ࣨ�ǹ����Ʋ�Ʊ��10011701 end####

#####���칺��ָ�� 10010704 start####
service["10010704"] = {
        "enable": True,
        "service_id": "10010704",
        "service_name": "���칺��ָ��",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"�Ƿ�����",
              "model_label_dict": {"110203100700": "2", "110200100700": "2", "110200100800": "2|3"},
              "sub_send": [
                  { "send_name": u"���ģ��-�Ƿ�����(100107041000)"
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.risk_user",
            "service_class": "Risk_user"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10010704,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 20
            }
        }
#####���칺��ָ��10010704 end####

#####������-������ 10020358 start####
service["10020358"] = {
        "enable": True,
        "service_id": "10020358",
        "service_name": "������-������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"����������",
              "model_id": "110201100900",
              "label_id": "1",
              "opt_need": "1168|1047|1065|1069|1151",
              "sub_send": [
                  { "send_name": u"���ģ��-����������(100203581000)"
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.qualification",
            "service_class": "Qualification"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020358,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 20
            }
        }
#####������-������ 10020358 end####

#####������-Pos���� 10020359 start####
service["10020359"] = {
        "enable": True,
        "service_id": "10020359",
        "service_name": "������-Pos����",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"pos��������",
              "model_id": "110201100900",
              "label_id": "4",
              "opt_need": "1165",
              "sub_send": [
                  { "send_name": u"���ģ��-pos��������(100203591000)"
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.qualification",
            "service_class": "Qualification"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020359,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 30
            }
        }
#####������-Pos���� 10020359 end####

#####������-�ڿ��� 10020322 start####
service["10020322"] = {
        "enable": True,
        "service_id": "10020322",
        "service_name": "������-�ڿ���",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"�ڿ�������",
              "model_id": "110201100900",
              "label_id": "3",
              "opt_need": "1103",
              "sub_send": [
                  { "send_name": u"���ģ��-�ڿ�������(100203221000)"
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.qualification",
            "service_class": "Qualification"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020322,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 40
            }
        }
#####������-�ڿ��� 10020322 end####

#####��������Υ�����ף������� 10010808 start####
service["10010808"] = {
        "enable": True,
        "service_id": "10010808",
        "service_name": "��������Υ�����ף�������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"�·��տ��ٵ���-QQȺ����Ӫ������",
              "service_module": "service_method.risk_user",
              "service_class": "Risk_user",
              "model_label_dict": {"110201101400": "2"},
              "sub_send": [
                  { "send_name": u"QQ΢��Ӫ������(100108081000)",
                    "product_id": 1,
                    "deal_group": "1",
                    "send_day_interval": 10
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 10,
            "risk_type": 10010808
            }
        }
#####��������Υ�����ף������� 10010808 end####

#####��پ�Ӫ��Χ��һ�� 10020204 start####
service["10020204"] = {
        "enable": True,
        "service_id": "10020204",
        "service_name": "��پ�Ӫ��Χ��һ��",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"��پ�Ӫ��Χ��һ��",
              "model_id": "110201100100",
              "label_id": "3|6",
              "intersection": {},
              "difference": {"100100101000": "5|22|28|31"},
              "opt_intersection": "",
              "opt_difference": "",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"����-��پ�Ӫ��Χ��һ��(100202041000)",
                    "product_id": 1,
                    "deal_group": "1",
                    "send_day_interval": 1
                    }] },
            { "service_id": "1002",
              "service_name": u"��پ�Ӫ��Χ��һ��",
              "service_module": "service_method.business_scope_inconsistent",
              "service_class": "BusinessScopeInconsistent",
              "model_id": "110201100100",
              "label_id": "3|6",
              "need_model_id": "100100101000",
              "need_model_label": "5|22|28|31",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"����-����ʵ���ƹ���ע��ҳ�����(100202041002)",
                    "product_id": 1,
                    "deal_group": "1",
                    "send_day_interval": 5
                    }] },
            { "service_id": "1003",
              "service_name": u"����-��ٲ�����˾����",
              "model_id": "110201100100",
              "label_id": "3|6",
              "intersection": {"110205100800": "2"},
              "difference": {},
              "limit_ulevel": "10101",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"����-��ٲ�����˾����(100202041003)",
                    "product_id": 1,
                    "push_user_num_max": 30,
                    "deal_group": "1",
                    "send_day_interval": 1
                    }] },
            { "service_id": "1005",
              "service_name": u"�����¼",
              "service_module": "service_method.business_scope_inconsistent",
              "service_class": "BusinessScopeInconsistent",
              "model_id": "110201101400",
              "label_id": "3",
              "need_model_id": "100100101000",
              "need_model_label": "5|22|28",
              "sub_send": [
                  { "send_name": u"�����¼-��پ�Ӫ��Χ��һ��(100202041005)",
                    "product_id": 1,
                    "deal_group": "1",
                    "send_day_interval": 1
                    }] },
            { "service_id": "1006",
              "service_name": u"��پ�Ӫ��Χ��һ��-����",
              "model_id": "110202000700",
              "label_id": "8",
              "difference": {"100100101000": "37"},
              "sub_send": [
                  { "enable": False,
                    "send_name": u"��پ�Ӫ��Χ��һ��-����(100202041006)",
                    "product_id": 1,
                    "push_user_num_max": 5,
                    "deal_group": "1"
                    }] },
            { "service_id": "1007",
              "service_name": u"�Ĳ��˻�url���",
              "model_id": "110201100100",
              "label_id": "3|6",
              "sub_send": [
                  { "send_type": URL_MONITOR,
                    "send_name": u"�Ĳ��˻�url���1(100202041007)",
                    "push_user_num_max": 500,
                    }] },
            { "service_id": "1008",
              "service_name": u"�����˻�url���1",
              "model_id": "110202100100",
              "label_id": "3",
              "sub_send": [
                  { "send_type": URL_MONITOR,
                    "send_name": u"�����˻�url���1(100202041008)",
                    "push_user_num_max": 500,
                    "monitor_conf": {
                        CDC_URL: {
                            "max_num": 1,
                            "hour_interval": 12,
                            "monitor_type": [LOCAL_CRAWL, OFFSITE_CRAWL],
                            }
                        },
                    }] },
            { "service_id": "1009",
              "service_name": u"�����˻�url���2",
              "model_id": "110201100100",
              "label_id": "3",
              "sub_send": [
                  { "send_type": URL_MONITOR,
                    "send_name": u"�����˻�url���2(100202041009)",
                    "push_user_num_max": 500,
                    "monitor_conf": {
                        CDC_URL: {
                            "max_num": 1,
                            "hour_interval": 12,
                            "monitor_type": [LOCAL_CRAWL, OFFSITE_CRAWL],
                            }
                        },
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 10,
            "risk_type": 10020204
            }
        }
#####��پ�Ӫ��Χ��һ�� 10020204 end####

#####������-���ɷ��� 10020315 start####
service["10020315"] = {
        "enable": True,
        "service_id": "10020315",
        "service_name": "������-���ɷ���",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"���ɷ���������",
              "model_id": "110201100900",
              "label_id": "2",
              "opt_need": "1003|1082|1083|1084|1085|1116|1118|1173",
              "sub_send": [
                  { "send_name": u"����������-���ɷ���(100203151000)",
                    "deal_group": "1"
                    },
                  { "enable": False,
                    "send_type": AUDIT,
                    "send_name": u"����������-���ɷ���(100203151000)",
                    "risk_type": 304,
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.qualification",
            "service_class": "Qualification"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020315,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 10
            }
        }
#####������-���ɷ��� 10020315 end####

#####�ֻ���������ء���λ������Ϣ 10010901 start####
service["10010901"] = {
        "enable": True,
        "service_id": "10010901",
        "service_name": "�ֻ���������ء���λ������Ϣ",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"������λ",
              "model_label_dict": {"110203100700": "1"},
              "sub_send": [
                  { "enable": False,
                    "send_name": u"����-�Ƿ��ֻ���λ(100109011000)",
                    "deal_group": "1"
                    },
                  { "enable": False,
                    "send_type": AUDIT,
                    "send_name": u"����-�Ƿ��ֻ���λ(100109011000)",
                    "risk_type": 306,
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.risk_user",
            "service_class": "Risk_user"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10010901,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 10
            }
        }
#####�ֻ���������ء���λ������Ϣ 10010901 end####

#####������-֤��ӡˢ��ҵ 10020323 start####
service["10020323"] = {
        "enable": True,
        "service_id": "10020323",
        "service_name": "������-֤��ӡˢ��ҵ",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"֤��ӡˢ��ҵ������",
              "model_id": "110201100900",
              "label_id": "6",
              "opt_need": "1108",
              "sub_send": [
                  { "send_name": u"����������-֤��ӡˢ��ҵ(100203231000)",
                    "deal_group": "1",
                    "send_day_interval": 5
                    },
                  { "enable": False,
                    "send_type": AUDIT,
                    "send_name": u"����������-֤��ӡˢ��ҵ(100203231000)",
                    "risk_type": 305,
                    "push_user_num_max": 10
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.qualification",
            "service_class": "Qualification"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020323,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 20
            }
        }
#####������-֤��ӡˢ��ҵ 10020323 end####

#####������-��ױƷ 10020304 start####
service["10020304"] = {
        "enable": True,
        "service_id": "10020304",
        "service_name": "������-��ױƷ",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"һ�㻯ױƷ������-feedһ�㻯ױƷ������",
              "model_id": "110201000200",
              "label_opt_dict": {"8002|5023|5024":
                  "1|2|3|4|7|12|13|15|26|1009|1014|1015|1028|1144|1148|1149|11|1136|1135|13|1054|1055|" + \
                  "1119|1120|1121|1122|1123|1124|1125|1161|1169|1170|1180|1181|1182",
                  "8001":
                  "1|2|3|4|7|12|13|15|20|26|1009|1014|1015|1028|1144|1148|1149|11|1136|1135|13|1054|1055|" + \
                  "1119|1120|1121|1122|1123|1124|1125|1161|1169|1170|" + \
                  "5|6|27|30|31|32|33|1026|1027|1028|1080|1180|1181|1182"
                  },
              "white_label": {"110200100801": "4", "100100101300": "1"},
              "sub_send": [
                  { "send_name": u"���ģ��-һ�㻯ױƷ������(100203041000)",
                    "push_user_num_max": 5
                    },
                  { "send_name": u"���ģ��-һ�㻯ױƷ������(100203041000)",
                    "product_id": 2,
                    "push_user_num_max": 5
                    }] },
            { "service_id": "1001",
              "service_name": u"һ�㻯ױƷ������",
              "model_id": "110201000200",
              "label_opt_dict": {"8002|5023|5024":
              "1|2|3|4|7|12|13|15|26|1009|1014|1015|1028|1144|1148|1149|11|1136|1135|13|1054|1055|" + \
              "1119|1120|1121|1122|1123|1124|1125|1161|1169|1170|1180|1181|1182",
              "8001":
              "1|2|3|4|7|12|13|15|20|26|1009|1014|1015|1028|1144|1148|1149|11|1136|1135|13|1054|1055|" + \
              "1119|1120|1121|1122|1123|1124|1125|1161|1169|1170|" + \
              "5|6|27|30|31|32|33|1026|1027|1028|1080|1180|1181|1182"
              },
              "white_label": {"100100101500": "4", "100100101300": "1"},
              "sub_send": [
                  { "send_name": u"���ģ��-һ�㻯ױƷ������(100203041001)",
                    "push_user_num_max": 5
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.medical_qualification",
            "service_class": "MedicalQualification"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020304,
            "is_evidence_exist": 1,
            "evidence_type": 1
            }
        }
#####������-��ױƷ 10020304 end####

#####������-�ػ� 10020305 start####
service["10020305"] = {
        "enable": True,
        "service_id": "10020305",
        "service_name": "������-�ػ�",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"���⻯ױƷ������-feed���⻯ױƷ������",
              "model_id": "110201000200",
              "label_opt_dict": {"5021|5105":
              "1|2|3|4|7|12|13|15|26|1009|1014|1015|1028|1144|1148|1149|11|1136|1135|13|1169|1170|1180|1181|1182",
              "5126|5110|5120|5109|8003":
              "1|2|3|4|7|12|13|15|26|1009|1014|1015|1028|1144|1148|1149|1135|1136|1169|1170|" + \
              "5|6|1180|1181|1182",
              "5108|5107|5121|5125|5127|5034|5130|5135|5136|5137|5201|5202|5303|5304|5305":
              "1|2|3|4|7|12|13|15|26|1009|1014|1015|1028|1144|1148|1149|11|1136|1135|13|1032|1054|1055|" + \
              "1060|1086|1087|1112|1144|1169|1170|" + \
              "5|6|1180|1181|1182"
              },
              "white_label": {"100100101300": "1"},
              "sub_send": [
                  { "send_name": u"���ģ��-���⻯ױƷ������(100203051000)",
                    },
                  { "send_name": u"���ģ��-���⻯ױƷ������(100203051000)",
                    "product_id": 2,
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.medical_qualification",
            "service_class": "MedicalQualification"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020305,
            "is_evidence_exist": 1,
            "push_user_num_max": 5,
            "evidence_type": 1
            }
        }
#####������-�ػ� 10020305 end####

#####������-������ 10020361 start####
service["10020361"] = {
        "enable": True,
        "service_id": "10020361",
        "service_name": "������-������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"������-������",
              "model_id": "110202000400",
              "label_id": "1",
              "difference": {"100100101000": "35"},
              "opt_difference": "1012|1030|1036|1037|1092|1097|1098|1100|1143",
              "sub_send": [
                  { "send_name": u"������-������(100203611000)"
                    },
                  { "enable": False,
                    "send_name": u"��پ�Ӫ��Χ��һ��-������(100203611000)",
                    "deal_group": "1"
                    },
                  { "enable": False,
                    "send_type": AUDIT,
                    "send_name": u"��پ�Ӫ��Χ��һ��-������(100203611000)",
                    "risk_type": 307
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020361,
            "is_evidence_exist": 1,
            "push_user_num_max": 10,
            "evidence_type": 1
            }
        }
#####������-������ 10020361 end####

#####ˢ�ۣ��Ƿ۷�����Ϣ 10010803 start####
service["10010803"] = {
        "enable": True,
        "service_id": "10010803",
        "service_name": "ˢ�ۣ��Ƿ۷�����Ϣ",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"�·��տ��ٵ���-����ˢ�۷���",
              "model_label_dict": {"110201101400": "1"},
              "sub_send": [
                  { "send_name": u"����ˢ�۷���(100108031000)",
                    "deal_group": "1",
                    "send_day_interval": 10
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.risk_user",
            "service_class": "Risk_user"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10010803,
            "is_evidence_exist": 1,
            "push_user_num_max": 5,
            "evidence_type": 1
            }
        }
#####ˢ�ۣ��Ƿ۷�����Ϣ 10010803 end####

#####���桢��ð���˲�Ʒ 10011503 start####
service["10011503"] = {
        "enable": True,
        "service_id": "10011503",
        "service_name": "���桢��ð���˲�Ʒ",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"���ҳ�ͼ��ݳ�Ʒ",
              "model_label_dict": {"110205104400": "1"},
              "sub_send": [
                  { "enable": False,
                    "send_name": u"���ҳ�ͼ��ݳ�Ʒ(100115031000)",
                    "deal_group": "1",
                    "send_day_interval": 5
                    }] },
            { "service_id": "1001",
              "service_name": u"�����ð���ҳ",
              "service_module": "service_method.label_operation",
              "service_class": "LabelOperation",
              "model_id": "110205102300",
              "label_id": "1|4",
              "intersection": {"110205103600": "1|2"},
              "limit_product": "feed|fc",
              "difference": {"110206104300": "1"},
              "sub_send": [
                  { "enable": True,
                    "send_name": u"���ģ��-�����ð����(100115031001)",
                    }] },
            { "service_id": "1002",
              "service_name": u"���Ͼ����ð",
              "service_module": "service_method.label_operation",
              "service_class": "LabelOperation",
              "model_id": "110201102300",
              "label_id": "1|4",
              "intersection": {},
              "difference": {"110200100801": "6|7"},
              "sub_send": [
                  { "send_name": u"���Ͼ����ð����(100115031002)",
                    "is_evidence_exist": 1,
                    "evidence_type": 1
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.risk_user",
            "service_class": "Risk_user"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "push_user_num_max": 150,
            "risk_type": 10011503,
            "is_evidence_exist": 2
            }
        }
#####���桢��ð���˲�Ʒ 10011503 end####

#####�����Ϲ��ԣ������� 10040301 end####
service["10040301"] = {
        "enable": True,
        "service_id": "10040301",
        "service_name": "�����Ϲ��ԣ�������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"��ҽ������ʹ��ada����",
              "model_id": "110200100801",
              "label_id": "5",
              "intersection": {},
              "difference": {},
              "opt_intersection": "",
              "opt_difference": "1|12|28|32|1014|1015|1071|1077|1148|1149|1169|1170|" + \
                      "2|3|4|7|27|1009|1026|1027|1028|1074|1144|" + \
                      "6|11|33|1136|" + \
                      "15|21|26|29|1106|1107",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"��ҽ������ʹ��ada����(100403011000)",
                    "deal_group": "1"
                    }] },
            { "service_id": "1001",
              "service_name": u"���-��ҽ������ʹ��ada����",
              "model_id": "100100101500",
              "label_id": "5",
              "intersection": {},
              "difference": {},
              "opt_intersection": "",
              "opt_difference": "1|12|28|32|1014|1015|1071|1077|1148|1149|1169|1170|" + \
                      "2|3|4|7|27|1009|1026|1027|1028|1074|1144|" + \
                      "6|11|33|1136|" + \
                      "15|21|26|29|1106|1107",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"��ҽ������ʹ��ada����(100403011001)",
                    "deal_group": "1"
                    }] },
            { "service_id": "1002",
              "service_name": u"��Σ�豸��-��������",
              "service_module": "service_method.risk_user",
              "service_class": "Risk_user",
              "model_label_dict": {"100100102100": "1"},
              "sub_send": [
                  { "send_name": u"��Σ�豸�ż��-��������(100403011002)",
                    "push_user_num_max": 5,
                    "deal_group": "1"
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10040301,
            "is_evidence_exist": 1,
            "push_user_num_max": 10,
            "evidence_type": 1
            }
        }
#####�����Ϲ��ԣ������� 10040301 end####

#####ҽ������ 10021002 start####
service["10021002"] = {
        "enable": True,
        "service_id": "10021002",
        "service_name": "ҽ������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"��������",
              "model_id": "110205102800",
              "label_id": "1",
              "intersection": {"110205102900": "1"},
              "difference": {"110206103700": "1"},
              "opt_intersection": "",
              "opt_difference": "1171",
              "sub_send": [
                  { "send_name": u"���ģ��-����������(100210021000)"
                    }] },
            { "service_id": "1001",
              "service_name": u"��������",
              "model_id": "110205102800",
              "label_id": "2",
              "intersection": {"110205102900": "1"},
              "difference": {"110206103700": "1"},
              "opt_intersection": "",
              "opt_difference": "1171",
              "sub_send": [
                  { "send_name": u"���ģ��-����������(100210021001)",
                    "send_day_interval": 3
                    }] },
            { "service_id": "1002",
              "service_name": u"׳������",
              "model_id": "110205102800",
              "label_id": "3",
              "intersection": {"110205102900": "1"},
              "difference": {},
              "opt_intersection": "",
              "opt_difference": "1171",
              "sub_send": [
                  { "send_name": u"���ģ��-׳��������(100210021002)",
                    "send_day_interval": 3
                    }] },
            { "service_id": "1003",
              "service_name": u"�/���/���/��������",
              "model_id": "110205102800",
              "label_id": "4|5|6|7",
              "intersection": {"110205102900": "1"},
              "difference": {"110206103700": "1"},
              "opt_intersection": "",
              "opt_difference": "5|6|13|30|31|1060|1087|1135|1136|1171",
              "sub_send": [
                  { "send_name": u"���ģ��-�/���/���/����������(100210021003)",
                    "send_day_interval": 10
                    }] },
            { "service_id": "1004",
              "service_name": u"����������",
              "model_id": "110205102800",
              "label_id": "8|10|11|12|13|14|16",
              "intersection": {"110205102900": "1"},
              "difference": {"110206103700": "1"},
              "opt_intersection": "",
              "opt_difference": "9|10|1139|1140|1163|1171",
              "sub_send": [
                  { "send_name": u"���ģ��-����������(100210021004)",
                    "send_day_interval": 7
                    }] },
            { "service_id": "1005",
              "service_name": u"������ѯ������",
              "model_id": "110205102800",
              "label_id": "15",
              "intersection": {"110205102900": "1"},
              "difference": {"110206103700": "1"},
              "opt_intersection": "",
              "opt_difference": "1171",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"���ģ��-������ѯ������(100210021005)",
                    "send_day_interval": 3
                    }] },
            { "service_id": "1006",
              "service_name": u"�����ת",
              "model_id": "110204103000",
              "label_id": "2",
              "intersection": {},
              "difference": {},
              "opt_intersection": "2|3|4|6|7|11|15|21|26|27|29|33|1009|" \
                      + "1026|1027|1028|1074|1136|1144",
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"���ģ��-�����ת����(100210021006)"
                    }] },
            { "service_id": "1007",
              "service_name": u"ҽ�ƻ�������",
              "model_id": "110205104000",
              "label_id": "1|2",
              "intersection": {"110205102900": "1"},
              "difference": {"110206103700": "1"},
              "opt_intersection": "",
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"���ģ��-���ҳҽ�ƻ�������(100210021007)",
                    }] },
            { "service_id": "1008",
              "enable": False,
              "service_name": u"��Ʒһе����",
              "model_id": "110205104100",
              "label_id": "2|4|5|6|9",
              "intersection": {"110205102900": "1"},
              "difference": {"110206103700": "1", "110205102800": "17|18|19|20"},
              "opt_intersection": "",
              "opt_difference": "",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"���ģ��-���ҳ��Ʒһе����(100210021008)"
                    }] },
            { "service_id": "1009",
              "service_name": u"��������������",
              "model_id": "110205102800",
              "label_id": "21|23|24|25|26",
              "intersection": {"110205102900": "1"},
              "difference": {"110206103700": "1"},
              "opt_intersection": "",
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"���ģ��-��������������(100210021009)",
                    "send_day_interval": 7
                    }] },
            { "service_id": "1010",
              "service_name": u"�пƸ��Ƽ���������",
              "model_id": "110205102800",
              "label_id": "9",
              "intersection": {"110205102900": "1"},
              "difference": {"110206103700": "1"},
              "opt_intersection": "",
              "opt_difference": "1171|1060|1087",
              "sub_send": [
                  { "send_name": u"���ģ��-�пƸ��Ƽ���������(100210021010)",
                    "send_day_interval": 7
                    }] },
            { "service_id": "1011",
              "service_name": u"δ�������������������",
              "model_id": "110205102800",
              "label_id": "29",
              "intersection": {"110205102900": "1"},
              "difference": {"110206103700": "1"},
              "opt_intersection": "",
              "opt_difference": "1171|1060|1087",
              "sub_send": [
                  { "send_name": u"���ģ��-δ�������������������(100210021011)",
                    "send_day_interval": 7
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10021002,
            "is_evidence_exist": 2,
            "push_user_num_max": 300
            }
        }
#####ҽ������ 10021002 end####


#####������-�г������� 10020369 start####
service["10020369"] = {
        "enable": True,
        "service_id": "10020369",
        "service_name": "������-�г�������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"������-��̽����",
              "model_id": "110201000600",
              "label_id": "2201",
              "opt_need": "1041",
              "sub_send": [
                  { "send_name": u"������-��̽����(100203691000)",
                    "deal_group": "1"
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.qualification",
            "service_class": "Qualification"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020369,
            "push_user_num_max": 50,
            "is_evidence_exist": 1,
            "evidence_type": 1
            }
        }
#####������-�г������� 10020369 end####

#####������-���� 10020311 start####
service["10020311"] = {
        "enable": True,
        "service_id": "10020311",
        "service_name": "������-����",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"������-����",
              "model_id": "110201000600",
              "label_id": "1006",
              "opt_need": "23",
              "sub_send": [
                  { "send_name": u"������-����(100203111000)",
                    "deal_group": "1"
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.qualification",
            "service_class": "Qualification"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020311,
            "push_user_num_max": 50,
            "is_evidence_exist": 1,
            "evidence_type": 1
            }
        }
#####������-���� 10020311 end####

#####������-������ 10020370 start####
service["10020370"] = {
        "enable": True,
        "service_id": "10020370",
        "service_name": "������-������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"������-����",
              "model_id": "110201000600",
              "label_id": "1007",
              "opt_need": "1045",
              "sub_send": [
                  { "send_name": u"������-����(100203701000)",
                    "deal_group": "1"
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.qualification",
            "service_class": "Qualification"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020370,
            "push_user_num_max": 50,
            "is_evidence_exist": 1,
            "evidence_type": 1
            }
        }
#####������-������ 10020370 end####

#####������-��Ħ�� 10020360 start####
service["10020360"] = {
        "enable": True,
        "service_id": "10020360",
        "service_name": "������-��Ħ��",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"������-��Ħ",
              "model_id": "110201000200",
              "label_id": "5129",
              "opt_need": "19",
              "sub_send": [
                  { "send_name": u"������-��Ħ(100203601000)",
                    "deal_group": "1"
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.qualification",
            "service_class": "Qualification"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020360,
            "is_evidence_exist": 1,
            "push_user_num_max": 50,
            "evidence_type": 1
            }
        }
#####������-��Ħ�� 10020360 end####

#####������-Σ�ջ�ѧƷ 10020318 start####
service["10020318"] = {
        "enable": True,
        "service_id": "10020318",
        "service_name": "������-Σ�ջ�ѧƷ",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"������-Σ�ջ�ѧƷ",
              "model_id": "110203100700",
              "label_id": "3",
              "opt_difference": "1034",
              "limit_ulevel": "10101",
              "sub_send": [
                  { "send_name": u"������-Σ�ջ�ѧƷ(100203181000)",
                    "deal_group": "1"
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020318,
            "is_evidence_exist": 1,
            "push_user_num_max": 20,
            "evidence_type": 1
            }
        }
#####������-Σ�ջ�ѧƷ 10020318 end####

#####������-������ 10020371 start####
service["10020371"] = {
        "enable": True,
        "service_id": "10020371",
        "service_name": "������-������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"������-������",
              "model_id": "110202000400",
              "label_id": "7|16",                                   # �䵱��ǩ��Ҳ�в��ֻ���
              "opt_difference": "1037|1100|1046|1168",              # �䵱��������ʾ���
              "sub_send": [
                  { "send_name": u"������-����(100203711000)",
                    "deal_group": "1"
                    }] },
            { "service_id": "1001",
              "service_name": u"feed����",
              "service_module": "service_method.qualification_business_scope_inconsistent",
              "service_class": "BusinessScopeInconsistent",
              "model_id": "110202101100",
              "label_id": "1|2|3|4",
              "opt_need": "17|1037|1100|1046",
              "need_model_id": "100100101000",
              "need_model_label": "34",
              "sub_send": [
                  { "send_name": u"������-����(100203711001)"
                    }] },
            { "service_id": "1002",
              "service_name": u"���վ�Ӫ��Χ��һ��",
              "service_module": "service_method.qualification_business_scope_inconsistent",
              "service_class": "BusinessScopeInconsistent",
              "model_id": "110202101100",
              "label_id": "1|2|3|4",
              "opt_need": "17|1037|1100|1046",
              "need_model_id": "100100101000",
              "need_model_label": "34",
              "sub_send": [
                  { "send_name": u"������-����(100203711002)",
                    "product_id": 1
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020371,
            "is_evidence_exist": 1,
            "push_user_num_max": 30,
            "evidence_type": 1
            }
        }
#####������-������ 10020371 end####

#####������-��ֽ����� 10020387 start####
service["10020387"] = {
        "enable": True,
        "service_id": "10020387",
        "service_name": "������-��ֽ�����",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"������-��ֱ���",
              "model_id": "110203102700",
              "label_id": "1",
              "opt_difference": "1178",
              "sub_send": [
                  { "send_name": u"���ģ��-��ֱ���������(100203871000)"
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020387,
            "is_evidence_exist": 1,
            "push_user_num_max": 20,
            "evidence_type": 1
            }
        }
#####������-��ֽ����� 10020387 end####

#####���Ȳ���ȼ�� 10011706 start####
service["10011706"] = {
        "enable": True,
        "service_id": "10011706",
        "service_name": "���Ȳ���ȼ��",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"�����̽���",
              "model_id": "110203102700",
              "label_id": "2",
              "sub_send": [
                  { "send_name": u"���ģ��-�����̽���(100203871000)"
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10011706,
            "is_evidence_exist": 1,
            "push_user_num_max": 20,
            "evidence_type": 1
            }
        }
#####���Ȳ���ȼ�� 10011706 end####

#####������-������̿ͻ������� 10020381 start####
service["10020381"] = {
        "enable": True,
        "service_id": "10020381",
        "service_name": "������-������̿ͻ�������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"����������ҳ",
              "model_id": "110205103600",
              "label_id": "1",
              "difference": {"110206104300": "1", "110206104200": "1"},
              "sub_send": [
                  { "send_name": u"���ģ��-����������ҳ(100203811000)"
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020381,
            "push_user_num_max": 50,
            "is_evidence_exist": 2
            }
        }
#####������-������̿ͻ������� 10020381 end####

#####������-���ϻ����� 10020388 start####
service["10020388"] = {
        "enable": True,
        "service_id": "10020388",
        "service_name": "������-���ϻ�����",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"���ϻ���������",
              "model_id": "110201000600",
              "label_id": "1104",
              "opt_need": "1179|20|1|12",
              "need_model_id": "100100101000",
              "need_model_label": "38",
              "sub_send": [
                  { "send_name": u"������-���ϻ���(100203881000)"
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.qualification_business_scope_inconsistent",
            "service_class": "BusinessScopeInconsistent"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020388,
            "is_evidence_exist": 1,
            "push_user_num_max": 50,
            "evidence_type": 1
            }
        }
#####������-���ϻ����� 10020388 end####

####�ṩSEO���������Ż����� 10010807 start####
service["10010807"] = {
        "enable": True,
        "service_id": "10010807",
        "service_name": "�ṩSEO���������Ż�����",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"seo����(unit, click)",
              "model_id": "110204103000",
              "label_id": "1",
              "intersection": {"110201101800": "9101|9102|9103|9104|9105"},
              "difference": {},
              "limit_consume": 0.00001,
              "sub_send": [
                  { "enable": False,
                    "send_name": u"seo����(100108071000)",
                    "product_id": 1,
                    "evidence_type": 1,
                    "push_user_num_max": 10,
                    "deal_group": "1"
                    }] },
            { "service_id": "1001",
              "service_name": u"seo����(unit)",
              "model_id": "110204103000",
              "label_id": "1",
              "intersection": {"110201101900": "4"},
              "difference": {},
              "limit_consume": 0.00001,
              "sub_send": [
                  { "enable": False,
                    "send_name": u"seo����(100108071001)",
                    "product_id": 1,
                    "push_user_num_max": 30,
                    "deal_group": "1"
                    }] },
            { "service_id": "1002",
              "service_name": u"seo����(unit)",
              "model_id": "110201101900",
              "label_id": "1|2",
              "intersection": {},
              "difference": {},
              "sub_send": [
                  { "enable": False,
                    "send_name": u"SEO����(100108071002)",
                    "product_id": 1,
                    "is_evidence_exist": 1,
                    "evidence_type": 1,
                    "push_user_num_max": 50,
                    "deal_group": "1"
                    }] },
            { "service_id": "1003",
              "service_name": u"SEO�����˻�url���",
              "model_id": "110201101800",
              "label_id": "9101|9102|9103|9104|9105|9201",
              "sub_send": [
                  { "send_type": URL_MONITOR,
                    "send_name": u"SEO�����˻�url���(100108071003)",
                    "push_user_num_max": 500,
                    "is_evidence_exist": 1,
                    "evidence_type": 1,
                    }] },
            { "service_id": "1004",
              "service_name": u"SEO�����˻�url���2",
              "model_id": "110201101900",
              "label_id": "4",
              "sub_send": [
                  { "send_type": URL_MONITOR,
                    "send_name": u"SEO�����˻�url���2(100108071004)",
                    "push_user_num_max": 500,
                    "is_evidence_exist": 1,
                    "evidence_type": 1,
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "is_evidence_exist": 2,
            "risk_type": 10010807
            }
        }
####�ṩSEO���������Ż����� 10010807 end####

#####���̼��˿������ 10021005 start####
service["10021005"] = {
        "enable": True,
        "service_id": "10021005",
        "service_name": "���̼��˿������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"���ҳ��׬",
              "model_label_dict": {"110205104500": "2"},
              "sub_send": [
                  { "send_name": u"���ģ��-���ҳ��׬(10021005)"
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.risk_user",
            "service_class": "Risk_user"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10021005,
            "push_user_num_max": 50,
            "is_evidence_exist": 2
            }
        }
#####���̼��˿������ 10021005 end####

#####���ٳ�Ϊ���������ƽ̨������ 10011609 start####
service["10011609"] = {
        "enable": True,
        "service_id": "10011609",
        "service_name": "���ٳ�Ϊ���������ƽ̨������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"���ҳ�����ٳ�",
              "model_id": "110204104600",
              "label_id": "4",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"���ҳ�����ٳ�(10011609)"
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10011609,
            "push_user_num_max": 10,
            "is_evidence_exist": 2
            }
        }
#####���ٳ�Ϊ���������ƽ̨������ 10011609 end####

#####������-���������� 10020364 start####
service["10020364"] = {
        "enable": True,
        "service_id": "10020364",
        "service_name": "������-����������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"������-��������",
              "model_id": "110202102200",
              "label_id": "8",
              "opt_difference": "1031",
              "main_difference": "1012|1013",
              "limit_ulevel": "10101",
              "sub_send": [
                  { "send_name": u"������-��������(100203641000)",
                    "deal_group": "1"
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020364,
            "is_evidence_exist": 1,
            "push_user_num_max": 10,
            "evidence_type": 1
            }
        }
#####������-���������� 10020364 end####

#####������-�ɻ����������� 10020373 start####
service["10020373"] = {
        "enable": True,
        "service_id": "10020373",
        "service_name": "������-�ɻ�����������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"������-�ɻ���������",
              "model_id": "110202102200",
              "label_id": "9",
              "opt_difference": "1048",
              "main_difference": "1012|1013",
              "limit_ulevel": "10101",
              "sub_send": [
                  { "send_name": u"������-�ɻ���������(100203731000)",
                    "deal_group": "1"
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": QUALIFICATION,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020373,
            "is_evidence_exist": 1,
            "push_user_num_max": 10,
            "evidence_type": 1
            }
        }
#####������-�ɻ����������� 10020373 end####

#####�漰����ͼƬ������ 10010511 start####
service["10010511"] = {
        "enable": True,
        "service_id": "10010511",
        "service_name": "�漰����ͼƬ������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"LP-����������վ",
              "model_id": "110205103301",
              "label_id": "1",
              "sub_send": [
                  { "send_name": u"���ģ��-���ҳ������վ(100105111000)"
                    }] },
            { "service_id": "1001",
              "service_name": u"LP-�����ṩ�Է���",
              "model_id": "110205103302",
              "label_id": "2",
              "sub_send": [
                  { "send_name": u"���ģ��-���ҳ�ṩ�Է���(100105111001)"
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10010511,
            "push_user_num_max": 20,
            "is_evidence_exist": 2
            }
        }
#####�漰����ͼƬ������ 10010511 end####

#####��ֹ�����ƹ���flash����Ƕ�׵������ⲿ���ӽ�����ת 10010809 start####
service["10010809"] = {
        "enable": True,
        "service_id": "10010809",
        "service_name": "��ֹ�����ƹ���flash����Ƕ�׵������ⲿ���ӽ�����ת",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"���ҳ�漰��ת",
              "model_id": "110204103900",
              "label_id": "1",
              "intersection": {},
              "difference": {},
              "opt_intersection": "2|3|4|6|7|11|15|21|26|27|29|33|1009|" + \
                      "1026|1027|1028|1074|1136|1144",
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"���ģ��-���ҳ�漰��ת����(100108091000)"
                    }] },
            ],
        "based_service": {
            "enable": False,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": False,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 1,
            "is_evidence_exist": 2,
            "push_user_num_max": 150,
            "evidence_type": 1
            }
        }
#####��ֹ�����ƹ���flash����Ƕ�׵������ⲿ���ӽ�����ת 10010809 end####

#####������-������ѧ�н��� 10020375 start####
service["10020375"] = {
        "enable": True,
        "service_id": "10020375",
        "service_name": "������-������ѧ�н���",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"������ѧ�н�������",
              "model_id": "110201102600",
              "label_id": "1",
              "difference": {"100100101300": "3"},
              "opt_difference": "1050",
              "sub_send": [
                  { "send_name": u"������-������ѧ�н�(100203751000)",
                    "deal_group": "1"
                    }] },
            { "enable": False,
              "service_id": "1001",
              "service_name": u"������ѧ�н������ʲ��ھ�Ӫ��Χ",
              "model_id": "110201102600",
              "label_id": "1",
              "difference": {"100100101000": "39"},
              "opt_difference": "1050",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"unit_������ѧ�н�(100203751001)"
                    }] }
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020375,
            "is_evidence_exist": 1,
            "push_user_num_max": 20,
            "evidence_type": 1
            }
        }
#####������-������ѧ�н��� 10020375 end####

#####�Ƿ����Թ��� 10011111 start####
service["10011111"] = {
        "enable": True,
        "service_id": "10011111",
        "service_name": "�Ƿ����Թ���",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"���Թ���",
              "model_id": "110201103100",
              "label_id": "2|5",
              "intersection": {},
              "difference": {},
              "opt_intersection": "",
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"���ģ��-���Թ�����(100111111000)"
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10011111,
            "is_evidence_exist": 1,
            "push_user_num_max": 20,
            "evidence_type": 1
            }
        }
#####�Ƿ����Թ��� 10011111 end####

#####�������� 10010519 start####
service["10010519"] = {
        "enable": True,
        "service_id": "10010519",
        "service_name": "��������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"LP-���״ʱ�",
              "model_id": "110205103800",
              "label_id": "1",
              "sub_send": [
                  { "send_name": u"���ģ��-���ҳ��������������(100105191000)"
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 3,
            "push_user_num_max": 20,
            "is_evidence_exist": 2
            }
        }
#####�������� 10010519 end####

#####��������أ������� 10040106 start####
service["10040106"] = {
        "enable": True,
        "service_id": "10040106",
        "service_name": "��������أ�������",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"�������ϡ�ע��ҳ��һ��",
              "model_id": "110207103200",
              "label_id": "1",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"���ģ��-�������ϡ�ע��ҳ��һ��(100401061000)",
                    "deal_group": 1
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10040106,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 40
            }
        }
#####��������أ������� 10040106 end####

#####������-��Ƶֱ���� 10020393 start####
service["10020393"] = {
        "enable": True,
        "service_id": "10020393",
        "service_name": "������-��Ƶֱ����",
        "sub_service": [
            { "service_id": "1000",
              "service_name": u"������-��Ƶֱ����",
              "model_id": "120200102000",
              "label_id": "3",
              "opt_difference": "1126",
              "sub_send": [
                  { "enable": True,
                    "send_name": u"������-��Ƶֱ����(100203931000)",
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SUPERVISE,
            "product_id": 1,
            "risk_type": 10020393,
            "is_evidence_exist": 1,
            "evidence_type": 1,
            "push_user_num_max": 40
            }
        }
#####������-��Ƶֱ���� 10020393 end####

######�й����� 10011614 start####
service["10011614"] = {
        "enable": True,
        "service_id": "10011614",
        "service_name": "�й�����",
        "sub_service": [
            {"service_id": "1000",
              "service_name": u"�˻�-��ˮ-������ˮ����",
              "model_id": "110201105600",
              "label_id": "1",
              "intersection": {},
              "difference": {"110200100801": "8|9|10|12", "110201105700": "11"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"�˻�-������ˮ����",
                    "send_day_interval": 7,
                    "evidence_type": 1
                    }] },
            {"service_id": "1001",
              "service_name": u"�˻�-��ˮ-ę́����Һ��ˮ����",
              "model_id": "110200100801",
              "label_id": "8",
              "intersection": {"110201105600": "1"},
              "difference": {"110201105700": "11", "110200100801": "12"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"�˻�-ę́����Һ��ˮ����",
                    "send_day_interval": 7,
                    "evidence_type": 1
                    }] },
            {"service_id": "1002",
              "service_name": u"�˻�-��ˮ-����Һ��ˮ����",
              "model_id": "110200100801",
              "label_id": "9",
              "intersection": {"110201105600": "1"},
              "difference": {"110201105700": "11", "110200100801": "12"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"�˻�-����Һ��ˮ����",
                    "send_day_interval": 7,
                    "evidence_type": 1
                    }] },
            {"service_id": "1003",
              "service_name": u"�˻�-��ˮ-���ƾ�ˮ����",
              "model_id": "110200100801",
              "label_id": "10",
              "intersection": {"110201105600": "1"},
              "difference": {"110201105700": "11", "110200100801": "12"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"�˻�-���ƾ�ˮ����",
                    "send_day_interval": 7,
                    "evidence_type": 1
                    }] },
            {"service_id": "1004",
              "service_name": u"�˻�-ҩƷ����",
              "model_id": "110201105800",
              "label_id": "2",
              "intersection": {},
              "difference": {"110201105700": "11"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"�˻�-ҩƷ����(100116141004)",
                    "send_day_interval": 7,
                    "evidence_type": 1
                    }] },
            {"service_id": "1005",
              "service_name": u"���ҳ-��ˮ-������ˮ����",
              "model_id": "110201105601",
              "label_id": "1",
              "intersection": {},
              "difference": {"110206104201": "1", "110205102300": "1|2|3|4"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-��ˮ����",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1006",
              "service_name": u"���ҳ-��ˮ�漰��������",
              "model_id": "110205102300",
              "label_id": "1|3|4|5|6|7|8|9",
              "intersection": {"110205102900": "1"},
              "difference": {"110206104201": "1", "110201105601": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-��ˮ�漰��������",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1007",
              "service_name": u"�˻�-���⻯ױƷ�������",
              "model_id": "110201105800",
              "label_id": "1",
              "intersection": {"110201000200": "5126"},
              "difference": {"110201105700": "11"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"�˻�-���⻯ױƷ�������(100116141007)",
                    "send_day_interval": 7,
                    "evidence_type": 1
                    }] },
            {"service_id": "1008",
              "service_name": u"���ҳ-ҩƷ����",
              "model_id": "110205105800",
              "label_id": "1",
              "intersection": {},
              "difference": {"110201105700": "11", "110206105801": "1", "110206104201": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-ҩƷ����(100116141008)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1009",
              "service_name": u"���ҳ-ҩƷ����Ʒ���⻯ױƷ��������-ҩƷǿ��������",
              "model_id": "110204105800",
              "label_id": "1",
              "intersection": {"110205102800": "1|2"},
              "difference": {"110201105700": "11", "110206105801": "1", "110206104201": "1", "110206105802": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-ҩƷ����Ʒ���⻯ױƷ��������-ҩƷǿ��������(100116141009)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1010",
              "service_name": u"���ҳ-ҩƷ����Ʒ���⻯ױƷ��������-ҩƷ���ƹ���",
              "model_id": "110204105800",
              "label_id": "2",
              "intersection": {"110205102800": "1"},
              "difference": {"110201105700": "11", "110206105801": "1", "110206104201": "1", "110206105802": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-ҩƷ����Ʒ���⻯ױƷ��������-ҩƷ���ƹ���(100116141010)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1011",
              "service_name": u"���ҳ-ҩƷ����Ʒ���⻯ױƷ��������-ҩƷ��������",
              "model_id": "110204105800",
              "label_id": "3",
              "intersection": {"110205102800": "1|2|3"},
              "difference": {"110201105700": "11", "110206105801": "1", "110206104201": "1", "110206105802": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-ҩƷ����Ʒ���⻯ױƷ��������-ҩƷ��������(100116141011)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1012",
              "service_name": u"���ҳ-ҩƷ����Ʒ���⻯ױƷ��������-���⻯ױƷǿ��������",
              "model_id": "110204105800",
              "label_id": "5",
              "intersection": {"110205102800": "2"},
              "difference": {"110201105700": "11", "110206105801": "1", "110206104201": "1", "110206105802": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-ҩƷ����Ʒ���⻯ױƷ��������-���⻯ױƷǿ��������(100116141012)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1013",
              "service_name": u"���ҳ-��ˮ-ę́��ˮ����",
              "model_id": "110201105601",
              "label_id": "1",
              "intersection": {"110205102300": "1|2|3"},
              "difference": {"110206104201": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-ę́��ˮ����",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1014",
              "service_name": u"���ҳ-��ˮ-����Һ��ˮ����",
              "model_id": "110201105601",
              "label_id": "1",
              "intersection": {"110205102300": "4"},
              "difference": {"110206104201": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-����Һ��ˮ����",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1015",
              "service_name": u"�˻�-����Ʒ����",
              "model_id": "110201105800",
              "label_id": "3",
              "intersection": {},
              "difference": {"110201105700": "11"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"�˻�-����Ʒ����(100116141015)",
                    "send_day_interval": 7,
                    "evidence_type": 1
                    }] },
            {"service_id": "1016",
              "service_name": u"�˻�-���⻯ױƷ����",
              "model_id": "110201105800",
              "label_id": "7",
              "intersection": {},
              "difference": {"110201105700": "11"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"�˻�-���⻯ױƷ����(100116141016)",
                    "send_day_interval": 7,
                    "evidence_type": 1
                    }] },
            {"service_id": "1017",
              "service_name": u"���ҳ-����Ʒ����",
              "model_id": "110205105800",
              "label_id": "2",
              "intersection": {},
              "difference": {"110201105700": "11", "110206105801": "1", "110206104201": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-����Ʒ����(100116141017)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1018",
              "service_name": u"���ҳ-���⻯ױƷ����",
              "model_id": "110205105800",
              "label_id": "7",
              "intersection": {},
              "difference": {"110201105700": "11", "110206105801": "1", "110206104201": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-���⻯ױƷ����(100116141018)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1019",
              "service_name": u"�˻�-һ�㻯ױƷ����",
              "model_id": "110201105800",
              "label_id": "4",
              "intersection": {},
              "difference": {"110201105700": "11"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"�˻�-һ�㻯ױƷ����(100116141019)",
                    "send_day_interval": 7,
                    "evidence_type": 1
                    }] },
            {"service_id": "1020",
              "service_name": u"���ҳ-һ�㻯ױƷ����",
              "model_id": "110205105800",
              "label_id": "3",
              "intersection": {},
              "difference": {"110201105700": "11", "110206105801": "1", "110206104201": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-һ�㻯ױƷ����(100116141020)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1021",
              "service_name": u"���ҳ-���⻯ױƷ����-��ױƷ��Ч��ѯҳ",
              "model_id": "110205106000",
              "label_id": "1",
              "intersection": {"110205105900": "2|7|8|10|16|25"},
              "difference": {},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-���⻯ױƷ����-��ױƷ��Ч��ѯҳ(100116141021)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1022",
              "service_name": u"���ҳ-һ�㻯ױƷ����-��ױƷ��Ч��ѯҳ",
              "model_id": "110205106000",
              "label_id": "1",
              "intersection": {"110205105900": "1|3|5|6|13|14|28|29"},
              "difference": {},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-һ�㻯ױƷ����-��ױƷ��Ч��ѯҳ(100116141022)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1023",
              "service_name": u"���ҳ-���⻯ױƷ����-��ױƷ��Ч��������",
              "model_id": "110205106100",
              "label_id": "1",
              "intersection": {"110205105900": "2|7|8|10|16"},
              "difference": {},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-���⻯ױƷ����-��ױƷ��Ч��������(100116141023)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1024",
              "service_name": u"���ҳ-һ�㻯ױƷ����-��ױƷ��Ч��������",
              "model_id": "110205106100",
              "label_id": "1",
              "intersection": {"110205105900": "1|4|5|6|9|12|13|15|17|18|19|27|29"},
              "difference": {},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-һ�㻯ױƷ����-��ױƷ��Ч��������(100116141024)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1025",
              "service_name": u"���ҳ-��Ʒ����-�����������",
              "model_id": "110205106100",
              "label_id": "1",
              "intersection": {"110205105900": "25"},
              "difference": {},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-��Ʒ����-�����������(100116141025)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1026",
              "service_name": u"���ҳ-һ�㻯ױƷ����-��ױƷ��Ч���˾�������",
              "model_id": "110205102900",
              "label_id": "1",
              "intersection": {"110205105900": "1|3|4|5|6|9|12|14|15|17|18|19|21|23|26|27|29"},
              "difference": {"110206105803": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-һ�㻯ױƷ����-��ױƷ��Ч���˾�������(100116141026)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1027",
              "service_name": u"���ҳ-���⻯ױƷ����-��ױƷ��Ч���˾�������",
              "model_id": "110205102900",
              "label_id": "1",
              "intersection": {"110205105900": "2|7|8|10|16|22|25"},
              "difference": {"110206105803": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-���⻯ױƷ����-��ױƷ��Ч���˾�������(100116141027)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1028",
              "service_name": u"���ҳ-ҩƷ����-ͼƬOCR��Ϣ",
              "model_id": "110208105800",
              "label_id": "1|2",
              "intersection": {},
              "difference": {},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-ҩƷ����-ͼƬOCR��Ϣ(100116141028)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1029",
              "service_name": u"���ҳ-����Ʒ����-ͼƬOCR��Ϣ",
              "model_id": "110208105800",
              "label_id": "3",
              "intersection": {},
              "difference": {},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"���ҳ-����Ʒ����-ͼƬOCR��Ϣ(100116141029)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1030",
              "service_name": u"�˻�-��������-���",
              "model_id": "110201105900",
              "label_id": "11",
              "intersection": {},
              "difference": {"110200100801": "11"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"�˻�-��������-���(100116141030)",
                    "send_day_interval": 7,
                    "evidence_type": 1
                    }] },
            {"service_id": "1031",
              "service_name": u"�˻�-��������-�������",
              "model_id": "110201105900",
              "label_id": "10|13|14|15|16|17|18|29",
              "intersection": {},
              "difference": {"110200100801": "11"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"�˻�-��������-�������(100116141031)",
                    "send_day_interval": 7,
                    "evidence_type": 1
                    }] },
            {"service_id": "1032",
              "service_name": u"�˻�-��������-���˴���",
              "model_id": "110201105900",
              "label_id": "12|30",
              "intersection": {},
              "difference": {"110200100801": "11"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "send_name": u"�˻�-��������-���˴���(100116141032)",
                    "send_day_interval": 7,
                    "evidence_type": 1
                    }] },
            {"service_id": "1033",
              "enable": False,
              "service_name": u"���ҳ-��������-���",
              "model_id": "110201105902",
              "label_id": "19",
              "intersection": {},
              "difference": {"110206104201": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "enable": False,
                     "send_name": u"���ҳ-��������-���(100116141033)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1034",
              "enable": False,
              "service_name": u"���ҳ-��������-�������",
              "model_id": "110201105902",
              "label_id": "15|16|17|18|20|21|22|23|24",
              "intersection": {},
              "difference": {"110206104201": "1"},
              "opt_difference": "1145|1195|1196|1197",
              "sub_send": [
                  { "enable": False,
                    "send_name": u"���ҳ-��������-�������(100116141034)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1035",
              "service_name": u"�˻�-ʳƷ����",
              "model_id": "110201106200",
              "label_id": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15" + \
                      "|16|17|18|19|20|21|22|23|24|25|26|27|28|29|" + \
                      "30|31|33|35|36|37|38|39|40|41|42|43|44|45|46|" + \
                      "47|48|49|50|51|52|53|54|55|56|57|58|59|60|61|62|63|64",
              "intersection": {},
              "difference": {"110200101201": "1|2", "110202101101": "1|2|3|4|5|6|7", "110200100801": "11"},
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"�˻�-ʳƷ����(100116141035)",
                    "send_day_interval": 7,
                    "evidence_type": 1
                    }] },
            {"service_id": "1036",
              "service_name": u"���ҳ-ʳƷ����",
              "model_id": "110205106200",
              "label_id": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15" + \
                      "|16|17|18|19|20|21|22|23|24|25|26|27|28|29|" + \
                      "30|31|33|35|36|37|38|39|40|41|42|43|44|45|46|" + \
                      "47|48|49|50|51|52|53|54|55|56|57|58|59|60|61|62|63|64",
              "intersection": {},
              "difference": {"110206106201": "1"},
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"���ҳ-ʳƷ����(100116141036)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1037",
              "service_name": u"���ҳ-����-���˾�������",
              "model_id": "110205106400",
              "label_id": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15" + \
                      "|16|17|18|19|20|21|22|23|24|25|26|27|28|29|" + \
                      "30|31|32|33|34|35|36|37|38|39|40|41|42",
              "intersection": {"110205102900": "1"},
              "difference": {"110205106200": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15" + \
                      "|16|17|18|19|20|21|22|23|24|25|26|27|28|29|" + \
                      "30|31|32|33|34|35|36|37|38|39|40|41|42|43|44|45|46|" + \
                      "47|48|49|50|51|52|53|54|55|56|57|58|59|60|61|62|63|64",
                      "110206105803": "1"},
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"���ҳ-����-���˾�������(100116141037)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1038",
              "service_name": u"���ҳ-����-������ѯҳ",
              "model_id": "110205106400",
              "label_id": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15" + \
                      "|16|17|18|19|20|21|22|23|24|25|26|27|28|29|" + \
                      "30|31|32|33|34|35|36|37|38|39|40|41|42",
              "intersection": {"110205106000": "1"},
              "difference": {"110205106200": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15" + \
                      "|16|17|18|19|20|21|22|23|24|25|26|27|28|29|" + \
                      "30|31|32|33|34|35|36|37|38|39|40|41|42|43|44|45|46|" + \
                      "47|48|49|50|51|52|53|54|55|56|57|58|59|60|61|62|63|64",
                      "110206105803": "1"},
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"���ҳ-����-������ѯҳ(100116141038)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1039",
              "service_name": u"���ҳ-����-��������",
              "model_id": "110205106400",
              "label_id": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15" + \
                      "|16|17|18|19|20|21|22|23|24|25|26|27|28|29|" + \
                      "30|31|32|33|34|35|36|37|38|39|40|41|42",
              "intersection": {"110205106100": "1"},
              "difference": {"110205106200": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15" + \
                      "|16|17|18|19|20|21|22|23|24|25|26|27|28|29|" + \
                      "30|31|32|33|34|35|36|37|38|39|40|41|42|43|44|45|46|" + \
                      "47|48|49|50|51|52|53|54|55|56|57|58|59|60|61|62|63|64",
                      "110206105803": "1"},
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"���ҳ-����-��������(100116141039)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1040",
              "service_name": u"���ҳ-��������-���˾�������",
              "model_id": "110205106300",
              "label_id": "1|2",
              "intersection": {"110205102900": "1"},
              "difference": {"110205106200": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15" + \
                      "|16|17|18|19|20|21|22|23|24|25|26|27|28|29|" + \
                      "30|31|32|33|34|35|36|37|38|39|40|41|42|43|44|45|46|" + \
                      "47|48|49|50|51|52|53|54|55|56|57|58|59|60|61|62|63|64",
                      "110206105803": "1"},
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"���ҳ-��������-���˾�������(100116141040)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1041",
              "service_name": u"���ҳ-��������-������ѯҳ",
              "model_id": "110205106300",
              "label_id": "1|2",
              "intersection": {"110205106000": "1"},
              "difference": {"110205106200": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15" + \
                      "|16|17|18|19|20|21|22|23|24|25|26|27|28|29|" + \
                      "30|31|32|33|34|35|36|37|38|39|40|41|42|43|44|45|46|" + \
                      "47|48|49|50|51|52|53|54|55|56|57|58|59|60|61|62|63|64",
                      "110206105803": "1"},
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"���ҳ-��������-������ѯҳ(100116141041)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1042",
              "service_name": u"���ҳ-��������-��������",
              "model_id": "110205106300",
              "label_id": "1|2",
              "intersection": {"110205106100": "1"},
              "difference": {"110205106200": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15" + \
                      "|16|17|18|19|20|21|22|23|24|25|26|27|28|29|" + \
                      "30|31|32|33|34|35|36|37|38|39|40|41|42|43|44|45|46|" + \
                      "47|48|49|50|51|52|53|54|55|56|57|58|59|60|61|62|63|64",
                      "110206105803": "1"},
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"���ҳ-��������-��������(100116141042)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            {"service_id": "1043",
              "service_name": u"�˻�-ҽ����е����",
              "model_id": "110201105800",
              "label_id": "6",
              "intersection": {},
              "difference": {"110201105700": "11"},
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"�˻�-ҽ����е����(100116141043)",
                    "send_day_interval": 7,
                    "evidence_type": 1
                    }] },
            {"service_id": "1044",
              "service_name": u"���ҳ-ҽ����е����",
              "model_id": "110205105800",
              "label_id": "5",
              "intersection": {},
              "difference": {"110201105700": "11", "110206105801": "1", "110206104201": "1"},
              "opt_difference": "",
              "sub_send": [
                  { "send_name": u"���ҳ-ҽ����е����(100116141044)",
                    "send_day_interval": 7,
                    "evidence_type": 2
                    }] },
            ],
        "based_service": {
            "enable": True,
            "service_type": RISK_USER,
            "service_module": "service_method.label_operation",
            "service_class": "LabelOperation"
            },
        "based_send": {
            "enable": True,
            "send_type": SEND_HDFS,
            "is_evidence_exist": 1,
            "push_user_num_max": 300,
            "risk_type": 10011614 
            }
    }
######�й����� 10011614 end####
