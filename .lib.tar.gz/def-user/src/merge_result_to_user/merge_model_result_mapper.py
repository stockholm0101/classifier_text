#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   zhukaiwen@baidu.com
#Date  :   19/05/09 14:09:12
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os
import json

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object
import review_object.merge_object as merge_object
import conf

if __name__ == "__main__":
    for eachline in sys.stdin:
        try:
            file_name = os.environ["mapreduce_map_input_file"] if "mapreduce_map_input_file" in \
                    os.environ else os.environ["map_input_file"]
            #1. ad result 2. unit result 3. user result 4. meteor result 5. other result
            which_file = conf.MODEL_TYPE_AD
            if "-merge-trade-unit" in file_name:
                which_file = conf.MODEL_TYPE_UNIT
            elif "-predict-trade-user" in file_name or "-append-trade-user" in file_name:
                which_file = conf.MODEL_TYPE_USER
            elif "-meteor-user-result" in file_name:
                which_file = conf.MODEL_TYPE_METEOR
            elif "-other-user-result" in file_name:
                which_file = conf.MODEL_TYPE_OTHER
            elif "-merge-trade-click-ad" in file_name:
                which_file = conf.MODEL_TYPE_CLICK_AD
            elif "-merge-trade-meteor-ad" in file_name:
                which_file = conf.MODEL_TYPE_METEOR_AD
            elif "-predict-trade-click-user" in file_name or "-append-trade-click-user" in file_name:
                which_file = conf.MODEL_TYPE_CLICK_USER
            elif "-lp-processed" in file_name:
                which_file = conf.MODEL_TYPE_LP
            elif "-merge-trade-url" in file_name:
                which_file = conf.MODEL_TYPE_URL
        except:
            which_file = int(sys.argv[1])

        userid = None
        if which_file == conf.MODEL_TYPE_AD:
            pass
        elif which_file == conf.MODEL_TYPE_UNIT or which_file == conf.MODEL_TYPE_METEOR or \
                which_file == conf.MODEL_TYPE_CLICK_AD or which_file == conf.MODEL_TYPE_METEOR_AD or \
                which_file == conf.MODEL_TYPE_URL:
            merge_obj = merge_object.MergeObj()
            merge_obj.init_from_json(eachline.strip())
            userid = merge_obj.userid
        elif which_file == conf.MODEL_TYPE_USER:
            review_user_obj = review_object.ReviewUserObj()
            review_user_obj.init_from_json(eachline.strip())
            userid = review_user_obj.userid
        elif which_file == conf.MODEL_TYPE_CLICK_USER:
            review_user_obj = review_object.ReviewClickUserObj()
            review_user_obj.init_from_json(eachline.strip())
            userid = review_user_obj.userid
        elif which_file == conf.MODEL_TYPE_OTHER or which_file == conf.MODEL_TYPE_LP:
            review_risk_user = review_object.ReviewRiskUserObj()
            review_risk_user.init_from_json(eachline.strip())
            userid = review_risk_user.userid

        if userid is not None:
            print "\t".join([userid, str(which_file), eachline.strip()])
