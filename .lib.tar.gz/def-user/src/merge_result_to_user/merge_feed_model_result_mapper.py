#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author: zhanghao55@baidu.com
Date  : 20/03/09 14:09:12
Desc  : feed����˽���ϲ�mapper
"""

import sys
import os
import json

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object
import review_object.merge_object as merge_object
import conf

if __name__ == "__main__":
    for eachline in sys.stdin:
        try:
            file_name = os.environ["mapreduce_map_input_file"] if "mapreduce_map_input_file" in \
                    os.environ else os.environ["map_input_file"]
            # MODEL_TYPE_FEED_AD = 11, feed����ά��
            # MODEL_TYPE_FEED_USER = 12, feed�˻�ά��
            which_file = None
            if "-merge-trade-feed-ad" in file_name:
                which_file = conf.MODEL_TYPE_FEED_AD
            elif "-append-trade-feed-user" in file_name:
                which_file = conf.MODEL_TYPE_FEED_USER
            elif "-append-trade-feed-idea-ad" in file_name or "-merge-trade-feed-idea-ad" in file_name:
                which_file = conf.MODEL_TYPE_FEED_IDEA_AD
            elif "-append-trade-feed-unit" in file_name or "-merge-trade-feed-unit" in file_name:
                which_file = conf.MODEL_TYPE_FEED_IDEA_UNIT
            elif "-append-trade-feed-idea-user" in file_name:
                which_file = conf.MODEL_TYPE_FEED_IDEA_USER
        except KeyError as e:
            which_file = int(sys.argv[1])

        userid = None
        if which_file in [conf.MODEL_TYPE_FEED_AD, conf.MODEL_TYPE_FEED_IDEA_AD, \
                conf.MODEL_TYPE_FEED_IDEA_UNIT]:
            merge_obj = merge_object.MergeObj()
            merge_obj.init_from_json(eachline.strip())
            userid = merge_obj.userid
        elif which_file == conf.MODEL_TYPE_FEED_USER:
            review_feed_user_obj = review_object.ReviewFeedUserObj()
            review_feed_user_obj.init_from_json(eachline.strip())
            userid = review_feed_user_obj.userid
        elif which_file == conf.MODEL_TYPE_FEED_IDEA_USER:
            review_feed_user_obj = review_object.ReviewFeedIdeaUserObj()
            review_feed_user_obj.init_from_json(eachline.strip())
            userid = review_feed_user_obj.userid

        if userid is not None:
            print "\t".join([userid, str(which_file), eachline.strip()])
