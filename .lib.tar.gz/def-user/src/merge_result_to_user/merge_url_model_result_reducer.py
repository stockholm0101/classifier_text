#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/05/14 17:43:41
Desc  :   
"""
import sys
import os
import json

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object
import review_object.merge_object as merge_object
import conf
import merge_url_model_result_mapper


def convert_to_merge(which_file, json_str):
    """תΪMergeObj
    """
    user_model_evidence = {}
    model_result = []
    product_set = set()
    if which_file == conf.MODEL_TYPE_URL_MONITOR:
        # URL�Ľ����merge��user��
        merge_obj = merge_object.MergeObj()
        merge_obj.init_from_json(json_str)
        model_result = merge_obj.check_result
        # ����Ҫuser_model_evidence
    if which_file == merge_url_model_result_mapper.URL_MONITOR_USER_INFO:
        # ������˻�������check_result��user_model_evidence������
        url_with_info = json.loads(json_str)
        model_result = url_with_info["check_result"]
        user_model_evidence = url_with_info["user_model_evidence"]
        product_set = set(url_with_info["product"].split("|"))

    return product_set, user_model_evidence, model_result


if __name__ == "__main__":
    old_userid = None
    user_result = merge_object.MergeObj()
    # url_monitor���˻���product��url��������Ϣ��
    product_set = set()
    # reduce�׶� ����˻�������check_resultֻ����һ��
    url_monitor_user_info_added = False

    for eachline in sys.stdin:
        line = eachline.strip("\n").split("\t")
        userid = line[0]
        which_file = int(line[1])
        json_str = line[2]

        if old_userid != userid:
            if old_userid is not None:
                # ���Ӳ�Ʒ��
                user_result.info["product"] = "|".join(product_set)
                print json.dumps(user_result.merge_result())
            user_result.init(userid)
            product_set.clear()
            url_monitor_user_info_added = False
            old_userid = userid

        if which_file == merge_url_model_result_mapper.URL_MONITOR_USER_INFO:
            # �����ǰΪ����˻���check_result��Ϣ
            if url_monitor_user_info_added:
                # ��������ӹ� ������
                continue
            else:
                # �������ִ�� ��¼��userid�����ӹ�����˻���check_result��Ϣ
                url_monitor_user_info_added = True

        cur_product_set, user_model_evidence, model_result = convert_to_merge(which_file, json_str)
        product_set.update(cur_product_set)
        user_result.check_result += model_result
        if len(user_model_evidence) > 0:
            user_result.user_model_evidence = user_model_evidence

    if old_userid is not None:
        # ���Ӳ�Ʒ��
        user_result.info["product"] = "|".join(product_set)
        print json.dumps(user_result.merge_result())
