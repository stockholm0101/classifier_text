#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   zhukaiwen@baidu.com
#Date  :   19/05/09 20:12:56
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os
import json
import random

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object
import review_object.merge_object as merge_object
import conf

def convert_to_merge(which_file, json_str):
    """"""
    user_model_evidence = {}
    model_result = []
    if which_file == conf.MODEL_TYPE_AD:
        pass
    elif which_file in [conf.MODEL_TYPE_UNIT, conf.MODEL_TYPE_METEOR, conf.MODEL_TYPE_CLICK_AD, \
            conf.MODEL_TYPE_METEOR_AD, conf.MODEL_TYPE_URL, conf.MODEL_TYPE_FEED_IDEA_AD, \
            conf.MODEL_TYPE_FEED_IDEA_UNIT]:
        # unit��Դ�Ѿ�merge��user��
        merge_obj = merge_object.MergeObj()
        merge_obj.init_from_json(json_str)
        model_result = merge_obj.check_result
    elif which_file in [conf.MODEL_TYPE_USER, conf.MODEL_TYPE_CLICK_USER, conf.MODEL_TYPE_FEED_IDEA_USER, \
            conf.MODEL_TYPE_FEED_USER]:
        if which_file == conf.MODEL_TYPE_USER:
            review_user_obj = review_object.ReviewUserObj()
        elif which_file == conf.MODEL_TYPE_CLICK_USER:
            review_user_obj = review_object.ReviewClickUserObj()
        elif which_file == conf.MODEL_TYPE_FEED_USER:
            review_user_obj = review_object.ReviewFeedUserObj()
        elif which_file == conf.MODEL_TYPE_FEED_IDEA_USER:
            review_user_obj = review_object.ReviewFeedIdeaUserObj()
        review_user_obj.init_from_json(json_str)
        
        # ֤�ݲ���
        idea_num = len(review_user_obj.idea_list)
        word_num = len(review_user_obj.word_list)
        idea_url_num = len(review_user_obj.idea_url_list)
        user_model_evidence["idea"] = review_user_obj.idea_list
        user_model_evidence["word"] = review_user_obj.word_list
        user_model_evidence["url"] = review_user_obj.idea_url_list
        if idea_num > conf.USER_IDEA_EVIDENCE_NUM:
            user_model_evidence["idea"] = random.sample(review_user_obj.idea_list,
                    conf.USER_IDEA_EVIDENCE_NUM)
        if word_num > conf.USER_WORD_EVIDENCE_NUM:
            user_model_evidence["word"] = random.sample(review_user_obj.word_list,
                    conf.USER_WORD_EVIDENCE_NUM)
        if idea_url_num > conf.USER_IDEA_EVIDENCE_NUM:
            user_model_evidence["url"] = random.sample(review_user_obj.idea_url_list,
                    conf.USER_IDEA_EVIDENCE_NUM)

        # ģ�ͽ������
        for user_review_result in review_user_obj.check_result:
            # �ϲ����ģ�ͽ����ʽ, MergeObj.check_result�е�Ԫ��
            each_model_result = {}
            each_model_result["model_id"] = user_review_result["model_id"]
            each_model_result["model_name"] = user_review_result["model_name"]
            each_model_result["model_type"] = which_file

            model_check_result = review_object.CheckUserResultObj()
            model_check_result.init_from_dict(user_review_result["model_result"])

            model_merge_result = merge_object.MergeResultObj()
            model_merge_result.init(model_check_result.label, 
                    model_check_result.label_name, 
                    model_check_result.label_list, {})
            each_model_result["model_result"] = model_merge_result.convert_to_dict()
            model_result.append(each_model_result)
    elif which_file == conf.MODEL_TYPE_OTHER or which_file == conf.MODEL_TYPE_LP:
        review_risk_user = review_object.ReviewRiskUserObj()
        review_risk_user.init_from_json(json_str.strip())
        merge_result = review_risk_user.merge_result()
        model_result = [merge_result["result"]]

    return user_model_evidence, model_result

def add_user_product(products, which_file, model_result):
    """�˻���Ʒ��
    """
    def append_product(products, product):
        """����product
        """
        product_set = set(products.split("|")) - set([""])
        product_set |= set([product])
        return "|".join(list(product_set))

    if which_file in [conf.MODEL_TYPE_FEED_AD, conf.MODEL_TYPE_FEED_USER, \
            conf.MODEL_TYPE_FEED_IDEA_AD, conf.MODEL_TYPE_FEED_IDEA_UNIT, \
            conf.MODEL_TYPE_FEED_IDEA_USER]:
        products = append_product(products, "feed")
    elif which_file in [conf.MODEL_TYPE_LP]:
        product = model_result[0]["model_result"]["evidence"]["product"]
        products = append_product(products, product)
    else:
        products = append_product(products, "fc")

    return {"product": products}


if __name__ == "__main__":
    old_userid = ""
    user_result = merge_object.MergeObj()
    for eachline in sys.stdin:
        line = eachline.strip("\n").split("\t")
        userid = line[0]
        which_file = int(line[1])
        json_str = line[2]

        if old_userid != userid:
            if old_userid != "":
                print json.dumps(user_result.merge_result())
            user_result.init(userid)
        user_model_evidence, model_result = convert_to_merge(which_file, json_str)
        products = user_result.info["product"] if "product" in user_result.info else ""
        user_result.info = add_user_product(products, which_file, model_result)
        user_result.check_result += model_result
        if len(user_model_evidence) > 0:
            user_result.user_model_evidence = user_model_evidence

        old_userid = userid

    if old_userid != "":
        print json.dumps(user_result.merge_result())
