#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author: zhanghao55@baidu.com
Date  : 20/03/09 20:12:56
Desc  : feed����˽���ϲ�reducer
"""
import sys
import os
import json
import random

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object
import review_object.merge_object as merge_object
import conf

def convert_to_merge(which_file, json_str):
    """������תΪMergeObj��ʽ
    """
    user_model_evidence = {}
    model_result = []
    if which_file in [conf.MODEL_TYPE_FEED_AD, conf.MODEL_TYPE_FEED_IDEA_AD, \
            conf.MODEL_TYPE_FEED_IDEA_UNIT]:
        # feed���ϵĽ���Ѿۺϵ��˻�
        merge_obj = merge_object.MergeObj()
        merge_obj.init_from_json(json_str)
        model_result = merge_obj.check_result
    elif which_file in [conf.MODEL_TYPE_FEED_USER]:
        review_feed_user_obj = review_object.ReviewFeedUserObj()
        review_feed_user_obj.init_from_json(json_str)
        # ֤�ݲ���
        text_num = len(review_feed_user_obj.text_list)
        if text_num > conf.USER_IDEA_EVIDENCE_NUM:
            user_model_evidence["text"] = random.sample(review_feed_user_obj.text_list, 
                    conf.USER_IDEA_EVIDENCE_NUM)
        else:
            user_model_evidence["text"] = review_feed_user_obj.text_list
    elif which_file in [conf.MODEL_TYPE_FEED_IDEA_USER]:
        review_feed_user_obj = review_object.ReviewFeedIdeaUserObj()
        review_feed_user_obj.init_from_json(json_str)
        # ֤�ݲ���
        text_num = len(review_feed_user_obj.idea_list)
        if text_num > conf.USER_IDEA_EVIDENCE_NUM:
            user_model_evidence["text"] = random.sample(review_feed_user_obj.idea_list, 
                    conf.USER_IDEA_EVIDENCE_NUM)
        else:
            user_model_evidence["text"] = review_feed_user_obj.idea_list

        # ģ�ͽ������
        for user_review_result in review_feed_user_obj.check_result:
            # �ϲ����ģ�ͽ����ʽ, MergeObj.check_result�е�Ԫ��
            each_model_result = {}
            each_model_result["model_id"] = user_review_result["model_id"]
            each_model_result["model_name"] = user_review_result["model_name"]
            each_model_result["model_type"] = which_file

            model_check_result = review_object.CheckFeedResultObj()
            model_check_result.init_from_dict(user_review_result["model_result"])

            model_merge_result = merge_object.MergeResultObj()
            model_merge_result.init(model_check_result.label, 
                    model_check_result.label_name, 
                    model_check_result.label_list, {})
            each_model_result["model_result"] = model_merge_result.convert_to_dict()
            model_result.append(each_model_result)

    return user_model_evidence, model_result


if __name__ == "__main__":
    old_userid = None
    user_result = merge_object.MergeObj()
    for eachline in sys.stdin:
        line = eachline.strip("\n").split("\t")
        userid = line[0]
        which_file = int(line[1])
        json_str = line[2]

        if old_userid != userid:
            if old_userid is not None:
                print json.dumps(user_result.merge_result())
            user_result.init(userid)
            old_userid = userid
        user_model_evidence, model_result = convert_to_merge(which_file, json_str)
        # ���Ӳ�Ʒ����Ϣ
        products = user_result.info.get("product", "")
        product_set = set(products.split("|")) - set([""])
        product_set.add("feed")
        user_result.info = {"product": "|".join(product_set)}
        user_result.check_result += model_result
        if len(user_model_evidence) > 0:
            user_result.user_model_evidence = user_model_evidence

    if old_userid is not None:
        print json.dumps(user_result.merge_result())
