#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   19/06/26 16:17:05
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import json

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import common.sampler as sampler
import review_object.review_object as review_object
import review_object.merge_object as merge_object
import conf

class Merger(object):
    """merge label, ����ģ�͵Ľӿ�
    """
    def __init__(self, merge_type):
        """init
        """
        assert merge_type in set([conf.MODEL_TYPE_AD, conf.MODEL_TYPE_UNIT, conf.MODEL_TYPE_CLICK_AD, \
                conf.MODEL_TYPE_METEOR_AD, conf.MODEL_TYPE_URL, conf.MODEL_TYPE_FEED_AD, conf.MODEL_TYPE_URL_MONITOR, \
                conf.MODEL_TYPE_FEED_IDEA_AD, conf.MODEL_TYPE_FEED_IDEA_UNIT]), \
                "merge type wrong, expect \"0\"(MODEL_TYPE_AD) or \"1\"(MODEL_TYPE_UNIT) or " \
                "\"6\"(MODEL_TYPE_CLICK_AD) or \"9\"(MODEL_TYPE_METEOR_AD) or \"10\"(MODEL_TYPE_URL) " \
                "or \"11\"(MODEL_TYPE_FEED_AD) or \"13\"(MODEL_TYPE_URL_MONITOR) or \"17\"(MODEL_TYPE_FEED_IDEA_AD) " \
                "or \"15\"(MODEL_TYPE_FEED_IDEA_UNIT), get %d" % merge_type
        self._tar_model_type = merge_type
        # �õ�merge���
        self._get_merge_result = {
                conf.MODEL_TYPE_AD: self._ad_merge,
                conf.MODEL_TYPE_UNIT: self._unit_merge,
                conf.MODEL_TYPE_CLICK_AD: self._click_merge,
                conf.MODEL_TYPE_URL: self._url_merge,
                conf.MODEL_TYPE_METEOR_AD: self._meteor_merge,
                conf.MODEL_TYPE_FEED_AD: self._feed_merge,
                conf.MODEL_TYPE_FEED_IDEA_AD: self._feed_ad_merge,
                conf.MODEL_TYPE_FEED_IDEA_UNIT: self._feed_unit_merge,
                conf.MODEL_TYPE_URL_MONITOR: self._url_monitor_merge,
                }[merge_type]

    def init(self):
        """ �õ�ָ��type�µ�������Ҫmerge��ģ����Ϣ
        """
        # �ϲ��б� (ģ����Ϣ,ģ�ͺϲ�����,ģ�ͺϲ���Ϣ)
        self.model_merge_list = list()
        for model_merge in conf.models_merge:
            tar_model_id = model_merge["model_id"] 
            # ����û�ж�Ӧmodel��
            if tar_model_id not in conf.models:
                continue

            # �õ���Ӧ��model
            model = conf.models[tar_model_id]

            if not model["enable"] or not model_merge["enable"] or \
                    self._tar_model_type not in model_merge["merge_type"]:
                continue

            m_module = __import__(model_merge["module_name"], fromlist = ['default'])
            m_class = getattr(m_module, model_merge["class_name"])
            m_obj = m_class()
            self.model_merge_list.append((model, m_obj, model_merge))

    def merge(self, key, review_res_list):
        """�ϲ�review���
        """
        assert len(review_res_list) > 0, "review_res_list is empty" 
        return self._get_merge_result(key, review_res_list)

    def _feed_merge(self, key, feed_res_list):
        """feed����ά��Ԥ�����ϲ����û�ά��
        """
        merge_feed_obj = merge_object.MergeObj()
        merge_feed_obj.init(feed_res_list[0].userid)
        for model_conf_info, m_obj, _ in self.model_merge_list:
            model_id = model_conf_info["model_id"]
            user_result_by_model = m_obj.merge_method(model_id, feed_res_list)
            merge_feed_obj.add_result(model_conf_info, user_result_by_model, self._tar_model_type)
        return merge_feed_obj.merge_result()
    

    def _click_merge(self, key, click_res_list):
        """���ά��Ԥ�����ϲ����û�ά��
        """
        merge_click_obj = merge_object.MergeObj()
        merge_click_obj.init(click_res_list[0].userid)
        for model_conf_info, m_obj, _ in self.model_merge_list:
            model_id = model_conf_info["model_id"]
            user_result_by_model = m_obj.merge_method(model_id, click_res_list)
            merge_click_obj.add_result(model_conf_info, user_result_by_model, self._tar_model_type)
        return merge_click_obj.merge_result()

    def _meteor_merge(self, key, meteor_res_list):
        """��������ά��Ԥ�����ϲ����û�ά��
        """
        merge_meteor_obj = merge_object.MergeObj()
        merge_meteor_obj.init(meteor_res_list[0].userid)
        for model_conf_info, m_obj, _ in self.model_merge_list:
            model_id = model_conf_info["model_id"]
            user_result_by_model = m_obj.merge_method(model_id, meteor_res_list)
            merge_meteor_obj.add_result(model_conf_info, user_result_by_model, self._tar_model_type)
        return merge_meteor_obj.merge_result()

    def _unit_merge(self, key, user_result):
        """��Ԫά�ȵ�Ԥ�����ϲ����û�ά��
        """
        merge_unit_obj = merge_object.MergeObj()
        merge_unit_obj.init(user_result[0].userid)
        for model_conf_info, m_obj, _ in self.model_merge_list:
            model_id = model_conf_info["model_id"]
            user_result_by_model = m_obj.merge_method(model_id, user_result)
            merge_unit_obj.add_result(model_conf_info, user_result_by_model, self._tar_model_type)

        return merge_unit_obj.merge_result()
    
    def _feed_unit_merge(self, key, user_result):
        """feed��Ԫά�ȵ�Ԥ�����ϲ����û�ά��
        """
        merge_feed_unit_obj = merge_object.MergeObj()
        merge_feed_unit_obj.init(user_result[0].userid)
        for model_conf_info, m_obj, _ in self.model_merge_list:
            model_id = model_conf_info["model_id"]
            user_result_by_model = m_obj.merge_method(model_id, user_result)
            merge_feed_unit_obj.add_result(model_conf_info, user_result_by_model, self._tar_model_type)

        return merge_feed_unit_obj.merge_result()

    def _ad_merge(self, key, ad_res_list):
        """����ά�ȵ�Ԥ�����ϲ�Ϊ��Ԫά�ȵ�Ԥ����
        """
        merge_ad_obj = review_object.ReviewUnitObj()
        merge_ad_obj.data_type = conf.MODEL_TYPE_AD
        merge_ad_obj.userid = ad_res_list[0].userid
        merge_ad_obj.planid = ad_res_list[0].planid
        merge_ad_obj.unitid = ad_res_list[0].unitid

        idea_sampler = sampler.Sampler(3)
        word_sampler = sampler.Sampler(3)
        idea_url_sampler = sampler.Sampler(3)
        word_url_sampler = sampler.Sampler(3)
        for res in ad_res_list:
            if res.ad_type == conf.IDEA:
                idea_sampler.put(res.text)
                if res.url != "null":
                    idea_url_sampler.put(res.url)
            if res.ad_type == conf.WORD:
                word_sampler.put(res.text)
                if res.url != "null":
                    word_url_sampler.put(res.url)

        merge_ad_obj.idea_list = idea_sampler.get_sample_list()
        merge_ad_obj.word_list = word_sampler.get_sample_list()
        merge_ad_obj.idea_url_list = idea_url_sampler.get_sample_list()
        merge_ad_obj.word_url_list = word_url_sampler.get_sample_list()

        for model_conf_info, m_obj, _ in self.model_merge_list:
            model_id = model_conf_info["model_id"]
            # �Զ����merge_method���������ʽ
            # ����: review_object.ReviewAdObj
            # ���: review_object.CheckUnitResultObj
            ad_merge_by_model = m_obj.merge_method(model_id, ad_res_list)
            merge_ad_obj.add_result(model_conf_info, ad_merge_by_model)

        return merge_ad_obj.review_result()

    def _url_merge(self, key, url_res_list):
        """�˻�urlԤ�����ϲ�Ϊuserά��Ԥ����
        """
        merge_url_obj = merge_object.MergeObj()
        merge_url_obj.init(key)
        for model_conf_info, m_obj, _ in self.model_merge_list:
            model_id = model_conf_info["model_id"]
            user_result_by_model = m_obj.merge_method(model_id, url_res_list)
            merge_url_obj.add_result(model_conf_info, user_result_by_model, self._tar_model_type)
        return merge_url_obj.merge_result()

    def _url_monitor_merge(self, key, url_res_list):
        """url����˻�Ԥ�����ϲ�Ϊuserά��Ԥ����
        """
        merge_url_obj = merge_object.MergeObj()
        merge_url_obj.init(key)
        for model_conf_info, m_obj, _ in self.model_merge_list:
            model_id = model_conf_info["model_id"]
            user_result_by_model = m_obj.merge_method(model_id, url_res_list)
            merge_url_obj.add_result(model_conf_info, user_result_by_model, self._tar_model_type)
        return merge_url_obj.merge_result()
    
    def _feed_ad_merge(self, key, ad_res_list):
        """feed����ά�ȵ�Ԥ�����ϲ�Ϊ��Ԫά�ȵ�Ԥ����
        """
        merge_ad_obj = review_object.ReviewFeedUnitObj()
        merge_ad_obj.data_type = conf.MODEL_TYPE_FEED_IDEA_AD
        merge_ad_obj.userid = ad_res_list[0].userid
        merge_ad_obj.planid = ad_res_list[0].planid
        merge_ad_obj.unitid = ad_res_list[0].unitid

        idea_sampler = sampler.Sampler(3)
        idea_url_sampler = sampler.Sampler(3)
        word_url_sampler = sampler.Sampler(3)
        for res in ad_res_list:
            idea_sampler.put(res.text)
            if res.url != "null":
                idea_url_sampler.put(res.url)

        merge_ad_obj.idea_list = idea_sampler.get_sample_list()
        merge_ad_obj.idea_url_list = idea_url_sampler.get_sample_list()
        merge_ad_obj.word_list = []
        merge_ad_obj.word_url_list = [] 
        for model_conf_info, m_obj, _ in self.model_merge_list:
            model_id = model_conf_info["model_id"]
            # �Զ����merge_method���������ʽ
            # ����: review_object.ReviewAdObj
            # ���: review_object.CheckUnitResultObj
            ad_merge_by_model = m_obj.merge_method(model_id, ad_res_list)
            merge_ad_obj.add_result(model_conf_info, ad_merge_by_model)
        return merge_ad_obj.review_result()


def main():
    """�ϲ�����ά�Ȼ�Ԫά�ȵļ���� ��merge_type����
    """
    merge_type = int(sys.argv[1])
    m = Merger(merge_type)
    m.init()
    previous_key = None
    review_res_list_sampler = sampler.Sampler(conf.USER_UNIT_SAMPLE_NUM)
    get_r_obj = {
            conf.MODEL_TYPE_AD: review_object.ReviewAdObj,
            conf.MODEL_TYPE_UNIT: review_object.ReviewUnitObj,
            conf.MODEL_TYPE_CLICK_AD: review_object.ReviewClickAdObj,
            conf.MODEL_TYPE_URL: review_object.ReviewUrlObj,
            conf.MODEL_TYPE_METEOR_AD: review_object.ReviewMeteorAdObj,
            conf.MODEL_TYPE_FEED_AD: review_object.ReviewFeedAdObj,
            conf.MODEL_TYPE_FEED_IDEA_AD: review_object.ReviewFeedIdeaAdObj,
            conf.MODEL_TYPE_FEED_IDEA_UNIT: review_object.ReviewFeedUnitObj,
            conf.MODEL_TYPE_URL_MONITOR: review_object.ReviewURLMonitorObj
            }[merge_type]
    for line in sys.stdin:
        parts = line.strip("\n").split("\t")
        cur_key = parts[0]
        json_str = parts[1]
        r_obj = get_r_obj()
        
        try:
           r_obj.init_from_json(json_str)
        except Exception as e:
            raise ValueError("%s\nerror line:%s" % (str(e), line))

        if previous_key != cur_key:
            if previous_key is not None:
                review_res_list = review_res_list_sampler.get_sample_list()
                merge_result = m.merge(previous_key, review_res_list)
                print json.dumps(merge_result)
            review_res_list_sampler.clear()
            previous_key = cur_key
        review_res_list_sampler.put(r_obj)
    if previous_key is not None:
        review_res_list = review_res_list_sampler.get_sample_list()
        merge_result = m.merge(previous_key, review_res_list)
        print json.dumps(merge_result)


if __name__ == "__main__":
    main()
