#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/05/14 17:30:23
Desc  :   
"""
import sys
import os
import json

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object
import review_object.merge_object as merge_object
import conf


# ��Ҫ��conf�е��������͵�ȡֵ����ͬ ��������
URL_MONITOR_USER_INFO = -1


if __name__ == "__main__":
    # latest_crawled_url�ļ���useridֻ����һ��
    latest_crawled_userid_set = set()

    for line in sys.stdin:
        line = line.strip()
        try:
            file_name = os.environ["mapreduce_map_input_file"] if "mapreduce_map_input_file" in \
                    os.environ else os.environ["map_input_file"]
            which_file = None
            if "-merge-url-monitor" in file_name:
                which_file = conf.MODEL_TYPE_URL_MONITOR
            elif "-merge-url-continuous-monitor" in file_name:
                which_file = conf.MODEL_TYPE_URL_CONTINUOUS_MONITOR
            elif "latest_crawled_url" in file_name:
                which_file = URL_MONITOR_USER_INFO
        except:
            which_file = int(sys.argv[1])

        userid = None
        if which_file == conf.MODEL_TYPE_URL_MONITOR:
            url_monitor_merge_obj = merge_object.MergeObj()
            url_monitor_merge_obj.init_from_json(line)
            userid = url_monitor_merge_obj.userid
        elif which_file == URL_MONITOR_USER_INFO:
            url_with_info = json.loads(line)
            cur_userid = url_with_info["userid"]
            if cur_userid not in latest_crawled_userid_set:
                userid = cur_userid
                latest_crawled_userid_set.add(cur_userid)

        if userid is not None:
            print "\t".join([userid, str(which_file), line])
