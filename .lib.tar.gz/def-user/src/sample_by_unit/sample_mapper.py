#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   19/07/05 16:28:19
Desc  :   ��Ԥ���������ϰ�unit����
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os

def main(user_set, data_type, ignore=False):
    """�����Ѵ������Ĵ������� ����keyֵΪunit������
    """
    for line in sys.stdin:
        parts = line.strip("\n").split("\t")
        if len(parts) != 8:
            continue
        userid = parts[0]
        if ignore == False and userid not in user_set:
            continue
        planid = parts[1]
        unitid = parts[2]
        text = parts[5]
        text_seg = parts[6]
        url = parts[7]
        # ���unitid, data_type, userid, planid, text, text_seg, url
        print("\t".join([unitid, data_type, userid, planid, text, text_seg, url]))


if __name__ == "__main__":
    ignore = False
    try:
        file_name = os.environ["mapreduce_map_input_file"] if "mapreduce_map_input_file" in \
                os.environ else os.environ["map_input_file"]
        data_type = "idea" if "idea-processed" in file_name else "word"
    except:
        # localִ���޸Ĵ˴�
        data_type = sys.argv[1]
        ignore = True
    user_set = set()
    user_info_file = "data/user_info.txt"
    with open(user_info_file, "r") as f:
        for eachline in f:
            line = eachline.strip("\n").split("\t")
            userid = line[0]
            user_set.add(userid)
    main(user_set, data_type, ignore)
