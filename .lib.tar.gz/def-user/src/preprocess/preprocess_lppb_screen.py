#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/12/13 11:30:01
Desc  :   LP PB ����
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os
import json
import random

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
sys.path.append("%s/../protobuf" % _cur_dir)
sys.path.append("%s/../proto" % _cur_dir)

import ad_review_service_pb2
import general_ad_field_pb2
import ad_review_util_pb2
import lp_job_pb2 as lpjob
import lp_feature_pb2 as lpfeature
import re
import conf

# mapper
def mapper(key, value):
    """mapper
    """
    pb = lpjob.LpJob()
    pb.ParseFromString(value)
    for task in pb.tasks:
        session_id = task.session_id
        url = task.url
        if  task.HasField("crawl_info") and task.crawl_info.crawl_type == 33:
            userid_0 = str(task.request_info.userid)
            userid_1 = str(task.additional_info.userid)
            userid = userid_0 if userid_0 != "" and userid_0 != "0" else userid_1

            audit_result = "none"
            if task.HasField('audit_info') and task.audit_info.HasField('feature'):
                model_id = task.audit_info.feature.type
                label_id = task.audit_info.feature.result
                audit_result = str(model_id) + " : " + str(label_id)

            crawl_type = str(task.crawl_info.crawl_type)      #1001|1002���·�����ץȡ
            crawl_result = str(task.crawl_info.crawl_result)  #0:success 1:failed 2:Unknow
            out = [userid, url, audit_result, crawl_type, crawl_result]
            emit(session_id, '\t'.join(out))

# reducer
def reducer(key, values):
    """reducer
    """
    for value in values:
        emit(key, value)

if __name__ == "__main__":
    pass
