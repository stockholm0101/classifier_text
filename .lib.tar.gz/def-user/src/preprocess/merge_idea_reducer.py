#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   18/02/06 16:44:59
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")

if __name__ == "__main__":
    ideadesc = ""
    ideaid = ""
    for eachline in sys.stdin:
        try:
            line = eachline.strip("\n").split("\t")
            which_file = line[1]
            if which_file == "1":
                ideaid = line[0]
                ideadesc = line[2:]
            elif which_file == "2":
                if line[0] != ideaid:
                    continue
                version = line[13]
                idea_tag = line[14]
                unitid = line[4]
                planid = line[3]
                userid = line[2]
                isdel = line[11]
                rsnid = ""
                reason = ""
                stat = ""
                pair_stat = ""
                ideastat1 = line[5]
                ideastat2 = line[6]
                ideastat3 = line[7]
                ideastat4 = line[8]
                ideastat5 = line[9]
                ideastat6 = line[10]
                modtime = line[15]
                title = ideadesc[0]
                desc1 = ideadesc[1]
                desc2 = ideadesc[2]
                url = ideadesc[3]
                show_url = ideadesc[4]
                mversion = ""
                misdel = ""
                mrsnid = ""
                mreason = ""
                mstat = ""
                mistat3 = ""
                mistat4 = ""
                mishowurl = ""
                miurl = ""
                maddtime = ""
                mmodtime = ""
                mdeltime = ""
                ad_type = line[12]

                res_str = [ideaid, version, unitid, planid, userid, isdel, rsnid, reason, stat, \
                        pair_stat, ideastat1, ideastat2, ideastat3, ideastat4, ideastat5, ideastat6, \
                        modtime, title, desc1, desc2, url, show_url, mversion, misdel, mrsnid, \
                        mreason, mstat, mistat3, mistat4, mishowurl, miurl, maddtime, mmodtime, \
                        mdeltime, ad_type, idea_tag]
                print "\t".join(res_str)
        except Exception as e:
            sys.stderr.write("%s\n" % eachline.strip("\n"))
