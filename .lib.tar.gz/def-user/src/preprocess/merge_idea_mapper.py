#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   18/02/06 15:39:50
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os

if __name__ == "__main__":
    for eachline in sys.stdin:
        line = eachline.strip("\n").decode("utf-8", "ignore").encode("gbk", "ignore").split("\t")
        file_name = os.environ["mapreduce_map_input_file"] if "mapreduce_map_input_file" in \
                os.environ else os.environ["map_input_file"]
        # 1. ideadesc 2. ideainfo
        which_file = "1"
        if "ideainfo/" in file_name:
            which_file = "2"

        if which_file == "1":
            ideaid = line[0]
            title = line[1]
            desc1 = line[2]
            desc2 = line[3]
            target_url = line[4]
            show_url = line[5]
            res_str = [ideaid, which_file, title, desc1, desc2, target_url, show_url]
            print "\t".join(res_str)
        elif which_file == "2":
            ideaid = line[0]
            unitid = line[1]
            planid = line[2]
            userid = line[3]
            ideastat1 = line[6]
            ideastat2 = line[7]
            ideastat3 = line[8]
            ideastat4 = line[9]
            ideastat5 = line[10]
            ideastat6 = line[11]
            isdel = line[15]
            ad_type = line[22]
            version = line[24]
            idea_tag = line[26]
            modtime = line[14].split(".")[0]
            if ideastat1 != "0" or ideastat2 != "0" or ideastat3 != "0" or ideastat4 != "0" or \
                    ideastat5 not in ("0", "2") or ideastat6 not in ("0", "2"):
                    #isdel not in ("0", "NULL"):
                continue
            res_str = [ideaid, which_file, userid, planid, unitid, ideastat1, ideastat2, \
                    ideastat3, ideastat4, ideastat5, ideastat6, isdel, ad_type, version, idea_tag, modtime]
            print "\t".join(res_str)
