#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/11/08 11:30:01
Desc  :   LP PB ����
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os
import json
import random

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
sys.path.append("%s/../protobuf" % _cur_dir)
sys.path.append("%s/../proto" % _cur_dir)
import review_object.review_object as review_object
from common.get_domain import GetDomain

import ad_review_service_pb2
import general_ad_field_pb2
import ad_review_util_pb2
import lp_job_pb2 as lpjob
import lp_feature_pb2 as lpfeature
import re
import conf

#url�ı���������
FILTER_REGEX = "1"
FILTER_DOMAIN = "2"
FILTER_SITE = "3"

class PbInitLoad(object):
    """pb��ʼ�����������������
    """
    def __init__(self, eff_user_path='data/effuser.txt', \
                       model_id_map_path='model/model_lp/model_id_map.txt', \
                       label_id_map_path='model/model_lp/label_id_map.txt', \
                       filter_url_map_path='model/model_lp/filter_url_map.txt',\
                       cross_model_conf_path='model/model_lp/cross_model_conf.txt'):
        """[in]  eff_user_path    : str, ��Ч�˻���·��
                 model_id_map_path: str, ģ��idӳ��·��
                 label_id_map_path: str, ��ǩidӳ��·��
                 filter_url_map_path: str, ���˵�urlӳ��·��
                 cross_model_conf_path: str, ģ�ͽ������ñ�
           [out] None
        """
        self.effuser = self.load_eff_user(eff_user_path)
        self.model_id_map = self.load_model_id_map(model_id_map_path)
        self.label_id_map = self.load_label_id_map(label_id_map_path)
        self.filter_url_map, self.filter_domain_map, self.filter_site_map, self.follow_model_id_map = \
                self.load_filter_url_map(filter_url_map_path)
        self.cross_model_conf = self.load_cross_model_conf(cross_model_conf_path)

    def __str__(self):
        """�ع�__str__
        """
        model_desc = ""
        for key, value in sorted(self.model_id_map.items(), key=lambda x:x[1]):
            model_desc += "\t%s\n" % ("\t".join(value))
        return 'lp model desc: \n%s' % model_desc

    def load_eff_user(self, eff_user_path):
        """��Ч�˻�
        """
        eff_user = set()
        with open(eff_user_path, "r") as f:
            for line in f:
                eff_user.add(line.strip().split("\t")[0])
        return eff_user

    def load_model_id_map(self, model_id_map_path):
        """feature type��model id��ӳ��
        """
        model_id_map = dict()
        with open(model_id_map_path, "r") as f:
            for line in f:
                if line.startswith("#"):
                    continue
                parts = line.strip().decode("gbk", "ignore").split("\t")
                model_id_map[parts[0]] = [parts[1], parts[2]]
        return model_id_map

    def load_label_id_map(self, label_id_map_path):
        """feature type��label id��ӳ��
        """
        label_id_map = dict()
        with open(label_id_map_path, "r") as f:
            for line in f:
                if line.startswith("#"):
                    continue
                parts = line.strip().decode("gbk", "ignore").split("\t")
                model_id = parts[0]
                label_id = parts[1]
                label_name = parts[2]
                if model_id not in label_id_map:
                    label_id_map[model_id] = dict()
                label_id_map[model_id][label_id] = label_name
        return label_id_map

    def load_filter_url_map(self, filter_url_map_path):
        """ģ��id�� url�����ı���ӳ��
        """
        filter_url_map = dict()
        filter_domain_map = dict()
        filter_site_map = dict()
        follow_model_id_map = dict()
        with open(filter_url_map_path, "r") as f:
            for line in f:
                if line.startswith("#"):
                    continue
                parts = line.strip('\n').decode('gbk', 'ignore').split("\t")
                if len(parts) < 5:
                    continue
                model_id = parts[0]
                filter_type = parts[1]
                text = parts[2]
                follow_model_id = parts[3]
                is_used = int(parts[4])
                if not is_used:
                    continue
                follow_model_ids = follow_model_id.split("|")
                for follow_model_idx in follow_model_ids:
                    if follow_model_idx not in follow_model_id_map:
                        follow_model_id_map[follow_model_idx] = set()
                    follow_model_id_map[follow_model_idx].add(model_id)
            
                if filter_type == FILTER_DOMAIN:
                    if model_id not in filter_domain_map:
                        filter_domain_map[model_id] = set()
                    filter_domain_map[model_id].add(text)
                elif filter_type == FILTER_SITE:
                    if model_id not in filter_site_map:
                        filter_site_map[model_id] = set()
                    filter_site_map[model_id].add(text)
                else:
                    if model_id not in filter_url_map:
                        filter_url_map[model_id] = set()
                    filter_url_map[model_id].add(text)

        for item in filter_url_map.items():
            model_id = item[0]
            texts = item[1]
            text_regex = '|'.join(texts)
            filter_url_map[model_id] = text_regex
        
        output = [filter_url_map, filter_domain_map, filter_site_map, follow_model_id_map]
        return output

    def load_cross_model_conf(self, cross_model_conf_path):
        """����ģ�ͽ������ñ�
        """
        cross_model = []
        with open(cross_model_conf_path, "r") as f:
            f.readline()
            for line in f:
                if line.startswith("#"):
                    continue
                parts = line.strip("\n").split("\t")
                if len(parts) != 4:
                    continue
                cross_set = set()
                cross_set.add(parts[0] + ":" + parts[1])
                cross_set.add(parts[2] + ":" + parts[3])
                cross_model.append(cross_set)
        return cross_model

# ===========lppb mapred================
# ��ʼ��pb������
pbinit = PbInitLoad()
FILTER_MODEL_LABEL = '1'
domain_m = GetDomain('./model/model_lp/effective_tld_names.dat')


def text_has_escape_string(text):
    """�ж��ַ������Ƿ���ת���ַ�
    """
    escape_list = ["\\", "\'", "\"", "\a", "\b", "\e", \
                   "\n", "\v", "\t", "\r", "\f"]
    for escape in escape_list:
        if escape in text:
            return True
    return False

# mapper
def mapper(key, value):
    """mapper
    """
    pb = lpjob.LpJob()
    pb.ParseFromString(value)
    for task in pb.tasks:
        session_id = task.session_id
        feature_array = task.audit_info.feature_array
        for feature in feature_array:
            result = feature.result
            feature_type = feature.type
            if str(feature_type) in pbinit.model_id_map and result != 0:
                if task.HasField('additional_info'):
                    if task.additional_info.HasField('userid'):
                        if task.request_info.type in [0, 1, 3, 8, 9, 12, 18, 23, 33, 34, 35, 36, 38]:
                            try:
                                userid       = str(task.additional_info.userid)
                                session_id   = str(session_id)
                                feature_type = str(feature_type)
                                model_id     = pbinit.model_id_map[feature_type][0]
                                model_name   = pbinit.model_id_map[feature_type][1]
                                label_id     = str(result)
                                label_name   = pbinit.label_id_map[feature_type][label_id]
                                url          = str(task.url)
                                ua           = str(task.ua_type)
                                model_type   = str(conf.MODEL_TYPE_LP)
                                product      = "feed" if task.request_info.type in [8, 9, 12, 23] else "fc"
                                # ���url����ת���ַ�������
                                if text_has_escape_string(url):
                                    continue
                                # �����ٳ����������Ͳ�ͬ
                                if str(feature_type) == "2":
                                    if feature.HasField('additional_infos'):
                                        add_info = feature.additional_infos
                                        if json.loads(add_info).get('alias', '') == 'hijacking':
                                            emit(userid, "\t".join([session_id, url, ua, feature_type, model_id, \
                                                model_name, label_id, 'hijacking', model_type, product]))
                                else:
                                    emit(userid, "\t".join([session_id, url, ua, feature_type, model_id, \
                                        model_name, label_id, label_name, model_type, product]))
                            except:
                                sys.stderr.write("feature_type: %s, label_id: %s" % (feature_type, label_id))

def filter_url(key, session_id, url, model_type, model_id, product):
    """��������ģ��
    [in] key: userid 
         session_id: session_id
         url:url
         model_type: conf.MODEL_TYPE_LP
         model_id: ��ǰ���ı�����Ӧ��ģ��id
         product: ��ǰsession_id�Ĳ�Ʒ��
    """
    domain = domain_m.get_domain2(url)
    site = domain_m.get_site(url)
    if model_id in pbinit.follow_model_id_map:
        for this_model_id in pbinit.follow_model_id_map[model_id]:
            if ((this_model_id in pbinit.filter_url_map) and \
                    len(re.findall(pbinit.filter_url_map[this_model_id], url)) > 0) \
                    or ((this_model_id in pbinit.filter_domain_map) \
                    and (domain in pbinit.filter_domain_map[this_model_id])) \
                    or ((this_model_id in pbinit.filter_site_map) \
                    and (site in pbinit.filter_site_map[this_model_id])):
                this_label_id = FILTER_MODEL_LABEL
                risk_info = [key, model_type, pbinit.model_id_map[this_model_id][0], \
                    pbinit.model_id_map[this_model_id][1], str(this_label_id), \
                    pbinit.label_id_map[this_model_id][this_label_id], url, session_id, product]
                rru_obj = review_object.ReviewRiskUserObj()
                rru_obj.init(risk_info)
                result = rru_obj.merge_result()
                emit("", json.dumps(result))

# reducer
def reducer(key, values):
    """reducer
    """
    # url����
    values_info = []
    session_label = dict()
    for value in values:
        values_info.append(value)
        [session_id, url, ua, feature_type, model_id, model_name, label_id, label_name, model_type, product] = \
                value.strip("\n").decode('gbk', 'ignore').split("\t")
        if session_id not in session_label:
            session_label[session_id] = set()
        session_label[session_id].add(model_id + ":" + label_id)

    session_id_cross_model = dict()
    lp_audit_info = set()
    flag = False
    for session_id in session_label:
        for cross_model in pbinit.cross_model_conf:
            if cross_model.issubset(session_label[session_id]):
                session_id_cross_model[session_id] = [x.split(":")[0] for x in session_label[session_id]]
                lp_audit_info |= set(session_id_cross_model[session_id])
                flag = True
                break
        if flag:
            break

    for value in values_info:
        [session_id, url, ua, feature_type, model_id, model_name, label_id, label_name, model_type, product] = \
                value.strip("\n").decode('gbk', 'ignore').split("\t")

        if (session_id in session_id_cross_model and model_id in session_id_cross_model[session_id]) \
                or model_id not in lp_audit_info:
            filter_url(key, session_id, url, model_type, model_id, product)

            risk_user_info = [key, model_type, model_id, model_name, \
                    label_id, label_name, url, session_id, product]

            rru_obj = review_object.ReviewRiskUserObj()
            rru_obj.init(risk_user_info)
            result = rru_obj.merge_result()
            emit("", json.dumps(result))

            if model_id not in lp_audit_info:
                lp_audit_info.add(model_id)


if __name__ == "__main__":
    pbint = PbInitLoad()
    print pbint
    
    #domain_m = GetDomain("./model/model_lp/effective_tld_names.dat")
    #url = "http://bd.xinghuacun-fenjiu.cn/fqgh5/fenj-m/"
    #domain = domain_m.get_domain2(url.strip())
    #site = domain_m.get_site(url.strip())
    #print url, "\tdomain=", domain
    #print url, "\tsite=", site

    #key = "2558564"
    #session_id = "83d67d72-7cc7-4b1e-9b23-8d7a9e4b32fd"
    #url = "http://sxlp.dtjtkjd.cn/m?sdclkid=ALfN15-l152sbJD6A5g"
    #model_type = "8"
    #model_id = "110201105601"
    #product = "12"
    #filter_url(key, session_id, url, model_type, model_id, product)
