#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao@baidu.com
Date  :   18/06/19 16:14:06
Desc  :   ɸѡ��Ч�Ĵ���(�ؼ���)��ȥ��ͨ��������Ӵ���(�ؼ���)���дʽ��
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import re
import os
import random
import json

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import common.word_segger as word_segger
import common.common as common
import review_object.review_object as review_object

rex = u"{�ؼ���}|{Ͷ�ŵ���}|{����}|{|}"

def idea_process(line, user_set, ignore=False):
    """��������
    """
    ret = None
    while True:
        parts = line.strip("\n").decode("gb18030", "ignore").lower().split("\t")

        userid = parts[4]
        if (ignore == False) and (userid not in user_set):
            break

        isdel = parts[5]
        ideastat1 = parts[10]
        ideastat2 = parts[11]
        ideastat3 = parts[12]
        ideastat4 = parts[13]
        ideastat5 = parts[14]
        ideastat6 = parts[15]
        modtime = parts[16]
        timedelta = common.Common.cal_timedelta(modtime)
        if (ignore == False) and ((isdel != "0" and isdel not in set(["NULL", "null"]) and \
                (timedelta is None or timedelta > 3)) \
                or ideastat1 != "0" or ideastat2 != "0" or ideastat3 != "0" or ideastat4 != "0" or \
                ideastat5 not in set(["0", "2"]) or ideastat6 not in set(["0", "2"])):
            break

        ideaid = parts[0]
        unitid = parts[2]
        version = parts[1]
        planid = parts[3]
        title = parts[17]
        desc1 = parts[18]
        desc2 = parts[19]
        url = parts[20]
        idea = "%s %s %s" % (title, desc1, desc2)
        idea = idea.replace("\t", " ").replace("\x01", " ").replace("\x02", " ").replace("\n", " ")
        idea = re.sub(rex, "", idea).strip()
        ret = {
                "userid": userid,
                "planid": planid,
                "unitid": unitid,
                "id": ideaid,
                "version": version,
                "text": idea, 
                "url": url}

        if True:
            break
    return ret


def word_process(line, user_set, ignore=False):
    """�����ؼ���
    """
    ret = None
    while True:
        parts = line.strip("\n").decode("utf-8", "ignore").lower().split("\t")
        if ignore:
            parts = line.strip("\n").decode("gb18030", "ignore").lower().split("\t")

        userid = parts[3]
        if (ignore == False) and (userid not in user_set):
            break

        wstat1 = parts[11]
        wstat2 = parts[12]
        wstat3 = parts[13]
        wstat4 = parts[14]
        isdel = parts[20]
        modtime = parts[19].split(".")[0]
        timedelta = common.Common.cal_timedelta(modtime)
        if (ignore == False) and ((isdel != "0" and isdel not in set(["NULL", "null"]) and \
                (timedelta is None or timedelta > 3)) \
                or wstat1 != "0" or wstat2 != "0" or wstat3 != "0" or wstat4 != "0"):
            break

        winfoid = parts[0]
        unitid = parts[1]
        planid = parts[2]
        assert "\t" not in parts[5]
        showword = parts[5].replace("\x01", " ").replace("\n", " ")
        version = parts[29]
        url = "NULL"  # �ؼ��ʲ㼶��û�йؼ���url��Ϣ
        ret = {
                "userid": userid,
                "planid": planid,
                "unitid": unitid,
                "id": winfoid,
                "version": version,
                "text": showword, 
                "url": url}

        if True:
            break
    return ret

def click_process(line, user_set, ignore=False):
    """�����������
    """
    ret = None
    while True:
        parts = line.strip("\n").decode("gb18030", "ignore").lower().split("\t")
        if len(parts) < 26:
            break

        userid = parts[0]
        unitid      = parts[1]
        winfoid     = parts[2]
        ideaid      = parts[3]
        price       = parts[6]
        query       = common.Common.text_normalize(parts[10])
        planid      = parts[11]
        title       = common.Common.text_normalize(parts[13])
        desc1       = common.Common.text_normalize(parts[14])
        desc2       = common.Common.text_normalize(parts[15])
        word        = common.Common.text_normalize(parts[16])
        showurl     = common.Common.text_normalize(parts[23])
        targeturl   = common.Common.text_normalize(parts[24])
        text        = ",".join([word, title, desc1, desc2])
        ret = {
                "userid": userid,
                "planid": planid,
                "unitid": unitid,
                "id": winfoid,
                "version": ideaid,
                "text": text, 
                "url": targeturl
                }

        if True:
            break
    return ret

def meteor_process(line, user_set, ignore=False):
    """����meteor����
    """
    ret = None
    while True:
        parts = line.strip("\n").decode("gbk", "ignore").lower().split("\t")
        if len(parts) < 80:
            break

        userid = parts[3]
        unitid = parts[4]
        winfoid = parts[5]
        ideaid = parts[7]
        wordtext = parts[16]
        wurl = parts[17]
        mwurl = parts[18]
        title = parts[19]
        desc1 = parts[20]
        desc2 = parts[21]
        targeturl = parts[22]
        showurl = parts[23]
        mtargeturl = parts[24]

        pipe_type = parts[1]      # output-trad-fc
        audit_type = parts[2]     # word, idea
        productid = parts[41]     # 0.fc
        audit_channel_type = parts[74] # 1. ���� 3. һ��
        review_result = parts[45] # APPROVED, DISAPPROVED
        is_need_audit = parts[75]

        # ���˻�����ͨ���ķﳲ����
        # 1. �ؼ��ʻ���
        if audit_type != "word" and audit_type != "idea":
            break
        # 2. �ﳲ���������˹�һ��fcд��ҵ�񷽵�pipe
        if productid != "0" or audit_channel_type not in set(["1", "3"]) or pipe_type != "output-trad-fc":
            break
        # 3. ���ͨ������
        if review_result == "DISAPPROVED":
            break

        rex = u"{�ؼ���}|{Ͷ�ŵ���}|{����}|{|}"
        if audit_type == "word":
            assert "\t" not in wordtext
            text = wordtext.replace("\x01", " ").replace("\n", " ")
            text = re.sub(rex, "", text).strip()
            idea_or_word_id = winfoid
            url = wurl.strip() if mwurl.strip() == "" else mwurl.strip()
        else:
            text = "%s %s %s" % (title, desc1, desc2)
            assert "\t" not in text
            text = text.replace("\x01", " ").replace("\n", " ")
            text = re.sub(rex, "", text).strip()
            idea_or_word_id = ideaid
            url = targeturl.strip() if mtargeturl.strip() == "" else mtargeturl.strip()

        ret = {
                "userid": userid,
                "planid": audit_type,
                "unitid": unitid,
                "id": idea_or_word_id,
                "version": is_need_audit,
                "text": text, 
                "url": url
                }

        if True:
            break
    return ret


def url_process(line, user_set, ignore=False):
    """url src feature�д�
    """
    ret = None
    while True:
        parts = line.strip("\n").decode("gbk", "ignore").lower().split("\t")
        if len(parts) != 4:
            break

        url = parts[0]
        userids = parts[1]
        src = parts[2]
        feature = parts[3]

        try:
            feature_dict = json.loads(feature)
        except Exception as e:
            break

        ret = {
                "url": url,
                "userids": userids,
                "src": src,
                "feature": feature_dict
                }

        if True:
            break
    return ret


def format_str(string):
    """url text format
    """
    string = string.replace("\n", " ").replace("\t", " ")
    while "  " in string:
        string = string.replace("  ", " ")
    string = string.strip()
    if len(string) == 0:
        return None
    return string


def print_url_line(segger, res):
    """url info
    """
    feature_dict = {}
    # �м�洢text
    feature_text = {
            "title": [],
            "navigation": [],
            "sem_central_content": [],
            "keywords": [],
            "abstract": [],
            "inner_links": [],
            "links": []
            }
    feature_seg_dict = {
            "title": [],
            "navigation": [],
            "sem_central_content": [],
            "keywords": [],
            "abstract": [],
            "inner_links": [],
            "links": []
            }

    key_to_lpfeature_key = {
            "title": ["title"],
            "navigation": ["navigation"],
            "sem_central_content": ["sem_central_content"],
            "keywords": ["reserved1"],
            "abstract": ["abstract_s"],
            "inner_links": ["reserved3"],
            "links": ["links"]
            }

    link_key = set(["reserved3", "links"])

    for key in key_to_lpfeature_key:
        for lp_key in key_to_lpfeature_key[key]:
            if lp_key in link_key:
                try:
                    value = json.loads(res["feature"][lp_key])
                except Exception as e:
                    value = {}
                value_list = value.get("links", [])
                for item in value_list:
                    string = format_str(item.get("text", ""))
                    if string is not None:
                        feature_text[key].append(string)
            else:
                string = format_str(res["feature"][lp_key])
                if string is not None:
                    feature_text[key].append(string)

    for k in feature_text:
        feature_dict[k] = " ".join(feature_text[k])
        if len(feature_dict[k]) > 1024000:
            feature_seg_dict[k] = segger.seg_words(feature_dict[k][0:1024000])
        else:
            feature_seg_dict[k] = segger.seg_words(feature_dict[k])

    print "\t".join([str(random.randint(0, 30000)), 
                     res["url"], 
                     res["userids"], 
                     res["src"], 
                     json.dumps(feature_dict), 
                     json.dumps(feature_seg_dict)]).encode("gb18030", "ignore")

def feed_process(line, user_set, ignore=False):
    """�����������
    """
    ret = None
    while True:
        parts = line.strip("\n").decode("gb18030", "ignore").lower().split("\t")
        if len(parts) < 35:
            break

        cmatch = parts[8]
        # cmatch_shoubai, cmatch_page
        if cmatch not in set(["545", "546", \
                #"604", "640", "620", "534", "585", "588", "596", "605", "641", "642", \
                #"691", "609", "703", "704", "610", "676", "720", "706", "774", "775", \
                #"781", "753", "755", "656", "657", "772", "863", "715", "873", "841", \
                #"842", "872", "868", "866", "896", "844", "890", "947", "970", "971", \
                #"972", "1013", "1009", "1010", "1011", "1012", "980", "981", "982", \
                #"983", "1052", "996", "1090", "1091", "1083", "1085", "1108", "1109", \
                #"1086", "1151", "1158", "1074", "1080", "1081", "913", "1016", "1084", \
                #"1127", "1128", "1129", "1181", "1173", "1074", "1075", "1068", "1214", \
                #"1220", "1227", "1257", "1258", "1230", "1178", "1283", "1313", "1137", \
                #"1361", "1349", "1369", "1370", "1078", "1079", "1178", "1179", "910", \
                #"1344", "1343"
                ]):
            break
        userid = parts[14]
        unitid    = parts[12]
        winfoid   = parts[10]
        ideaid    = parts[11]
        #price     = parts[2]
        #query     = common.Common.text_normalize(parts[3])
        planid    = parts[13]
        title     = common.Common.text_normalize(parts[16])
        desc1     = common.Common.text_normalize(parts[17])
        desc2     = common.Common.text_normalize(parts[18])
        #showurl   = common.Common.text_normalize(parts[24])
        targeturl = common.Common.text_normalize(parts[26])
        #text      = ",".join([title, desc1, desc2])
        text      = title
        ret = {
                "userid": userid,
                "planid": planid,
                "unitid": unitid,
                "id": winfoid,
                "version": ideaid,
                "text": text, 
                "url": targeturl
                }

        if True:
            break
    return ret


def feed_idea_process(line, user_set, ignore=False):
    """����feed��������
    """
    ret = None
    while True:
        try:
            line = line.strip("\n").decode("utf8", "ignore")
            conts = json.loads(line)
            userid = str(conts["userid"])
            unitid = str(conts["unitid"])
            planid = str(conts["planid"])
            ideaid = str(conts["ideaid"])
            kExtendText_list = conts["text"]["kExtendText"]
            kBrandWord_list = conts["text"]["kBrandWord"]
            kMTargtUrl_list = conts["url"]["kMTargetUrl"]
            ideas = " ".join(kExtendText_list).lower().strip() 
            brands = " ".join(kBrandWord_list).lower().strip()
            urls = "\x01".join(kMTargtUrl_list).strip()
            #text = ",".join((brands, ideas))
            text = ideas
            
            ret = {
                    "userid": userid,
                    "planid": planid,
                    "unitid": unitid,
                    "id": "",
                    "version": ideaid,
                    "text": text,
                    "url": urls
                    }
        except:
            break

        if True:
            break
    return ret


def get_users(user_info_file):
    """get users from file
    """
    user_set = set()
    with open(user_info_file, "r") as f:
        for eachline in f:
            line = eachline.strip("\n").split("\t")
            userid = line[0]
            user_set.add(userid)
    return user_set

def main(in_type):
    """����Ԥ����������
    """
    process_dict = {
            "idea": idea_process,
            "word": word_process,
            "click": click_process,
            "meteor": meteor_process,
            "url": url_process,
            "feed": feed_process,
            "feed_idea": feed_idea_process,
            }

    if in_type not in process_dict:
        raise ValueError("process type unknown: %s, expect 'idea' or 'word' " \
                "or 'click' or 'meteor' or 'feed'." % in_type)

    processor = process_dict[in_type]
    segger = word_segger.WordSegger()
    user_set = get_users("data/user_info.txt")

    ignore = not common.Common.is_online_mapred()
    for line in sys.stdin:
        res = processor(line, user_set, ignore)
        if res is None:
            continue
        if in_type == "url":
            print_url_line(segger, res)
        else:
            text_seg = "\x02".join(segger.seg_words(res["text"]))
            print("\t".join([
                    str(random.randint(0, 30000)),
                    res["userid"],
                    res["planid"],
                    res["unitid"],
                    res["id"],
                    res["version"],
                    res["text"],
                    text_seg, 
                    res["url"]]).encode("gb18030"))

    segger.destroy()

if __name__ == "__main__":
    main(sys.argv[1])
