#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   zhuxiaodong01@baidu.com
#Date  :   19/05/06 16:58:10
import sys
reload(sys)
sys.setdefaultencoding("gbk")

if __name__ == "__main__":
    for eachline in sys.stdin:
        print "\t".join(eachline.strip("\n").split("\t")[1:])

