#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/03/10 15:00:00
Desc  :   �ڴ������˻���Ϣ����������������������Ϣ���˻�״̬
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import json

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import common.common as common
import service_filter.service_mapper as service_class
import review_object.service_object as service_object

if __name__ == "__main__":
    s = service_class.Servicer()
    s.init()
    for eachline in sys.stdin:
        line = eachline.strip("\n")
        s_obj = service_object.ServiceResultObj()
        s_obj.init(line)

        # �ڴ�����
        userid = s_obj.user_info["userid"]
        optids, opts = common.Common.get_online_opt(userid)
        s_obj.user_info["info"]["optids"] = optids
        s_obj.user_info["info"]["opts"] = opts

        # ����service filter
        for k in s.service_obj:
            service = s.service_obj[k]
            service_conf = service["service_conf_info"]
            check_result, model_id = service["obj"].check(s_obj, service_conf)
            s_obj.add_result(service_conf, check_result, model_id)
        result = s_obj.service_result()
        print json.dumps(result)
