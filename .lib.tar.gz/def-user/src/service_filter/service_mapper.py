#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/04/28 14:03:26
Desc  :   ҵ��
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import re
import json
import random

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.service_object as service_object
import conf

class Servicer(object):
    """ҵ����, ��ʼ��ҵ������
    """
    def __init__(self):
        """init"""
        pass

    def init(self):
        """��ʼ��ҵ��
        [in]  data_type: 1, ������; 2, ��Σ�˻�
        [out] None
        """
        # import service
        self.service_obj = {}
        for k in conf.service:
            service = conf.service[k]
            if not service["enable"]:
                continue
            based_service = service["based_service"] 
            for sub_service in service["sub_service"]:
                sub_service = dict(based_service, **sub_service)
                if not sub_service["enable"]:
                    continue
                sub_kid = k + sub_service["service_id"]
                sub_service["service_id"] = sub_kid
                
                self.service_obj[sub_kid] = {}
                self.service_obj[sub_kid]["service_conf_info"] = sub_service 
                m_module = __import__(sub_service["service_module"], fromlist = ['default'])
                m_class = getattr(m_module, sub_service["service_class"])
                m_obj = m_class()
                self.service_obj[sub_kid]["obj"] = m_obj

if __name__ == "__main__":
    s = Servicer()
    s.init()
    for eachline in sys.stdin:
        line = eachline.strip("\n")
        s_obj = service_object.ServiceResultObj()
        s_obj.init(line)
        for k in s.service_obj:
            service = s.service_obj[k]
            service_conf = service["service_conf_info"]
            check_result, model_id = service["obj"].check(s_obj, service_conf)
            s_obj.add_result(service_conf, check_result, model_id)

        result = s_obj.service_result()
        print "%d\t%s" % (random.randint(0, 100000), json.dumps(result))
