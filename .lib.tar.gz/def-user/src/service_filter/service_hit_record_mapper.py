#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/10/29 10:03:30
DESC  :   ɸѡ���е�service���,��ֹgetmerge�����غ�ʱ����
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")

import json
import random

if __name__ == "__main__":
    for eachline in sys.stdin:
        line = eachline.strip("\n")
        service_obj = json.loads(line)
        service_result = service_obj["service_result"]
        for s_obj in service_result:
            if s_obj["is_hit"]:
                print "%d\t%s" % (random.randint(0, 100000), line)
                break
