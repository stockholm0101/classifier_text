#!/usr/bin/env python
# -*- coding: gbk -*-
 
"""
Author:   zhubenchang@baidu.com
Date  :   20/02/21 16:43:19
DESC  :   ��ظ�Σ�豸�����˺ŵ���������
"""

import os
import sys
reload(sys)
sys.setdefaultencoding("gbk") 

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)
import review_object.review_object as review_object
import common.common as common
import common.rule_detector as rule_detector
import codecs


class RiskDeviceMeteor(object):
    """��ظ�Σ�豸�����˺ŵ���������
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword: ͣ�ôʼ���
              model_dir: ģ��Ŀ¼
        [out] None
        """
        self.word_segger = word_segger
        self.stopword = stopword

        self.risk_user_path = os.path.join(model_dir, "risk_user.txt")
        self.risk_user_set = self.get_risk_user()


    def get_risk_user(self):
        """��ȡ��Σ�豸���µ���Ч�˻�
        [in] None
        [out] user_set : ��Σ�˻����� set
        """
        user_set = set()
        with codecs.open(self.risk_user_path, "r", "gb18030") as f:
            for line in f:
                parts = line.strip("\n").split("\t")
                risk_userid = parts[0]
                score = float(parts[1])
                if score >= 0.9:
                    user_set.add(risk_userid)
        return user_set

    def check(self, r_obj):
        """�����û��������
        [in]  r_obj: ��Ԥ�����
        [out] check_ad_result_obj: {
                "label": Ԥ���ǩ, 
                "lable_name": Ԥ���ǩ����, 
                "label_list": ��ϸԤ����[[label1, name, val], [...], ...],
                "opt": ������Ϣ}
        """
        
        check_ad_result_obj = review_object.CheckClickResultObj()
        # label Ĭ��ֵ0, ��ʾ�����ϲ��ǶĲ�����
        label = "0"
        label_name = u"�޷���"
        label_list = []
        opt_info = {}
        check_ad_result_obj.init(label, label_name, label_list, opt_info)

        text = r_obj.text

        if text and (r_obj.userid in self.risk_user_set):
            label = "1"
            label_name = u"����������"
            label_list = [[label, label_name, 1]]
            check_ad_result_obj.opt["risk_text"] = text
        else:
            return None
        
        check_ad_result_obj.label_list = label_list
        check_ad_result_obj.label = label
        check_ad_result_obj.label_name = label_name
        return check_ad_result_obj.convert_to_dict()
    


if __name__ == "__main__":

   # def sizeof(obj):
   #     """����obj�Ĵ�С����λΪM
   #     """
   #     print getsizeof(obj)/float(1024**2)

    def test():
        """��Ԫ����
        """
        import conf
        import time

        segdict_path = "dict/chinese_gbk"
        stopword_file = "data/stopword.txt"
        import word_seg
        stopword = common.Common.load_word_file(stopword_file)
        word_segger = word_seg.WordSeg(segdict_path)
        word_segger.init_wordseg_handle()
        model_dir = "model/model_42_risk_device"
        ruleDetector = RiskDeviceMeteor()
        ruleDetector.init(word_segger, stopword, model_dir)
        print ruleDetector.risk_user_set
        #sizeof(ruleDetector)
        # ����r_obj
        for eachline in sys.stdin:
            line = eachline.strip("\n").lower().decode("gbk", "ignore").split("\t")
            #line = eachline.strip("\n").lower().split("\t")
            #print line
            r_obj = None
            r_obj = review_object.ReviewClickAdObj()
            r_obj.init(line)
            
            # ��ʼʱ��
            start_time = time.time()
            #print "start_time %s" % (start_time)
            check_result = ruleDetector.check(r_obj)
            end_time = time.time()
            print "use_time %.4f" % (end_time - start_time)
            print check_result
    test()
