#!/usr/bin/env python
#-*- coding:gb18030 -*-
################################################################################
#
# Copyright (c) 2017 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
This module provides ***
Authors: gancaizhao@baidu.com
Date: 2019/12/26 10:51:46
"""
import re
import sys
import os
import math

reload(sys)
sys.setdefaultencoding('gb18030')

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)

import common.common as common

class LpIntentionDetector(object):
    """ʶ�����ҳ���ƹ���ͼ
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """init
        """
        name_threshold_file = os.path.join(model_dir, "class_id_threshold.txt")
        self.model_th_dict = common.Common.load_class_name_thres(name_threshold_file)
        model_weight_file = os.path.join(model_dir, "model_feature.txt")
        self.lr_model = common.LpLrPredict(model_weight_file)
        stop_word_file = os.path.join(model_dir, "stop_word.txt")
        self.stop_word_set = common.Common.load_word_file(stop_word_file)
        self.chinese = re.compile(ur'^[\u4e00-\u9fa5]+$')
        self.ngram_number = 3

    def token_sentence(self, line):
        """���ı��ִ�
        """
        word_list = line
        token_list = []
        for word in word_list:
            if len(word.strip()) == 0:
                continue
            if not self.chinese.search(word):
                continue
            if word in self.stop_word_set:
                continue
            token_list.append(word)
        return "\t".join(token_list)
    
    def get_feature_list(self, input_dict, ngram_number):
        """ �Ը������ַ�����ȡ����.
        [in]
        input_dict : dict, ������������ֵ�
        [out]
        feature_words : list, ����λ����Ϣ��ngram����
        """
        feature_words = set([])
        for tagname in input_dict.keys():
            segments = map(lambda x: ";".join([x, tagname]), input_dict.get(tagname).split("\t"))
            segments = [x.lower() for x in segments]
            feature_words |= common.Common.ngram(segments, ngram_number + 1)
        return list(feature_words)

    def get_result(self, predict_label, predict_rate):
        """����Ԥ�����͸������ֵ��������ս��
        """
        this_type_threshold = self.model_th_dict[predict_label][1]
        if predict_label != 0 and predict_rate > this_type_threshold:
            return predict_label, self.model_th_dict[predict_label][0]
        return 0, u"�޷���"

    def get_label_list(self, labels_rate):
        """��ȡlabel_list
        """
        label_list = []
        for index in range(len(labels_rate)):
            label_list.append([str(index), self.model_th_dict[index][0], str(labels_rate[index])])
        return label_list

    def check(self, r_obj):
        """checkһ���ı�����
        """
        input_dict = dict()
        input_item = [
            "title",
            "navi",
            "content",
            "meta_keywords",
            "meta_desc",
            "in_anchor",
            "out_anchor"
            ]
        feature_item = ['title',
                'navigation',
                'sem_central_content',
                'keywords',
                'abstract',
                'inner_links',
                'links']
        for index in range(len(feature_item)):
            input_dict[input_item[index]] = self.token_sentence(r_obj.feature_seg_dict[feature_item[index]])
        feature_list = self.get_feature_list(input_dict, self.ngram_number)
        result, predict_index = self.lr_model.predict(feature_list)
        predict_rate = result['predict_pro'][predict_index]
        predict_label, label_name = self.get_result(predict_index, predict_rate)
        label_list = self.get_label_list(result['predict_pro'])
        
        check_result = {}
        check_result["label"] = str(predict_label)
        check_result["label_name"] = label_name
        check_result["label_list"] = label_list
        check_result["opt"] = {}
        return check_result

if __name__ == '__main__':
    import word_seg

    class ReviewUrlObj(object):
        """������������
        """
        def __init__(self):
            """init
            """
            self.url = ""
            self.feature_seg_dict = {}
    
    def display_result(check_result):
        """չʾ���
        """
        print('\t'.join(["label_id:", str(check_result['label']), \
                "label_name:", check_result["label_name"]]))
        for item in check_result['label_list']:
            item = [str(it) for it in item]
            print('\t'.join(item))

    stop_word = set([])
    segdict_path = "dict/chinese_gbk"
    word_segger = word_seg.WordSeg(segdict_path)
    word_segger.init_wordseg_handle()
    detector = LpIntentionDetector()
    detector.init(word_segger, stop_word, 'model/model_110205102800_lp_intention/')

    for line in sys.stdin:
        parts = line.strip("\n").lower().split("\t")
        url = parts[0]
        feature_seg_dict = {'title': parts[1],
                'navigation': parts[2],
                'sem_central_content': parts[3],
                'key_words': parts[4],
                'abstract': parts[5],
                'in_links': parts[6],
                'out_links': parts[7]
                }
        for item in feature_seg_dict.items():
            feature_seg_dict[item[0]] = '\t'.join(word_segger.seg_words(item[1]))
        r_obj = ReviewUrlObj()
        r_obj.url = url
        r_obj.feature_seg_dict = feature_seg_dict
        check_result = detector.check(r_obj)
        display_result(check_result)

    word_segger.destroy_wordseg_handle()
