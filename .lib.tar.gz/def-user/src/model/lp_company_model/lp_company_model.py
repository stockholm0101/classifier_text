#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   xuming06@baidu.com
Date  :   20/05/21 11:29:25
Desc  :   
"""
import sys
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)

import common.common as common
import common.rule_detector as rule_detector

class LpCompanyRule(object):
    """���ҳ�ı����еĹ�˾����
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """init"""
        rule_file = os.path.join(model_dir, "rule.txt")
        self.detector_src = rule_detector.RuleDetector(word_segger, 
                punctuations=r",|;|\?",
                rule_path=rule_file)

    def check(self, r_obj):
        """check lp text
        """
        src_rules = self.detector_src.check("0", r_obj.src, shallow=False)

        # 4:src
        rules_type = {"4": src_rules}

        labels = set()
        for k in rules_type:
            for rule in rules_type[k]:
                scope = rule.rule_scope
                # 4:src
                if k not in scope:
                    continue
                labels.add(rule.origin_rule)

        check_result = {}
        if len(labels) == 0:
            check_result["label"] = "-1"
            check_result["label_name"] = u"�޷���"
            check_result["label_list"] = []
            check_result["opt"] = {}
        else:
            check_result["label"] = "1"
            check_result["label_name"] = u"������˾����"
            check_result["label_list"] = [[x, "1", "1"] for x in labels]
            check_result["opt"] = {}
        return check_result


if __name__ == "__main__":
    pass
