#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/03/09 22:22:19
DESC  :   base_model, Common, ֧��LP_LR�����, ���ļ���ȡ��
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import random
import re
import numpy as np

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
sys.path.append("%s/../../" % _cur_dir)

import common.common as common
import review_object.review_object as review_object


class LpBaseModel(object):
    """ʾ��ģ��, LP_LR�����ģ��
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword: ͣ�ôʼ���
              model_dir: ģ��Ŀ¼
        [out] None
        """
        self.word_segger = word_segger
        self.stopword = stopword

        #������ģ���ļ�����
        bi_model_file = os.path.join(model_dir, "bi_model.txt")
        bi_feature_id_file = os.path.join(model_dir, "bi_feature_id.txt")
        bi_class_id_file = os.path.join(model_dir, "bi_class_id.txt")

        self.bi_model_dict, self.bi_model_feature_num = common.Common.load_multiclass_lr_model_file(bi_model_file)
        self.bi_class_dict = common.Common.load_class_id_file(bi_class_id_file)
        self.bi_feature_dict = common.Common.load_feature_id_file(bi_feature_id_file)
        self.bi_feature_dict_keys = set(self.bi_feature_dict.keys())
        self.bi_class_thres = common.Common.load_class_thres(bi_class_id_file)

        #�����ģ���ļ�����
        model_file = os.path.join(model_dir, "model.txt")
        feature_id_file = os.path.join(model_dir, "feature_id.txt")
        class_id_file = os.path.join(model_dir, "class_id.txt")

        self.model_dict, self.model_feature_num = common.Common.load_multiclass_lr_model_file(model_file)
        self.class_dict = common.Common.load_class_id_file(class_id_file)
        self.feature_dict = common.Common.load_feature_id_file(feature_id_file)
        self.feature_dict_keys = set(self.feature_dict.keys())
        self.class_thres = common.Common.load_class_thres(class_id_file)

    def extract_text_ngram_feature(self, text_list):
        """��ȡngram feature, text_list��δ�д�
        [in]  text_list: ����ȡ���ı�, [text, text, ...]
        [out] ngram_feature: �д�ngram�����������
        """
        ngram_feature = set()
        for text in text_list:
            text_ngram = common.Common.ngram_feature(self.word_segger, text, self.stopword)
            ngram_feature |= text_ngram
        return ngram_feature

    def extract_seglist_ngram_feature(self, seg_list):
        """��ȡngram feature, seg_list�Ѿ��й���, ��Ҫ��ngram
        [in]  seg_list: [��1, ��2, ...]
        [out] ngram_feature: ngram�����������
        """
        ngram_feature = common.Common.ngram_feature(seg_list, self.stopword)
        return ngram_feature

    def check(self, r_obj):
        """����, Ԥ��
        [in]  r_obj: ��Ԥ��Ķ���
        [out] check_result: {"label": ģ�ͽ���ı�ǩ, 
                             "lable_name": ģ�ͽ���ı�ǩ��, 
                             "label_list": ��ϸԤ����[[label1, name, val], [...], ...]}
        """
        check_unit_result_obj = review_object.CheckUnitResultObj()
        key = ["title", "navigation", "sem_central_content", "keywords", "abstract", "inner_links", "links"]
        feature_list = []
        for k in key:
            feature_list += r_obj.feature_seg_dict[k]
        feature = " ".join(feature_list)

        ######�Լ��дʽӿ�
        #word_ngram = self.extract_text_ngram_feature(r_obj.word_list)
        #idea_ngram = self.extract_text_ngram_feature(r_obj.idea_list)
        ######
        word_ngram = self.extract_seglist_ngram_feature(feature_list)
        idea_ngram = self.extract_seglist_ngram_feature(feature_list)
        words = word_ngram | idea_ngram

        bi_hit_feature = words & self.bi_feature_dict_keys
        bi_hit_feature_num = len(bi_hit_feature)
        if bi_hit_feature_num < 2:
            return check_unit_result_obj.convert_to_dict()

        bi_label_list = common.Common.cal_multiclass_lr_predict(self.bi_model_dict, self.bi_model_feature_num, \
                self.bi_feature_dict, self.bi_class_dict, bi_hit_feature)
        if len(bi_label_list) == 0:
            check_unit_result_obj.label = "-10"
            return check_unit_result_obj.convert_to_dict()

        bi_label = bi_label_list[0][0]
        if bi_label == "0":
            check_unit_result_obj.label = "0"
            check_unit_result_obj.label_name = u'����'
            check_unit_result_obj.label_list = bi_label_list
            return check_unit_result_obj.convert_to_dict()

        hit_feature = words & self.feature_dict_keys
        hit_feature_num = len(hit_feature)
        label_list = common.Common.cal_multiclass_lr_predict(self.model_dict, self.model_feature_num, \
                self.feature_dict, self.class_dict, hit_feature)

        if len(label_list) == 0:
            check_unit_result_obj.label = "-10"
            return check_unit_result_obj.convert_to_dict()

        check_unit_result_obj.label = label_list[0][0]
        check_unit_result_obj.label_name = label_list[0][1]
        check_unit_result_obj.label_list = label_list

        if label_list[0][0] in self.class_thres and \
                float(label_list[0][2]) < self.class_thres[label_list[0][0]]:
            check_unit_result_obj.label = "0"
            check_unit_result_obj.label_name = u'����'

        return check_unit_result_obj.convert_to_dict()

if __name__ == "__main__":
    def test():
        """��Ԫ����
        """
        import conf
        import time

        segdict_path = "dict/chinese_gbk"
        stopword_file = "data/stopword.txt"
        import word_seg
        stopword = common.Common.load_word_file(stopword_file)
        word_segger = word_seg.WordSeg(segdict_path)
        word_segger.init_wordseg_handle()
        model_dir = "model/model_3204_lp_gamble"
        lpmodel = LpBaseModel()
        lpmodel.init(word_segger, stopword, model_dir)
        
        #sizeof(lpmodel)
        # ����r_obj
        for eachline in sys.stdin:
            line = eachline.strip("\n").lower().decode("gbk", "ignore").split("\t")
            #print line
            r_obj = None
            r_obj = review_object.ReviewUrlObj()
            r_obj.init(line)
            
            # ��ʼʱ��
            start_time = time.time()
            print "start_time %s" % (start_time)
            check_result = lpmodel.check(r_obj)
            end_time = time.time()
            print "use_time %.4f" % (end_time - start_time)
            print check_result
    test()
