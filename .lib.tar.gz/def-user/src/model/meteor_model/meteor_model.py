#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   19/05/23 15:24:28
Desc  :   
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.merge_object as merge_object

class MeteorModel(object):
    """meteor model, ����meteor��modelid���е���������ռ��
    """
    def __init__(self):
        """init"""
        pass

    def init(self, model, class_dict):
        """init"""
        self.model_info = model
        self.class_dict = class_dict

    def check(self, meteor_user):
        """��meteor_userתΪMergeObj����
        [in]  meteor_user: review_object.py �е�MeteorUser
        [out] ret: 0����, -1û��ģ�ͽ��
              model_conf_info: תΪMergeObj�ı�Ҫ��Ϣ
              model_merge_result: תΪMergeObj��ģ�ͽ����Ϣ
        """
        ret = -1
        model_conf_info = {}
        model_merge_result = merge_object.MergeResultObj()
        if len(meteor_user.model_result) == 0:
            return ret, model_conf_info, model_merge_result
        else:
            max_hit_ad_num = 0
            max_model_id = None
            for model_id in meteor_user.model_result:
                if max_hit_ad_num < meteor_user.model_result[model_id]["hit_ad_num"]:
                    max_hit_ad_num = meteor_user.model_result[model_id]["hit_ad_num"]
                    max_model_id = model_id

            if max_model_id is None:
                return ret, model_conf_info, model_merge_result

            # ռ������model_id, ����Ӧ������
            m_result = meteor_user.model_result[max_model_id]
            val = (0.0 + max_hit_ad_num) / meteor_user.total_disapproved
            if len(m_result["opt_args"]) > 0 and (val < m_result["opt_args"]["percent_thres"] or \
                    max_hit_ad_num < m_result["opt_args"]["adnum_thres"]):
                return ret, model_conf_info, model_merge_result

            ret = 0
            label = "1"
            label_name = self.class_dict[max_model_id][label]
            label_list = []
            label_list.append([label, label_name, str(val)])
            evidence = {}
            evidence["word"] = list(m_result["evidence"]["word"])
            evidence["idea"] = list(m_result["evidence"]["idea"])
            model_merge_result.init(label, label_name, label_list, evidence)

            model_conf_info["model_id"] = max_model_id
            model_conf_info["model_type"] = m_result["model_type"]
            model_conf_info["model_name"] = m_result["model_name"]

        return ret, model_conf_info, model_merge_result


if __name__ == "__main__":
    pass
