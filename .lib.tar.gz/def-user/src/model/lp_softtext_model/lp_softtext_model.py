#!/usr/bin/env python
#-*- coding:gb18030 -*-
################################################################################
#
# Copyright (c) 2019 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
This module provides ***
Authors: liuxingwang(liuxingwang@baidu.com)
Date: 20179/12/12 12:03:13
"""
import re
import sys
import time
import math
import random
import random
import numpy as np
import os

def check_html(line):
    """�����ҳ���������ݳ���
    [in]: 
        line:7��feature
    [out]: 
        7��feature
    """
    one = line.split("\t")
    base_len = len(one[3])
    rate = 0.4
    ere = 0.000001
    titel_site = 1
    out_anchor_site = 8
    conten_site = 3
    if base_len - 0 < ere:
        return line
    for i in range(titel_site, out_anchor_site):
        if conten_site != i:
            if (len(one[i]) * 1.0) / base_len - rate > ere:
                one[conten_site] += " " + one[i]
                one[i] = " "
    return "\t".join(one)

def get_ngram(tokens, max_order, max_order_only=False, filter_short_gram=True):
    """��ȡngram
    [in]: 
        tokens ��
        max_order ���ȡ��gram
        max_order_only ֻȡ���ngram
        filter_short_gram ���˵�����
    [out]: 
        ngram ������
    """
    tokens = [x.lower() for x in tokens]
    start_order = max_order if max_order_only else 1
    ngram_list = []
    for order_index in range(start_order, max_order + 1):
        for seq_index in range(0, len(tokens) - order_index + 1):
            sub_tokens = tokens[seq_index: seq_index + order_index]
            ngram = ''.join(sub_tokens)
            if (not filter_short_gram or len(ngram.split(";")[0]) > 1):
                ngram_list.append(ngram)
    return set(ngram_list)


def get_feature_list(input_dict, ngram_list):
    """ �Ը������ַ�����ȡ����.
    [in]:
        input_dict : dict, ������������ֵ�
        ngram_list : list, ��������������Ҫ���ngram��ʽ.
    [out]:
        None
    """
    feature_words = set([])
    for tagname in input_dict.keys():
        segments = map(lambda x: ";".join([x, tagname]), input_dict.get(tagname).split(" "))
        for ngram in ngram_list:
            feature_words |= get_ngram(segments, ngram, True, False)
    return list(feature_words)

class LrPredict(object):
    """ LRģ��Ԥ����.
    """
    def __init__(self):
        pass
    def init(self, word_segger, stopword, model_dir):
        """
        [in]:
            word_segger �д�
            stopword ͣ�ôʼ���
            model_dir : ģ���ļ�·����.
        [out]:
            None
        """
        self.word_segger = word_segger
        self.stopword = stopword
        self.word_weight_list = []
        self.model_bias_list = []
        self.index_map_label = {}

        self.chinese = re.compile(ur'^[\u4e00-\u9fa5]+$')
        self.english = re.compile(".*[a-zA-Z0-9]+")
        model_filename_path = os.path.join(model_dir, "lp_softtext_model.txt") 
        stopword_file_name_path = os.path.join(model_dir, "stop_word.txt")
        model_threshold_file = os.path.join(model_dir, "model_conf.txt")
        self.load_stop_word(stopword_file_name_path)
        self.load_model_weight(model_filename_path)
        self.load_model_conf(model_threshold_file)

    def load_model_conf(self, model_threshold_file):
        """����ģ����ֵ����
        [in]:
            model_threshold_file ģ����ֵ�����ļ�
        [out]:
            None
        """
        self.model_threshold_dic = {}
        with open(model_threshold_file) as f:
            for line in f:
                one_conf = line.strip("\n").split(" ")
                self.model_threshold_dic[one_conf[0]] = float(one_conf[1])

    def load_stop_word(self, stopword_file_name_path):
        """����ͣ�ô�
        [in]:
            stopword_file_name_path ͣ�ô��ļ�
        [out]:
            None
        """
        self.stopword_dict = {}
        with open(stopword_file_name_path, 'r') as f:
            for line in f:
                line = line.strip("\n").decode("gbk")
                word = line.split("\t")[0]
                if word:
                    self.stopword_dict[word] = None

    def load_model_weight(self, filename):
        """ ����ģ��Ȩ�ز���.
        [in]:
            filename : id.weight.word�ļ�����·��.
        [out]:
            None
        """
        self.word_weight_list = []
        self.model_bais_list  = []
        with open(filename, 'r') as f:
            for line in f:
                line = line.strip("\n")
                cols = line.split("\t")
                if 1 == len(cols):
                    label_list = line.decode('gbk', 'ignore').split(" ")
                    for index, label in enumerate(label_list):
                        self.index_map_label[index] = label
                    continue
                if len(cols) != 3:
                    continue
                id = cols[0]
                weight_list = cols[1].split("|")
                weight_list = map(lambda x: float(x), weight_list)
                word = cols[2].decode("gbk", "ignore")
                if (id == "-1") and (word.split(";")[-1] == "bias"):
                    bias_list = weight_list
                    for bias in bias_list:
                        self.model_bias_list.append(bias)
                        self.word_weight_list.append({})
                    continue
                if (int(id) >= 0):
                    for class_id, weight in enumerate(weight_list):
                        self.word_weight_list[class_id][word] = weight

    def is_stopword(self, word):
        """�ж��Ƿ�Ϊͣ�ôʣ��˴��������Ķ�����ͣ�ô�.
        [in]:
            word һ����
        [out]:
            None
        """
        #word = word.decode("gbk", "ignore")
        if len(word) < 2:
            pass
        if  not self.chinese.search(word):
            return True
        if (word in self.stopword_dict):
            return True
        return False

    def softmax(self, score_list):
        """ softmax.
        [in]:
            score_list : ��ͬ����Ȩֵ.
        [out]:
            pro_dist : ���ʷֲ�.
        """
        pro_dist = []
        score_list = np.array(score_list)
        max_val = max(score_list)
        score_list = score_list - max_val
        exp_list = np.exp(score_list)

        esum = np.sum(exp_list)
        for score in exp_list:
            pro_dist.append(score / esum)
        return np.array(pro_dist)

    def predict(self, segwords, real_label):
        """ Ԥ�⺯��.
        [in]:
            segwords : ����Ƭ�Σ�����Ϊunicode���.
            real_label : ��ʵ���.
        [out]:
            result_dict : Ԥ�����ֵ䣬���������ֶ�(unicode���):
                          ������ʣ�
                          Ԥ����ꣻ
                          ��ʵ��ꣻ
                          ��������ࣻ
        """
        result_dict = {}
        hit_list = []
        score_list = []
        for bias in self.model_bias_list:
            score_list.append(bias)
            hit_list.append([])
        for segword in set(segwords):
            for dict_index in range(len(self.word_weight_list)):
                if segword in self.word_weight_list[dict_index]:
                    score_list[dict_index] += self.word_weight_list[dict_index].get(segword)
                    weight = self.word_weight_list[dict_index].get(segword)
                    hit_list[dict_index].append(":".join([segword, str(weight)]))
        predict_pro = self.softmax(score_list)
        predict_index = np.argmax(predict_pro)
        predict_label = self.index_map_label[predict_index]
        result_dict = {
                "predict_pro": predict_pro,
                "predict_label": predict_label,
                "real_label": real_label,
                "predict_index": predict_index
                }
        return result_dict

    def text_pro_preces(self, r_obj):
        """�ı�Ԥ������ȥͣ�ôʣ�ȥ�������
        [in]:
            r_obj ����������
        [out]:
            Ԥ�����õ��ı��б�

        """
        feature_list = []
        feature_seg_dict = r_obj.feature_seg_dict
        feature_list.append(feature_seg_dict["title"])
        feature_list.append(feature_seg_dict["navigation"])
        feature_list.append(feature_seg_dict["sem_central_content"])
        feature_list.append(feature_seg_dict["keywords"])
        feature_list.append(feature_seg_dict["abstract"])
        feature_list.append(feature_seg_dict["inner_links"])
        feature_list.append(feature_seg_dict["links"])

        pro_feature_text = ["url"]

        for one_feature in feature_list:
            temp_feature = []
            for one_word in one_feature:
                if not self.is_stopword(one_word):
                    temp_feature.append(one_word)
            pro_feature_text.append(" ".join(temp_feature))
        result_text = check_html("\t".join(pro_feature_text)).split("\t")
        return result_text

    def get_lab_list(self, predict_pro):
        """����lab_list
        [in]:
            predict_pro �����Ԥ������б�
        [out]:
            lab_list
        """
        lab_list = []
        for label in range(len(self.index_map_label)):
            lab_list.append([str(label), self.index_map_label[label], predict_pro[label]])
        return lab_list

    def check(self, r_obj):
        """
        [in]  r_obj: ��Ԥ��Ķ���
        [out] check_result: {"label": ģ�ͽ���ı�ǩ, 
                            "lable_name": ģ�ͽ���ı�ǩ��, 
                            "label_list": ��ϸԤ����[[label1, name, val], [...], ...]}
        """
        feature_list = self.text_pro_preces(r_obj)

        input_dict = {
            "title": feature_list[1],
            "navi": feature_list[2],
            "content": feature_list[3],
            "meta_keywords": feature_list[4],
            "meta_desc": feature_list[5],
            "in_anchor": feature_list[6],
            "out_anchor": feature_list[7]
        }
        ngram_list = [1, 2, 3]
        feature_list = get_feature_list(input_dict, ngram_list)
        result = self.predict(feature_list, real_label = -1)
        predict_pro = result['predict_pro']
        label = result['predict_index']
        #predict_label_name = result['predict_label']

        ere = 0.000001
        check_result = {}
        check_result["label"] = "0"
        check_result['label_name'] = self.index_map_label[0]
        check_result['label_list'] = self.get_lab_list(predict_pro)
        check_result['opt'] = None

        if  predict_pro[label] - self.model_threshold_dic[str(label)] > ere:
            check_result["label"] = str(label)
            check_result['label_name'] = self.index_map_label[label]
            return check_result
        return check_result


if __name__ == '__main__':
    pass
