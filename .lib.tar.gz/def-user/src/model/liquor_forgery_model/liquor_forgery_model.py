#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   changxiaojing@baidu.com
Date  :   20/03/06 14:50:19
DESC  :   �����ð����ʶ��unitά��
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import random
import re
import numpy as np

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)

import common.common as common
import review_object.review_object as review_object

class LiquorForgeryModel(object):
    """ LR�����ģ��
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword: ͣ�ôʼ���
              model_dir: ģ��Ŀ¼
        [out] None
        """
        self.word_segger = word_segger
        self.stopword = stopword

        model_file = os.path.join(model_dir, "model.txt")
        feature_id_file = os.path.join(model_dir, "feature_id.txt")
        class_id_file = os.path.join(model_dir, "class_id.txt")

        self.model_dict, self.model_feature_num = common.Common.load_multiclass_lr_model_file(model_file)
        self.class_dict = common.Common.load_class_id_file(class_id_file)
        self.feature_dict = common.Common.load_feature_id_file(feature_id_file)
        self.feature_dict_keys = set(self.feature_dict.keys())
        self.class_thres = common.Common.load_class_thres(class_id_file)

    def extract_seglist_ngram_feature(self, seg_list):
        """��ȡngram feature, seg_list�Ѿ��й���, ��Ҫ��ngram
        [in]  seg_list: [[��һ���ؼ��ʵ��д�list], [�ڶ���], ...]
        [out] ngram_feature: ngram�����������
        """
        ngram_feature = set()
        for seg in seg_list:
            text_ngram = common.Common.ngram_feature(seg, self.stopword)
            ngram_feature |= text_ngram
        return ngram_feature

    def check(self, r_obj):
        """����, Ԥ��
        [in]  r_obj: ��Ԥ��Ķ���
        [out] check_result: {"label": ģ�ͽ���ı�ǩ, 
                             "lable_name": ģ�ͽ���ı�ǩ��, 
                             "label_list": ��ϸԤ����[[label1, name, val], [...], ...]}
        """
        check_unit_result_obj = review_object.CheckUnitResultObj()

        ######�Լ��дʽӿ�
        #word_ngram = self.extract_text_ngram_feature(r_obj.word_list)
        #idea_ngram = self.extract_text_ngram_feature(r_obj.idea_list)
        ######
        word_ngram = self.extract_seglist_ngram_feature(r_obj.word_seg_list)
        idea_ngram = self.extract_seglist_ngram_feature(r_obj.idea_seg_list)
        words = word_ngram | idea_ngram

        hit_feature = words & self.feature_dict_keys
        hit_feature_num = len(hit_feature)
        if hit_feature_num < 5:
            return check_unit_result_obj.convert_to_dict()

        label_list = common.Common.cal_multiclass_lr_predict(self.model_dict, self.model_feature_num, \
                self.feature_dict, self.class_dict, hit_feature)

        if len(label_list) == 0:
            check_unit_result_obj.label = "-10"
            return check_unit_result_obj.convert_to_dict()

        if label_list[0][0] == "0":
            check_unit_result_obj.label = label_list[0][0]
            check_unit_result_obj.label_name = label_list[0][1]
        else:
            multi_label = []
            multi_name = []
            for label_res in label_list:
                if label_res[0] in self.class_thres and \
                        float(label_res[2]) > self.class_thres[label_res[0]]:
                            multi_label.append(label_res[0]) 
                            multi_name.append(label_res[1])
            if len(multi_label) == 0:
                check_unit_result_obj.label = "0"
                check_unit_result_obj.label_name = u'�޷���'
            else:
                check_unit_result_obj.label = "|".join(multi_label)
                check_unit_result_obj.label_name = "|".join(multi_name)

        check_unit_result_obj.label_list = label_list
        return check_unit_result_obj.convert_to_dict()

if __name__ == "__main__":
    """
    def test():
        import word_seg
        import json
        segdict_path = "/home/changxiaojing/baidu/wine_risk/wuliao/def-user/src/model/liquor_forgery_model/chinese_gbk"
        stopword_file = "/home/changxiaojing/baidu/wine_risk/wuliao/def-user/src/model/liquor_forgery_model/stopword.txt"
        word_segger = word_seg.WordSeg(segdict_path)
        word_segger.init_wordseg_handle()
        stopword = common.Common.load_word_file(stopword_file)
        model_dir = "/home/changxiaojing/baidu/wine_risk/wuliao/def-user/model/model_44_liquor_forgery"

        liquor_obj = LiquorForgeryModel()
        liquor_obj.init(word_segger, stopword, model_dir)
        for eachline in sys.stdin:
            line = eachline.strip("\n").lower().decode("gbk", "ignore").split("\t")
            r_obj = review_object.ReviewUnitObj()
            r_obj.init(line)
            check_result = liquor_obj.check(r_obj)
            print(json.dumps(check_result))
    
    test()
    """
    pass
