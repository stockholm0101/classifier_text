#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   shenhao02@baidu.com
Date  :   20/04/22 17:40:25
Desc  :   
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import common.common as common
import review_object.review_object as review_object

class HunterPredict(object):
    """LR�����ģ��
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
        stopword: ͣ�ôʼ���
        model_dir: ģ��Ŀ¼
        [out] None
        """
        self.word_segger = word_segger
        self.stopword = stopword
        model_file4 = os.path.join(model_dir, "model4.txt")
        feature_id_file4 = os.path.join(model_dir, "feature_id4.txt")
        class_id_file4 = os.path.join(model_dir, "class_id4.txt")
        model_file2 = os.path.join(model_dir, "model2.txt")
        feature_id_file2 = os.path.join(model_dir, "feature_id2.txt")
        class_id_file2 = os.path.join(model_dir, "class_id2.txt")

        self.model_dict4, self.model_feature_num4 = common.Common.load_multiclass_lr_model_file(model_file4)
        self.class_dict4 = common.Common.load_class_id_file(class_id_file4)
        self.feature_dict4 = common.Common.load_feature_id_file(feature_id_file4)
        self.feature_dict_keys4 = set(self.feature_dict4.keys())
        self.model_dict2, self.model_feature_num2 = common.Common.load_multiclass_lr_model_file(model_file2)
        self.class_dict2 = common.Common.load_class_id_file(class_id_file2)
        self.feature_dict2 = common.Common.load_feature_id_file(feature_id_file2)
        self.feature_dict_keys2 = set(self.feature_dict2.keys())

    def extract_seg_ngram_feature(self, text_seg, stopword):
        """��ȡngram feature, text_seg�Ѿ��й���, ��Ҫ��ngram
        [in]  text_seg: word+idea text seg
        [out] ngram_feature: ngram�����������
        """
        features = set()
        skip_stopword = []
        for x in text_seg:
            if x in stopword:
                features |= common.Common.ngram(skip_stopword, 3)
                skip_stopword = []
                continue
            skip_stopword.append(x)
        if len(skip_stopword) > 0:
            features |= common.Common.ngram(skip_stopword, 3)
        return features
    
    def get_features(self, r_obj):
        all_seg_list = []
        for word_seg in r_obj.word_seg_list:
            for word in word_seg:
                all_seg_list.append(word)
        for idea_seg in r_obj.idea_seg_list:
            for idea in idea_seg:
                all_seg_list.append(idea)
        features = self.extract_seg_ngram_feature(all_seg_list, self.stopword)
        return features
    
    def check(self, r_obj):
        """����, Ԥ��
        [in]  r_obj: ��Ԥ��Ķ���
        [out] check_result: {"label": ģ�ͽ���ı�ǩ, 
        "lable_name": ģ�ͽ���ı�ǩ��, 
        "label_list": ��ϸԤ����[[label1, name, val], [...], ...]}
        """
        check_unit_result_obj = review_object.CheckUnitResultObj()
        features = self.get_features(r_obj)
        # ��һ�����࣬4��������
        hit_feature = features & self.feature_dict_keys4
        hit_feature_num = len(hit_feature)
        if hit_feature_num < 5:
            return check_unit_result_obj.convert_to_dict() 
        label_list = common.Common.cal_multiclass_lr_predict_otherway(self.model_dict4, self.model_feature_num4, \
                self.feature_dict4, self.class_dict4, hit_feature)
        if len(label_list) == 0:
            check_unit_result_obj.label = "-10" 
            return check_unit_result_obj.convert_to_dict()
        #һ�����౻�ж�Ϊ����½�����������£���Ҫϸ�ֱ�ǩ���ղ�����/����ׯ�ڣ�
        if label_list[0][0] == "1" and label_list[0][2] > 0.51:
            hit_feature_2 = features & self.feature_dict_keys2
            hit_feature_num_2 = len(hit_feature)
            if hit_feature_num_2 < 5:
                return  check_unit_result_obj.convert_to_dict() 
            label_list_2 = common.Common.cal_multiclass_lr_predict_otherway(self.model_dict2, self.model_feature_num2, \
                    self.feature_dict2, self.class_dict2, hit_feature_2)
            if len(label_list_2) == 0:
                check_unit_result_obj.label = "-10" 
                return check_unit_result_obj.convert_to_dict()
            check_unit_result_obj.label = label_list_2[0][0]
            check_unit_result_obj.label_name = label_list_2[0][1]
            check_unit_result_obj.label_list = label_list_2
            return check_unit_result_obj.convert_to_dict()
        # �������漰������ֳ���ж�
        if (label_list[0][0] == "2" and label_list[0][2] > 0.51) or (label_list[0][0] == "3" and label_list[0][2] > 0.51):
            check_unit_result_obj.label = label_list[0][0]
            check_unit_result_obj.label_name = label_list[0][1]
            check_unit_result_obj.label_list = label_list
            return check_unit_result_obj.convert_to_dict()
        # ʣ�µı��ж�Ϊ������
        check_unit_result_obj.label = "4"
        check_unit_result_obj.label_name = self.class_dict4["4"]
        check_unit_result_obj.label_list = label_list

        return check_unit_result_obj.convert_to_dict()
        
if __name__ == "__main__":
    pass
