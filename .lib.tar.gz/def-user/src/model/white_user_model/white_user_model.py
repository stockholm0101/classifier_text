#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   19/10/12 16:20:42
Desc  :   
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)

import common.common as common
import common.rule_detector as rule_detector
import review_object.review_object as review_object
import codecs
import random

class WhiteUserDetector(object):
    """����ʶ�Ӧ��ģ��label
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword: ͣ�ôʼ���
              model_dir: ģ��Ŀ¼
        [out] None
        """
        # ���شʱ��ļ�
        rule_file = os.path.join(model_dir, "rule.txt")
        self.detector = rule_detector.RuleDetector(
                word_segger = word_segger, 
                rule_path = rule_file)

        # �������
        class_id_file = os.path.join(model_dir, "class_id.txt")
        self.class_dict = common.Common.load_class_id_file(class_id_file)

        # ����userid��Ӧ�Ĺ�˾��
        user_file = "data/effuser.txt"
        self.userid_company_dict = self.load_userid_company_file(user_file)

    def load_userid_company_file(self, user_file):
        """����userid��Ӧ�Ĺ�˾��
        [in]  user_file: userid, username, ka/��С, status, company, url, date
              encoding: �ļ�����
        [out] userid_company_dict: userid -> company name
        """
        userid_company_dict = {}
        with open(user_file, "r") as f:
            for eachline in f:
                eachline = eachline.decode("gbk", "ignore").replace(u"��", "(").replace(u"��", ")")
                line = eachline.strip("\n").split("\t")
                userid = line[0]
                company = line[4]
                userid_company_dict[userid] = company
        return userid_company_dict

    def check(self, r_obj):
        """���userid�Ƿ��а�������ǩ
        [in]  r_obj: ��Ԥ�����
        [out] check_ad_result_obj: {
                "label": Ԥ���ǩ, str
                "label_name": Ԥ���ǩ����, str
                "label_list": ��ϸԤ����[[label1, name, val], [...], ...]
                "opt": ������Ϣ
        }
        """
        check_user_result_obj = review_object.CheckUserResultObj()

        # ��˾�����е����й���
        company = self.userid_company_dict.get(r_obj.userid, "")
        res = self.detector.check(r_obj.userid, company, shallow = True)
        label_list = []
        for rule in res:
            label = rule.rule_classes
            for l in label:
                label_list.append([l, self.class_dict[l], 1.0])

        if len(label_list) == 0:
            check_user_result_obj.label = "-10"
            return check_user_result_obj.convert_to_dict()

        index = random.randint(0, len(label_list) - 1)
        check_user_result_obj.label = label_list[index][0]
        check_user_result_obj.label_name = label_list[index][1]
        check_user_result_obj.label_list = label_list
        return check_user_result_obj.convert_to_dict()


if __name__ == "__main__":
    pass
