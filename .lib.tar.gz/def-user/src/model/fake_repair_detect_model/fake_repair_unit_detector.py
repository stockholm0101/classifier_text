#!/usr/bin/env python
# -*- coding: gbk -*-
 
"""
Author:   zhanghao55@baidu.com
Date  :   19/04/29 16:55:19
DESC  :   ά����ҵ��ð�ٷ�����ʶ��
"""

import os
import sys
reload(sys)
sys.setdefaultencoding("gbk") 
import codecs

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)
import review_object.review_object as review_object

from brand_detector import BrandDetector
from fake_repair_intention_detector import FakeRepairDetector

class FakeRepairUnitDetector(object):
    """ʶ��ά����ҵ��ð�ٷ��ĵ�Ԫ
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword: ͣ�ôʼ���
              model_dir: ģ��Ŀ¼
        [out] None
        """
        self.brand_num_threshold = 2
        self.high_risk_ratio_threshold = 0.2

        # �������ļ�
        white_user_file = os.path.join(model_dir, "white_user.txt")

        # Ʒ�Ƽ�������ļ�
        user_tag_file = os.path.join(model_dir, "user_tag.txt")
        brand_rule_file = os.path.join(model_dir, "brand_rule.txt")
        brand_map_file = os.path.join(model_dir, "brand_map.txt")
        brand_exclude_file = os.path.join(model_dir, "brand_exclude.txt")

        self.white_user_set = self.load_user_set(white_user_file)

        self.userid_set = self.load_user_set(user_tag_file)

        #����Ʒ�Ƽ����
        self.detector = BrandDetector(
                word_segger = word_segger,
                user_tag_path = user_tag_file,
                brand_rule_path = brand_rule_file,
                brand_map_path = brand_map_file,
                brand_exclude_path = brand_exclude_file)

        # ���ط�ð�ٷ������
        self.inferer = FakeRepairDetector(
                word_segger = word_segger,
                stopword = stopword,
                model_dir = model_dir)

    def check(self, r_obj):
        """�����û��������
        [in]  r_obj: ��Ԥ�����
        [out] check_unit_result_obj: {
                "label": Ԥ���ǩ, 
                "lable_name": Ԥ���ǩ����, 
                "label_list": ��ϸԤ����[[label1, name, val], [...], ...],
                "opt": ������Ϣ}
        """
        
        check_unit_result_obj  = review_object.CheckUnitResultObj()
        # label Ĭ��ֵ0, ��ʾ���û����Ƿ�ð�ٷ��˻�
        check_info = None
        label = "0"
        label_name = u"�޷���"
        label_list = []
        opt_info = {}
        check_unit_result_obj.init(label,label_name,label_list,opt_info)
        while True:
            if r_obj.userid not in self.userid_set:
                check_info = u"�û�������ά����ҵ"
                break

            if r_obj.userid in self.white_user_set:
                check_info = u"�û����ڷ�ðά��ģ�͵İ������ͻ�"
                break

            idea_num = len(r_obj.idea_list)
            idea_num = 1 if idea_num == 0 else idea_num
            keyword_num = len(r_obj.word_list)
            keyword_num = 1 if keyword_num == 0 else keyword_num
            total_pair_num = float(idea_num*keyword_num)
            # �����õ�Ԫ�����
            #1. �ἰƷ�Ƶĸ���
            total_brand_detected_count = 0
            brand_detected_set = set()
            #2. �ἰƷ�Ƶ�ռ��
            #idea_brand_detected_count = 0
            #keyword_brand_detected_count = 0
            #total_brand_detected_ratio = 0.0
            #3. �߷�ð���յ����ϸ���
            total_high_risk_count = 0
            idea_risk_evidence = list()
            word_risk_evidence = list()
            #4. �õ�Ԫ�߷�ð���յ�ռ��
            idea_high_risk_count = 0
            keyword_high_risk_count = 0
            total_high_risk_ratio = 0.0

            
            for keyword, keyword_seg in zip(r_obj.word_list, r_obj.word_seg_list):
                _, origin_brand = self.detector.detect(r_obj.userid,keyword)
                pred_label, pred_confidence = self.inferer.check(keyword_seg)
                if origin_brand is not None:
                    brand_detected_set.add(origin_brand)
                if pred_label == "2":
                    keyword_high_risk_count += 1
                    word_risk_evidence.append(keyword)
                    
            for idea, idea_seg in zip(r_obj.idea_list, r_obj.idea_seg_list):
                _, origin_brand = self.detector.detect(r_obj.userid,idea)
                pred_label, pred_confidence = self.inferer.check(idea_seg)
                if origin_brand is not None:
                    brand_detected_set.add(origin_brand)
                if pred_label == "2":
                    idea_high_risk_count += 1
                    idea_risk_evidence.append(idea)
            
            total_brand_detected_count = len(brand_detected_set)
            #total_brand_detected_ratio = (idea_brand_detected_count*keyword_num+keyword_brand_detected_count*idea_num-idea_brand_detected_count*keyword_brand_detected_count)/total_pair_num
            total_high_risk_ratio = (idea_high_risk_count*keyword_num+keyword_high_risk_count*idea_num-idea_high_risk_count*keyword_high_risk_count)/total_pair_num
            total_high_risk_count = idea_high_risk_count + keyword_high_risk_count
        
            
            if total_brand_detected_count < self.brand_num_threshold:
                check_info = u"���Ʒ����(%d)С��%d"%(total_brand_detected_count,self.brand_num_threshold)
                if total_high_risk_ratio < self.high_risk_ratio_threshold:
                    check_info += u",��ð�ٷ�����(%.2f)С��%.2f"%(total_high_risk_ratio,self.high_risk_ratio_threshold)
            
            if total_high_risk_ratio < self.high_risk_ratio_threshold:
                check_info = u"��ð�ٷ�����(%.2f)С��%.2f"%(total_high_risk_ratio,self.high_risk_ratio_threshold)
            
            if idea_high_risk_count == 0:
                label = "1"
                label_name = u"��Ԫ��΢��ð�ٷ�"
                check_info = u"�õ�Ԫ�з�ð�ٷ����գ��������޷�ð����"

            if check_info is None:
            # ������ ˵����⵽��Ʒ�������ڵ�����ֵ ��ð�ٷ��ı������ڵ�����ֵ �������з�ð����
                label = "2"
                label_name = u"��Ԫ���ط�ð�ٷ�"
                check_info = u"�õ�Ԫ�з�ð�ٷ�����"
            
            label_list = [[label,label_name,total_high_risk_ratio]]
            check_unit_result_obj.opt["high_risk_ratio"] = str(total_high_risk_ratio)
            check_unit_result_obj.opt["brand_detected"] = "\x01".join(brand_detected_set)
            check_unit_result_obj.opt["idea_risk_evidence"] = "\x01".join(idea_risk_evidence)
            check_unit_result_obj.opt["word_risk_evidence"] = "\x01".join(word_risk_evidence)
            
            break
            
        check_unit_result_obj.label_list = label_list
        check_unit_result_obj.label = label
        check_unit_result_obj.label_name = label_name
        check_unit_result_obj.opt["check_info"] = check_info
        return check_unit_result_obj.convert_to_dict()
    
    def load_user_set(self, user_tag_file):
        """����user_tag�ļ��е�userid,ֻ�������ڸ��ļ��е�userid
        """
        userid_set = set()
        with codecs.open(user_tag_file,"r","gb18030") as rf:
            for line in rf:
                userid_set.add(line.strip("\n").split("\t")[0])
        return userid_set


def test():
    """����
    """
    import os
    _cur_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.append("%s/../../" % _cur_dir)
    import word_seg
    import common.common as common
    stopword = common.Common.load_word_file("data/stopword.txt")
    segdict_path = "dict/chinese_gbk"
    word_segger = word_seg.WordSeg(segdict_path)
    word_segger.init_wordseg_handle()
    detector = FakeRepairUnitDetector()
    detector.init(
            word_segger=word_segger,
            stopword=stopword,
            model_dir="model/model_8_wxfm/")

    def gen_r_obj(userid, idea_list, word_list):
        """����review_object
        """
        r_obj = review_object.ReviewUnitObj()
        r_obj.userid = userid
        r_obj.word_list = word_list
        r_obj.word_seg_list = \
                [[x.decode("gb18030") for x in word_segger.seg_words(word.encode("gb18030"))] for word in word_list]
        r_obj.idea_list = idea_list
        r_obj.idea_seg_list = \
                [[x.decode("gb18030") for x in word_segger.seg_words(idea.encode("gb18030"))] for idea in idea_list]
        return r_obj

    userid = "20456629"
    word_list = [u"��ʫ����ȥ������", u"̫����", u"�ļ����", u"ƻ��"]
    idea_list = [u"�ŵ���ۺ�ά�޵�", u"�ŵ���ۺ�ά���������ߵ绰"]
    
    # �Ӱ��˻� ͨ��
    r_obj = gen_r_obj(userid, idea_list, word_list)
    check_res = detector.check(r_obj)
    print("label name : %s" % check_res["label_name"].encode("gb18030"))
    print("check info : %s" % check_res["opt"]["check_info"].encode("gb18030"))
    if "brand_detected" in check_res["opt"]:
        print("brand detected : %s" % check_res["opt"]["brand_detected"].encode("gb18030"))
    assert check_res["label_name"]==u"�޷���", "assert fail"

    # ά���˻������Ϸ�ð�ٷ� �ܾ�
    r_obj.userid = "29159091"
    check_res = detector.check(r_obj)
    print("label name : %s" % check_res["label_name"].encode("gb18030"))
    print("check info : %s" % check_res["opt"]["check_info"].encode("gb18030"))
    if "brand_detected" in check_res["opt"]:
        print("brand detected : %s" % check_res["opt"]["brand_detected"].encode("gb18030"))

    word_segger.destroy_wordseg_handle()

if __name__ == "__main__":
    test()
