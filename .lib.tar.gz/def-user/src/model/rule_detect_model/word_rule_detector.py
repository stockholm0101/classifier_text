#!/usr/bin/env python
# -*- coding: gbk -*-
 
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/08/14 15:06:01
DESC  :   def-user����ģ��
"""

import os
import sys
reload(sys)
sys.setdefaultencoding("gbk") 

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)
import review_object.review_object as review_object
import common.common as common
import common.rule_detector as rule_detector
import codecs


class RuleDetector(object):
    """���ڴ�ƥ��Ĺ���ģ��
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword: ͣ�ôʼ���
              model_dir: ģ��Ŀ¼
        [out] None
        """
        self.word_segger = word_segger
        self.stopword = stopword

        self.rule_path = os.path.join(model_dir, "rule_words")
        self.detector = rule_detector.RuleDetector(word_segger, \
            rule_path=self.rule_path)
        self.label_map_path = os.path.join(model_dir, "label_map.txt")
        self.label_map_dict = common.Common.load_class_id_file(self.label_map_path)

    def check(self, r_obj):
        """�����û��������
        [in]  r_obj: ��Ԥ�����
        [out] check_ad_result_obj: {
                "label": Ԥ���ǩ, 
                "lable_name": Ԥ���ǩ����, 
                "label_list": ��ϸԤ����[[label1, name, val], [...], ...],
                "opt": ������Ϣ}
        """
        
        check_ad_result_obj = review_object.CheckClickResultObj()

        # label Ĭ��ֵ0, ��ʾ������û�д����κι���
        label = "0"
        label_name = u"�޷���"
        label_list = []
        opt_info = {}
        check_ad_result_obj.init(label, label_name, label_list, opt_info)

        if r_obj.ad_type == "idea":
            return None

        text = r_obj.text.split(",")[0]
        rules = self.detector.check(r_obj.userid, text.decode("gb18030", "ignore"), shallow=False, is_debug=False)

        label_list = []
        if len(rules) > 0:
            for ruleObj in rules:
                label_id = ruleObj.rule_classes
                assert len(label_id) == 1, "a rule only belong to one of lables!"
                label = list(label_id)[0]
                label_list.append([label, self.label_map_dict[label], 1.0])
            check_ad_result_obj.label_list = label_list
            check_ad_result_obj.label = label
            check_ad_result_obj.label_name = self.label_map_dict[label]
            check_ad_result_obj.opt["risk_text"] = text

        return check_ad_result_obj.convert_to_dict()


if __name__ == "__main__":

    def test():
        """��Ԫ����
        """
        import conf
        import time

        segdict_path = "dict/chinese_gbk"
        stopword_file = "data/stopword.txt"
        import word_seg
        stopword = common.Common.load_word_file(stopword_file)
        word_segger = word_seg.WordSeg(segdict_path)
        word_segger.init_wordseg_handle()
        model_dir = "model/model_21_rule"
        ruleDetector = RuleDetector()
        ruleDetector.init(word_segger, stopword, model_dir)

        for eachline in sys.stdin:
            line = eachline.strip("\n").lower().decode("gbk", "ignore").split("\t")
            r_obj = None
            r_obj = review_object.ReviewClickAdObj()
            r_obj.init(line)

            # ��ʼʱ��
            start_time = time.time()
            check_result = ruleDetector.check(r_obj)
            end_time = time.time()
            print "use_time %.4f" % (end_time - start_time)
            print check_result
    test()
