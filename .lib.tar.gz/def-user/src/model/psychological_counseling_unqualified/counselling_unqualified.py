#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: counselling_unqualified.py
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2020/03/23 14:52:55
"""

import os
import sys
import re

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)
import review_object.review_object as review_object
import model.psychological_counseling.psychological_counsel as psychological_counsel

class CounselingUnqualifiedPredict(object):
    """��������������ѯģ��
    """
    def __init__(self):
        pass

    def init(self, word_segger, stopword, model_dir):
        """
        [in]:
            word_segger �д�
            stopword ͣ�ôʼ���
            model_dir : ģ���ļ�·����.
        [out]:
            None
        """
        self.base_couseling_model = psychological_counsel.PysCounselingPredict()
        self.base_couseling_model.init(word_segger, stopword, model_dir)

    def check(self, r_obj):
        """
        [in]:
            r_obj ��Ԥ��Ķ���
        [out]:
            check_result {"label": ģ�ͽ���ı�ǩ, 
                            "lable_name": ģ�ͽ���ı�ǩ��, 
                            "label_list": ��ϸԤ����[[label1, name, val], [...], ...]}
        """
        try:
            check_ad_result_obj = review_object.CheckAdResultObj()
            word_list = r_obj.text_seg_list
            word_list = self.base_couseling_model.pre_text_process(word_list)
            ngram_feature = self.base_couseling_model.get_ngram_list(word_list)
            detect_res = self.base_couseling_model.detect_psychological_counsel(ngram_feature)
            if detect_res is not None:
                check_ad_result_obj.label = detect_res[0]
                check_ad_result_obj.label_name = detect_res[1]
                check_ad_result_obj.label_list = detect_res[2]
                return check_ad_result_obj.convert_to_dict()
            return None
        except:
            return None
if __name__ == "__main__":
    pass
