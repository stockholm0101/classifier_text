#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/09/09 16:24:42
DESC  :   ��Ӫ��Χ��ǩ��
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")

import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import random
import re
import numpy as np

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import common.common as common
import review_object.review_object as review_object

#import paddle.fluid as fluid
#import paddle.v2 as paddle

class BusinessScopeLabel(object):
    """��Ӫ��Χ��ǩ����
    """
    def __init__(self):
        """init
        """
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        """
        model_file = os.path.join(model_dir, "business_scope_label.txt")
        class_id_file = os.path.join(model_dir, "class_id.txt")

        self.user_business_scope_label = common.Common.load_business_scope_label(model_file)
        self.class_dict = common.Common.load_class_id_file(class_id_file)

    def check(self, r_obj):
        """����, Ԥ��
        [in]  r_obj: ��Ԥ��Ķ���
        [out] check_result: {"label": ģ�ͽ���ı�ǩ, 
                             "lable_name": ģ�ͽ���ı�ǩ��, 
                             "label_list": ��ϸԤ����[[label1, name, val], [...], ...]}
        """
        check_user_result_obj = review_object.CheckUserResultObj()

        userid = r_obj.userid
        if userid not in self.user_business_scope_label:
            return check_user_result_obj.convert_to_dict()

        label = self.user_business_scope_label[userid]

        # ������ݿ����о�Ӫ��Χ������û�д����κα�ǩ������label="-10"
        if len(label) == 0:
            check_user_result_obj.label = "-10"
            return check_user_result_obj.convert_to_dict()

        label_id_list = label.split("|")
        label_name = "|".join([self.class_dict[id] for id in label_id_list])
        label_list = []
        for id in label_id_list:
            label_list.append([id, self.class_dict[id], "1.0"])

        check_user_result_obj.label = label
        check_user_result_obj.label_name = label_name
        check_user_result_obj.label_list = label_list

        return check_user_result_obj.convert_to_dict()


if __name__ == "__main__":
    pass

