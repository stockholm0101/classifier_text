#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   xuming06@baidu.com
Date  :   20/05/21 15:29:25
Desc  :   
"""
import sys
import os

import codecs
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)

import common.common as common
import common.rule_detector as rule_detector

class LpBrandRule(object):
    """���ҳ���������̱����
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """init"""
        # ���شʱ��ļ�
        brand_rule_file = os.path.join(model_dir, "brand_rule.txt")
        self.detector = rule_detector.RuleDetector(
                word_segger = word_segger,
                rule_path = brand_rule_file)
        # �����̱���-��˾��ӳ���
        brand_company_file = os.path.join(model_dir, "brand_compnay_cdc_map.txt")
        self.brand_company_map = self.load_brand_company_map(brand_company_file)

    def load_brand_company_map(self, map_file):
        """�����̱���-��˾��ӳ���
        """
        b_c_map = dict()
        with codecs.open(map_file, "r", "gb18030") as rf:
            for line in rf:
                line = line.strip()
                parts = line.split("\t")
                if len(parts) < 2:
                    continue
                b = parts[0]
                c = parts[1]
                if b not in b_c_map:
                    b_c_map[b] = [c]
                else:
                    temp = b_c_map[b]
                    temp.append(c)
                    b_c_map[b] = temp
        return b_c_map

    def check(self, r_obj):
        """check lp title text
        """
        key = ["title"]
        text_list = []
        for k in key:
            text_list.append(r_obj.feature_dict[k])
        text = " ".join(text_list)
        rules = self.detector.check("0", text, shallow=False)

        # 5:title
        rules_type = {"5": rules}

        labels = set()
        for k in rules_type:
            for rule in rules_type[k]:
                scope = rule.rule_scope
                # k: 5. title
                if k not in scope:
                    continue
                brand = rule.origin_rule
                comp = self.brand_company_map.get(brand, [])
                comp_str = "|".join(comp)
                labels.add(brand + '=' + comp_str)

        check_result = {}
        if len(labels) == 0:
            check_result["label"] = "-1"
            check_result["label_name"] = u"�޷���"
            check_result["label_list"] = []
            check_result["opt"] = {}
        else:
            check_result["label"] = "1"
            check_result["label_name"] = u"�����̱�����"
            check_result["label_list"] = [[x, "1", "1"] for x in labels]
            check_result["opt"] = {}
        return check_result


if __name__ == "__main__":
    pass
