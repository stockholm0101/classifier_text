#!/usr/bin/env python
# -*- coding: gbk -*-
 
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/08/14 15:06:01
DESC  :   def-user����ģ��
"""

import os
import sys
reload(sys)
sys.setdefaultencoding("gbk") 

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)
import review_object.review_object as review_object
import common.common as common
import common.rule_detector as rule_detector
import conf
import codecs


class RuleDetector(object):
    """���ڴ�ƥ��Ĺ���ģ��
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword: ͣ�ôʼ���
              model_dir: ģ��Ŀ¼
        [out] None
        """
        self.word_segger = word_segger
        self.stopword = stopword

        rule_path = os.path.join(model_dir, "rule_words")
        self.detector = rule_detector.RuleDetector(
                word_segger = word_segger, 
                rule_path = rule_path)

        class_id_file = os.path.join(model_dir, "label_map.txt")
        self.class_dict = common.Common.load_class_id_file(class_id_file)

    def check(self, r_obj):
        """�������еĹ����, Ԥ��label���ѡȡ, ���е����й��򱣴���label_list
        [in]  r_obj: ��Ԥ�����
        [out] check_ad_result_obj: {
                "label": Ԥ���ǩ, 
                "lable_name": Ԥ���ǩ����, 
                "label_list": ��ϸԤ����[[label1, name, val], [...], ...],
                "opt": ������Ϣ}
        """
        text = ""
        url = ""
        if r_obj.data_type in [conf.MODEL_TYPE_UNIT, conf.MODEL_TYPE_USER, \
                conf.MODEL_TYPE_CLICK_USER, conf.MODEL_TYPE_FEED_IDEA_UNIT, \
                conf.MODEL_TYPE_FEED_IDEA_USER]:
            text = ' '.join(r_obj.idea_list)
            url = " ".join(r_obj.idea_url_list)
        elif r_obj.data_type in [conf.MODEL_TYPE_FEED_USER]:
            text = ' '.join(r_obj.text_list)
            url = " ".join(r_obj.url_list)
        else:
            text = r_obj.text
            url = r_obj.url
        rules_text = self.detector.check(r_obj.userid, text, shallow = False)
        rules_url = self.detector.check(r_obj.userid, url, shallow = False)
        rules_type = {"1": rules_text, "2": rules_url}

        label = set()
        for k in rules_type:
            for rule in rules_type[k]:
                scope = rule.rule_scope
                # k: 1. �ؼ���/�������� 2. url����
                if k not in scope:
                    continue
                label |= rule.rule_classes

        label_list = []
        for l in label:
            label_list.append([l, self.class_dict[l], 1])

       
        check_ad_result_obj = review_object.CheckAdResultObj()
        if r_obj.data_type == conf.MODEL_TYPE_UNIT:
            check_ad_result_obj = review_object.CheckUnitResultObj()
        elif r_obj.data_type == conf.MODEL_TYPE_USER:
            check_ad_result_obj = review_object.CheckUserResultObj()
        elif r_obj.data_type == conf.MODEL_TYPE_CLICK_USER:
            check_ad_result_obj = review_object.CheckClickResultObj()
        elif r_obj.data_type == conf.MODEL_TYPE_FEED_USER:
            check_ad_result_obj = review_object.CheckFeedResultObj()
        
        # û������
        if len(label_list) == 0:
            return check_ad_result_obj.convert_to_dict() 

        check_ad_result_obj.label = "|".join([x[0] for x in label_list])
        check_ad_result_obj.label_name = "|".join([x[1] for x in label_list])
        check_ad_result_obj.label_list = label_list

        return check_ad_result_obj.convert_to_dict()


if __name__ == "__main__":
    pass
