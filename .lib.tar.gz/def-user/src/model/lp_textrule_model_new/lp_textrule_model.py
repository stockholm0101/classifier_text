#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   20/01/21 16:29:25
Desc  :   
"""
import sys
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)

import common.common as common
import common.rule_detector as rule_detector

class LpTextRule(object):
    """���ҳ�ı����еĹ���
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """init"""
        rule_file = os.path.join(model_dir, "rule.txt")
        label_map_file = os.path.join(model_dir, "label_map.txt")
        self.detector = rule_detector.RuleDetector(word_segger, rule_path=rule_file)
        self.detector_src = rule_detector.RuleDetector(word_segger, 
                punctuations=r",|;|\?",
                rule_path=rule_file)
        self.label_map_dict = common.Common.load_class_id_file(label_map_file)

    def check(self, r_obj):
        """check lp text
        """
        key = ["title", "navigation", "sem_central_content", "keywords", "abstract", "inner_links", "links"]
        text_list = []
        for k in key:
            text_list.append(r_obj.url_crawl_res["feature_dict"].get(k, ""))
        text = " ".join(text_list)
        rules = self.detector.check("0", text, shallow=False)
        src_rules = self.detector_src.check("0", r_obj.url_crawl_res["src"], shallow=False)

        rules_type = {"3": rules, "4": src_rules}

        label = set()
        for k in rules_type:
            for rule in rules_type[k]:
                scope = rule.rule_scope
                # k: 3. feature 4. src
                if k not in scope:
                    continue
                label |= rule.rule_classes

        label_list = []
        for l in label:
            label_list.append([l, self.label_map_dict[l], "1"])

        check_result = {}
        if len(label_list) == 0:
            check_result["label"] = "-1"
            check_result["label_name"] = u"�޷���"
            check_result["label_list"] = []
            check_result["opt"] = {}
        else:
            check_result["label"] = "|".join([x[0] for x in label_list])
            check_result["label_name"] = "|".join([x[1] for x in label_list])
            check_result["label_list"] = label_list
            check_result["opt"] = {}
        return check_result


if __name__ == "__main__":
    pass
