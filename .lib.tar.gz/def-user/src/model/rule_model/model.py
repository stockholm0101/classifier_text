#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   19/05/28 11:27:19
DESC  :   base_model, ֧��LR�����, ���ļ���ȡ��
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import random
import re
import numpy as np

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import common.common as common
import review_object.review_object as review_object
import word_seg
import conf


class Predicter(object):
    """Ԥ����, ��ʼ��ģ��, ����ģ��Ԥ��ӿ�
    """
    def __init__(self):
        """init"""
        pass

    def init(self, user_info_file, stopword_file, segdict_path, model_dir):
        """��ʼ��ģ��
        [in]  user_info_file: �û���Ϣ�ļ�
              stopword_file: ͣ�ô��ļ�
              segdict_path: �дʴʵ�
        [out] None
        """
        self.stopword = common.Common.load_word_file(stopword_file)
        self.word_segger = word_seg.WordSeg(segdict_path)
        self.word_segger.init_wordseg_handle()

        # import models
        self.m_obj = BaseModel()
        self.m_obj.init(self.word_segger, self.stopword, model_dir)

    def destroy(self):
        """
        �ͷ��д�
        """
        self.word_segger.destroy_wordseg_handle()


class BaseModel(object):
    """ʾ��ģ��, LR�����ģ��
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword: ͣ�ôʼ���
              model_dir: ģ��Ŀ¼
        [out] None
        """
        self.word_segger = word_segger
        self.stopword = stopword

        model_file = os.path.join(model_dir, "model.txt")
        feature_id_file = os.path.join(model_dir, "feature_id.txt")
        class_id_file = os.path.join(model_dir, "class_id.txt")

        self.model_dict, self.model_feature_num = common.Common.load_multiclass_lr_model_file(model_file)
        self.class_dict = common.Common.load_class_id_file(class_id_file)
        self.feature_dict = common.Common.load_feature_id_file(feature_id_file)
        self.feature_dict_keys = set(self.feature_dict.keys())

    def extract_text_ngram_feature(self, text_list):
        """��ȡngram feature, text_list��δ�д�
        [in]  text_list: ����ȡ���ı�, [text, text, ...]
        [out] ngram_feature: �д�ngram�����������
        """
        ngram_feature = set()
        for text in text_list:
            text_ngram = common.Common.ngram_feature_text(self.word_segger, text, self.stopword)
            ngram_feature |= text_ngram
        return ngram_feature

    def extract_seglist_ngram_feature(self, seg_list):
        """��ȡngram feature, seg_list�Ѿ��й���, ��Ҫ��ngram
        [in]  seg_list: [[��һ���ؼ��ʵ��д�list], [�ڶ���], ...]
        [out] ngram_feature: ngram�����������
        """
        ngram_feature = set()
        for seg in seg_list:
            text_ngram = common.Common.ngram_feature(seg, self.stopword)
            ngram_feature |= text_ngram
        return ngram_feature

    def check(self, risk_evidences):
        """����, Ԥ��
        [in]  risk_evidence: ��Ԥ��Ķ���  string
        [out] check_result:  Ԥ�������Ƿ�Υ�� boolean
        """
        check_result = False

        #####�Լ��дʽӿ�
        words = self.extract_text_ngram_feature(risk_evidences)
       # idea_ngram = self.extract_text_ngram_feature(r_obj.idea_list)
        ######
        #word_ngram = self.extract_seglist_ngram_feature(r_obj.word_seg_list)
        #idea_ngram = self.extract_seglist_ngram_feature(r_obj.idea_seg_list)
        #words = word_ngram | idea_ngram

        hit_feature = words & self.feature_dict_keys
        hit_feature_num = len(hit_feature)
        if hit_feature_num < 1:
            return check_result

        label_list = common.Common.cal_multiclass_lr_predict(self.model_dict, self.model_feature_num, \
                self.feature_dict, self.class_dict, hit_feature)

        if len(label_list) == 0:
            return check_result

        label = label_list[0][0]
        label_name = label_list[0][1]
        label_list = label_list

        if label == "1":
            check_result = True
        return check_result



if __name__ == "__main__":
    pass
