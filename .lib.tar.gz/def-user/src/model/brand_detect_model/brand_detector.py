#!/usr/bin/env python
# -*- coding: gbk -*-
 
"""
Author:   zhanghao55@baidu.com
Date  :   19/06/24 11:01:06
DESC  :   Ʒ��ʶ��ģ��
"""

import os
import sys
reload(sys)
sys.setdefaultencoding("gbk") 
import codecs

import disambiguation_model

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)
import review_object.review_object as review_object
import common.rule_detector as rule_detector


class BrandDetector(object):
    """ʶ���������ἰ��Ʒ��(�з��޹�ϵ���û���ʶ��)
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword: ͣ�ôʼ���
              model_dir: ģ��Ŀ¼
        [out] None
        """

        # ���شʱ��ļ�
        brand_rule_file = os.path.join(model_dir, "brand_rule.txt")
        self.detector = rule_detector.RuleDetector(
                word_segger = word_segger,
                rule_path = brand_rule_file)

        # ��������ģ��
        feature_weight_file = os.path.join(model_dir, "brand_infringement_feature_weight")
        rule_conf_file = os.path.join(model_dir, "brand_infringement_rule_conf")
        stopword_file = os.path.join(model_dir, "brand_infringement_stop_words.txt")
        self.disambiguation_model = disambiguation_model.DisambiguationModel(
                word_segger = word_segger,
                feature_weight_file = feature_weight_file,
                rule_conf_file = rule_conf_file,
                stopword_file = stopword_file)

    def check(self, r_obj):
        """��������е�Ʒ��
        [in]  r_obj: ��Ԥ�����
        [out] check_ad_result_obj: {
                "label": Ԥ���ǩ, 
                "lable_name": Ԥ���ǩ����, 
                "label_list": ��ϸԤ����[[label1, name, val], [...], ...],
                "opt": ������Ϣ}
        """
        
        check_ad_result_obj  = review_object.CheckAdResultObj()
        # ����������������е�Ʒ��
        res = self.detector.check(r_obj.userid, r_obj.text, shallow=False)

        # ������Ʒ����rule_classesΪ2�Ĺ�����ģ��
        brand_set = set()
        brand_info = dict()
        for rule in res:
            if "2" in rule.rule_classes:
                # �����������е����ƴ��滻Ϊ�����
                text = r_obj.text.replace(rule.riskword, rule.origin_rule)
                label, prob, evidence = self.disambiguation_model.check(text, rule.origin_rule)
                if label == "1":
                    #print(("model:[text = %s, rule = %s, prob = %.4f, evidence = %s]" % (r_obj.text, rule.riskword, prob, evidence)).encode("gb18030"))
                    if rule.riskword not in brand_set or prob > brand_info[rule.riskword]:
                        brand_set.add(rule.riskword)
                        brand_info[rule.riskword] = prob
            else:
                brand_set.add(rule.riskword)
                brand_info[rule.riskword] = 1.0

        # ���������û��Ʒ��
        if len(brand_set) == 0:
            return None
            #check_ad_result_obj.label = "0"
            #check_ad_result_obj.label_name = u"�޷���"
            #break

        # ��������д���Ʒ��
        check_ad_result_obj.label = "1"
        check_ad_result_obj.label_name = u"�漰Ʒ��"
        check_ad_result_obj.label_list = [[x[0], "1", "%.4f" % x[1]] for x in brand_info.items()]

        return check_ad_result_obj.convert_to_dict()
    

if __name__ == "__main__":
    import word_seg
    import conf
    segdict_path = "dict/chinese_gbk"
    word_segger = word_seg.WordSeg(segdict_path)
    word_segger.init_wordseg_handle()
    detector = BrandDetector()
    detector.init(word_segger, None, "model/model_13_brand_detect")

    def display_check_result(text, result):
        """չʾ�����
        """
        print(("rule:[text = %s, brand_list = [%s]]" % (text, \
                ",".join(["[%s,%s,%s]" % (x[0], x[1], x[2]) for x in result["label_list"]]))).encode("gb18030"))

    for line in sys.stdin:
        parts = line.strip("\n").lower().decode("gbk", "ignore").split("\t")
        r_obj = review_object.ReviewAdObj()
        r_obj.init(parts, conf.IDEA)
        check_result = detector.check(r_obj)
        if check_result is None:
            continue
        display_check_result(r_obj.text, check_result)

    word_segger.destroy_wordseg_handle()
