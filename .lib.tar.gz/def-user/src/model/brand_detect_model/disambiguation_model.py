#!/usr/bin/env python
# -*- coding: gbk -*-
 
"""
Author:   zhanghao55@baidu.com
Date  :   19/06/24 15:28:40
DESC  :   Ʒ������ģ��
"""

import os
import sys
reload(sys)
sys.setdefaultencoding("gbk") 
import codecs
import math


class DisambiguationModel(object):
    """Ʒ��������
    """
    def __init__(
            self,
            word_segger,
            feature_weight_file,
            rule_conf_file,
            stopword_file,
            evidence_num=5):
        self._feature_min_length = 1
        self._segger = word_segger
        self._feature_weight_dict = self.load_feature_weight(feature_weight_file)
        self._rule_conf = self.load_rule_conf(rule_conf_file)
        self._stopword_set = self.load_stopword_set(stopword_file)
        self._evidence_num = evidence_num

    def check(self, text, brand):
        """�������text�Ƿ����Ʒ��brand��Ȩ
        """
        label = "0"
        prob = 0
        evidence = ""
        while True:
            # ��ȡ��brand��Ӧ��ģ�Ͳ���
            if brand not in self._rule_conf:
                evidence = u"[rule = %s]rule not found in rule conf." % brand
                break
            try:
                n_gram, cover_length, confidence, prefix = self._rule_conf[brand]
                # ��������
                feature_list = self.gen_feature(text, brand, n_gram, cover_length, prefix)

                # Ԥ��
                feature_weight_sum = float(0)
                evidence_list = list()
                for feature in set(feature_list):
                    if feature in self._feature_weight_dict:
                        cur_feature_weight = self._feature_weight_dict[feature]
                        if cur_feature_weight != 0:
                            evidence_list.append((abs(cur_feature_weight), "%s(%.4f)" % (feature, cur_feature_weight)))
                        feature_weight_sum += cur_feature_weight
                prob = 1 / (1 + math.exp(-feature_weight_sum))
                label = "0" if prob < confidence else "1"
                evidence_sort_list = \
                        [x[1] for x in sorted(evidence_list, key=lambda x: x[0], reverse=True)[:self._evidence_num]]
                evidence = "||".join(evidence_sort_list)
            except Exception as e:
                label = "-1"
                evidence = str(e)
            # ѭ���������
            if True:
                break

        return label, prob, evidence

    def gen_feature(self, text, brand, n_gram, cover_length, prefix):
        """text brand ����unicode����
        """
        ngram_list = list()
        while True:
            if len(text) == 0:
                break
            text = text.lower() \
                    .replace(ur"{����}{Ͷ�ŵ���}", "") \
                    .replace(ur"{�ؼ���}", "") \
                    .replace(ur"{", "") \
                    .replace(ur"}", "")
            brand = brand.lower()
            content_zoomed_in = self.zoom_in_by_rule(text, brand, cover_length)
            #����������Ҳ�������������� ����
            if content_zoomed_in is None or len(content_zoomed_in) == 0:
                raise ValueError("[text = %s, rule = %s]rule not found in text" % (text, brand))
                break
            word_list = [x.decode("gb18030") for x in self._segger.seg_words(content_zoomed_in.encode("gb18030"))]
            #ȥ������
            word_list = self.filter_unvalid_word(word_list)
            if len(word_list) == 0:
                break
            #��Ҫ���������� �������㳤�ȵ�����
            ngram_list = self.gen_ngram(word_list, n_gram)
            if len(ngram_list) == 0:
                break
            #Ϊngram_list����ָ��ǰ׺
            ngram_list = [prefix + "_" + tmp for tmp in ngram_list]
            
            if True:
                break
        return ngram_list

    def gen_ngram(self, token_list, n_gram):
        """
        ����n-gram����
        """
        feature_list =  list()
        for index in range(len(token_list)):
            cur_feature = ""
            for offset in range(min(len(token_list)-index, n_gram)):
                cur_feature += token_list[index + offset]
                if len(cur_feature) > self._feature_min_length:
                    feature_list.append(cur_feature)
        return feature_list

    def zoom_in_by_rule(self, content, rule, cover_length):
        """
        �����й����������е�λ����չָ������(cover_length)���õ��������й��������Ƭ��
        Args:
        content: string
            ����
        rule: list[string]
            ���еĹ���,���������
        """
        rule_parts = rule.split(ur"|")
        assert len(rule_parts) < 3, "[rule = %s]rule has more than 2 parts." % rule
        location = self.locate_rule(content, rule_parts)
        res = None
        if location is not None:
            lower_bound, upper_bound = location
            lower_bound -= cover_length
            lower_bound = 0 if lower_bound < 0 else lower_bound
            upper_bound += cover_length
            res = content[lower_bound:upper_bound]
        return res

    def locate_single_rule(self, content, rule):
        """
        �ҳ������д��ڴ˹�������½�
        ���������޸ù������׳��쳣��
        ���쳣�ɵ��øú�����locate_rule��
        """
        lower_bound = content.index(rule)
        next_index = lower_bound
        upper_bound = next_index
        next_index = content.find(rule, next_index + 1)
        while next_index != -1:
            upper_bound = next_index
            next_index = content.find(rule, next_index + 1)
        upper_bound = upper_bound + len(rule)
        return (lower_bound, upper_bound)
    
    def locate_rule(self, content, rule_parts):
        """
        �������ڸù����κβ��ֵ��������½�
        ���½����º��Ͻ����ϵ����ϲ������������һ����
        ����:             0123456789
        ��Ϲ���:A|B ����:CCBCACCABC
        �������½�Ϊ[2,8]
        """
        upper_bound = -1
        lower_bound = len(content)
        for rule in rule_parts:
            try:
                cur_lower_bound, cur_upper_bound = self.locate_single_rule(content, rule)
            except ValueError as e:
                return None
            upper_bound = cur_upper_bound if cur_upper_bound > upper_bound else upper_bound
            lower_bound = cur_lower_bound if cur_lower_bound < lower_bound else lower_bound
        return (lower_bound, upper_bound)

    def filter_unvalid_word(self, token_list):
        """
        ȥ��������ķ���:
        1. ͣ�ôʱ�(self._stopword_set)�е��ַ�
        """
        new_token_list = list()
        for token in token_list:
            if token not in self._stopword_set:
                new_token_list.append(token)
        return new_token_list

    def load_stopword_set(self, stopword_file):
        """����ͣ�ôʱ�
        """
        stopword_set = set()
        with codecs.open(stopword_file, "r", "gb18030") as rf:
            for line in rf:
                content = line.strip("\n")
                stopword_set.add(content)
        return stopword_set

    def load_rule_conf(self, rule_conf_file):
        """���ع�������
        """
        rule_conf_dict = dict()
        with codecs.open(rule_conf_file, "r", "gb18030") as rf:
            for line_id, line in enumerate(rf):
                line = line.strip("\n")
                parts = line.split("\t")
                if len(parts) != 5:
                    raise ValueError("[file=%s, line=%d, text=%s]: wrong format. field number must be 5." \
                            % (rule_conf_file, line_id + 1, line))
                    continue
                brand = parts[0]
                n_gram = int(parts[1])
                cover_length = int(parts[2])
                confidence = float(parts[3])
                prefix = parts[4]
                if brand in rule_conf_dict:
                    raise ValueError(("[file=%s, line=%d, text=%s]: brand duplicate.\n" \
                            % (rule_conf_file, line_id + 1, line)).encode("gb18030"))
                    continue
                rule_conf_dict[brand] = (n_gram, cover_length, confidence, prefix)
        return rule_conf_dict

    def load_feature_weight(self, feature_weight_file):
        """��������Ȩֵ�ļ�
        """
        feature_weight_dict = dict()
        with codecs.open(feature_weight_file, "r", "gb18030") as rf:
            for line_id, line in enumerate(rf):
                #���Ե�һ��չʾ����
                if line_id == 0 and line.startswith("class"):
                    continue
                line = line.strip("\n")
                parts = line.split("\t")
                if len(parts) != 2:
                    raise ValueError("[file=%s, line=%d, text=%s]: wrong format. field number must be 2." \
                            % (feature_weight_file, line_id + 1, line))
                    continue
                feature = parts[0]
                if feature in feature_weight_dict:
                    raise ValueError(("[file=%s, line=%d, text=%s]: feature duplicate.\n" \
                            % (feature_weight_file, line_id + 1, line)).encode("gb18030"))
                    continue
                feature_weight_dict[feature] = float(parts[1])
        return feature_weight_dict
