#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/07/18 11:04:26
Desc  :   
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import random
import re
import numpy as np

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import common.common as common
import review_object.review_object as review_object


class ClickModel(object):
    """ʾ��ģ��, LR�����ģ��
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword: ͣ�ôʼ���
              model_dir: ģ��Ŀ¼
        [out] None
        """
        self.word_segger = word_segger
        self.stopword = stopword

        model_file = os.path.join(model_dir, "model.txt")
        feature_id_file = os.path.join(model_dir, "feature_id.txt")
        class_id_file = os.path.join(model_dir, "class_id.txt")

        self.model_dict, self.model_feature_num = common.Common.load_multiclass_lr_model_file(model_file)
        self.class_dict = common.Common.load_class_id_file(class_id_file)
        self.feature_dict = common.Common.load_feature_id_file(feature_id_file)
        self.feature_dict_keys = set(self.feature_dict.keys())
        self.class_thres = common.Common.load_class_thres(class_id_file)

    def extract_seg_ngram_feature(self, text_seg):
        """��ȡngram feature, text_seg�Ѿ��й���, ��Ҫ��ngram
        [in]  text_seg: word+idea text seg
        [out] ngram_feature: ngram�����������
        """
        ngram_feature = text_ngram = common.Common.ngram_feature(text_seg, self.stopword)
        return ngram_feature
    
    def check(self, r_obj):
        """����, Ԥ��
        [in]  r_obj: ��Ԥ��Ķ���
        [out] check_result: {"label": ģ�ͽ���ı�ǩ, 
                             "lable_name": ģ�ͽ���ı�ǩ��, 
                             "label_list": ��ϸԤ����[[label1, name, val], [...], ...]}
        """
        check_click_result_obj = review_object.CheckClickResultObj()
        ngram = self.extract_seg_ngram_feature(r_obj.text_seg)
        hit_feature = ngram & self.feature_dict_keys
        hit_feature_num = len(hit_feature)
        if hit_feature_num < 5:
            return check_click_result_obj.convert_to_dict()

        label_list = common.Common.cal_multiclass_lr_predict(self.model_dict, self.model_feature_num, \
                self.feature_dict, self.class_dict, hit_feature)

        if len(label_list) == 0:
            check_click_result_obj.label = "-10"
            return check_click_result_obj.convert_to_dict()

        check_click_result_obj.label = label_list[0][0]
        check_click_result_obj.label_name = label_list[0][1]
        check_click_result_obj.label_list = label_list

        if label_list[0][0] in self.class_thres and float(label_list[0][2]) < self.class_thres[label_list[0][0]]:
            check_click_result_obj.label = "0"
            check_click_result_obj.label_name = u'����'

        return check_click_result_obj.convert_to_dict()


if __name__ == "__main__":
    pass


