#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/07/25 11:37:41
Desc  :   �⽨����ģ��Ԥ��
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")

import random
import re
import numpy as np

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import common.common as common
import review_object.review_object as review_object


class ClickModel(object):
    """ʾ��ģ��, LR�����ģ��
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword: ͣ�ôʼ���
              model_dir: ģ��Ŀ¼
        [out] None
        """
        self.word_segger = word_segger
        self.stopword = stopword

        model_file2 = os.path.join(model_dir, "model2.txt")
        feature_id_file2 = os.path.join(model_dir, "feature_id2.txt")
        class_id_file2 = os.path.join(model_dir, "class_id2.txt")

        model_file7 = os.path.join(model_dir, "model7.txt")
        feature_id_file7 = os.path.join(model_dir, "feature_id7.txt")
        class_id_file7 = os.path.join(model_dir, "class_id7.txt")

        self.model_dict2, self.model_feature_num2 = common.Common.load_multiclass_lr_model_file(model_file2)
        self.class_dict2 = common.Common.load_class_id_file(class_id_file2)
        self.feature_dict2 = common.Common.load_feature_id_file(feature_id_file2)
        self.feature_dict_keys2 = set(self.feature_dict2.keys())

        self.model_dict7, self.model_feature_num7 = common.Common.load_multiclass_lr_model_file(model_file7)
        self.class_dict7 = common.Common.load_class_id_file(class_id_file7)
        self.feature_dict7 = common.Common.load_feature_id_file(feature_id_file7)
        self.feature_dict_keys7 = set(self.feature_dict7.keys())

    def extract_seg_ngram_feature(self, text_seg):
        """��ȡngram feature, text_seg�Ѿ��й���, ��Ҫ��ngram
        [in]  text_seg: word+idea text seg
        [out] ngram_feature: ngram�����������
        """
        ngram_feature = text_ngram = common.Common.ngram_feature(text_seg, self.stopword)
        return ngram_feature

    def check(self, r_obj):
        """����, Ԥ��
        [in]  r_obj: ��Ԥ��Ķ���
        [out] check_result: {"label": ģ�ͽ���ı�ǩ, 
                             "lable_name": ģ�ͽ���ı�ǩ��, 
                             "label_list": ��ϸԤ����[[label1, name, val], [...], ...]}
        """
        check_click_result_obj = review_object.CheckClickResultObj()
        ngram = self.extract_seg_ngram_feature(r_obj.text_seg)
        # ��һ������
        hit_feature = ngram & self.feature_dict_keys2
        hit_feature_num = len(hit_feature)
        if hit_feature_num < 5:
            return check_click_result_obj.convert_to_dict()
        label_list = common.Common.cal_multiclass_lr_predict(self.model_dict2, self.model_feature_num2, \
                self.feature_dict2, self.class_dict2, hit_feature)
        if len(label_list) == 0:
            check_click_result_obj.label = "-10"
            return check_click_result_obj.convert_to_dict()
        if label_list[0][0] == "0" or float(label_list[0][2]) < 0.7:
            check_click_result_obj.label = "-1"
            check_click_result_obj.label_name = label_list[0][1]
            check_click_result_obj.label_list = [["-1", label_list[0][1], label_list[0][2]]]
            return check_click_result_obj.convert_to_dict()

        # �ڶ������࣬�Ѿ�ȷ��Ϊ�⽨����
        hit_feature = ngram & self.feature_dict_keys7
        hit_feature_num = len(hit_feature)
        if hit_feature_num < 5:
            return check_click_result_obj.convert_to_dict()
        label_list = common.Common.cal_multiclass_lr_predict(self.model_dict7, self.model_feature_num7, \
                self.feature_dict7, self.class_dict7, hit_feature)
        if len(label_list) == 0:
            check_click_result_obj.label = "-10"
            return check_click_result_obj.convert_to_dict()

        check_click_result_obj.label = label_list[0][0]
        check_click_result_obj.label_name = label_list[0][1]
        check_click_result_obj.label_list = label_list

        return check_click_result_obj.convert_to_dict()


if __name__ == "__main__":
    pass


