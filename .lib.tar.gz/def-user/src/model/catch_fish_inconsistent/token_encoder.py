#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/04/04 16:43:41
Desc  :   
"""

import sys
from utils import read_from_file
import logging


class TokenEncoder(object):
    """���ʡ�IDת����
    """
    def __init__(self, token_id, is_file=False, oov='<unk>', encoding="gb18030"):
        """
        ��ʼ��token��id��ӳ��
        :param token_id:
        :param if_file: bool, True����ļ��м���token_id
        :param oov: δ��¼��, ����ֻ��ָ��oov����һ��, ��Ҫ��ѵ��������ʱ�и�oov,
        """
        self.token_id = TokenEncoder.load_token_id (token_id, encoding) if is_file else token_id
        assert ' ' not in self.token_id, "token ' ' should not be used, it's reserved for padding"
        assert 0 not in self.token_id.values(), "token_id 0 should not be used, it's reserved for padding"
        self.token_id[' '] = 0
        self.oov_id = self.token_id[' ']
        if oov is not None:
            assert oov in self.token_id, "oov('{}') not in token, it should exist when training word2vec".format(oov)
            self.oov_id = self.token_id[oov]
        self.id_token = {v: k for k, v in self.token_id.items()}
        self.vocab_size = len(self.token_id)

    @staticmethod
    def load_token_id(file_path, encoding):
        """
        ���ļ�����token_id
        :param file_path: str, �ļ���ַ
        :return: token_id_dict: dict[str]=int, �ʻ��ֵ�
        """
        cover_set = set()
        def token_id_processor(line):
            """���ı�����ȡtoken��idӳ���ϵ
            """
            parts = line.strip("\n").split("\t")
            try:
                token = parts[0]
                token_id = int(parts[1])
                if token in cover_set:
                    logging.warning("duplicate: %s" % token.encode("utf-8"))
                cover_set.add(token)
                return token, token_id
            except Exception as e:
                return None

        import time
        start_time = time.time()
        logging.debug("load token id dict from file {}".format(file_path))
        token_id_dict = dict(read_from_file(file_path, read_func=token_id_processor, encoding=encoding))
        logging.debug("load time = {}s, vocab size = {}".format(time.time() - start_time, len(token_id_dict)))
        return token_id_dict

    def transform(self, token):
        """tokenתID
        """
        return self.token_id[token] if token in self.token_id else self.oov_id

    def inverse_transform(self, token_id):
        """IDתtoken
        """
        return self.id_token[token_id]

    def __len__(self):
        """�ֵ��С
        """
        return len(self.token_id)

    def tokenizer(self, text):
        """�д�����תID����
        """
        # ���ڶ�������Ŀո� split()ֻ�ָ�һ�� split(" ")��ÿ���ո�ָ�һ��
        return [self.transform(word) for word in text.split()]

if __name__ == "__main__":
    pass
