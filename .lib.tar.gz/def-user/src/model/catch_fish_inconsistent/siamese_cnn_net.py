#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/04/03 11:44:14
Desc  :   ����CNN��������
"""

import paddle.fluid as fluid
import paddle.fluid.param_attr as attr


class SiameseCNN(object):
    """����CNN����
    """
    def __init__(self, conf_dict):
        """��ʼ��
        [in]  conf_dict: dict, �����ֵ�
        [out] None
        [author] zhanghao55
        """
        self.vocab_size = conf_dict["vocab_size"]
        self.task_mode = conf_dict["task_mode"]
        self.emb_size = conf_dict["net"]["emb_size"]
        self.filter_size = conf_dict["net"]["filter_size"]
        self.num_filters = conf_dict["net"]["num_filters"]
        self.hidden_num = conf_dict["net"]["hidden_num"]

    def predict(self, left, right):
        """ǰ���������
        [in]  left: �����벻��������, size=[batch_size, None]
              right: �����벻��������, size=[batch_size, None]
        [out] left_feat: ���������������
              pred: ����Լ���ֵ
        [author] zhanghao55
        """
        # embedding layer
        emb_layer = EmbeddingLayer(self.vocab_size, self.emb_size, "emb")
        left_emb = emb_layer.ops(left)
        right_emb = emb_layer.ops(right)

        # Presentation context
        cnn_layer = SequenceConvPoolLayer(
                self.filter_size, self.num_filters, "conv")
        left_cnn = cnn_layer.ops(left_emb)
        right_cnn = cnn_layer.ops(right_emb)

        # matching layer
        if self.task_mode == "pairwise":
            fc_layer = FCLayer(self.hidden_num, None, "fc")
            left_fc = fc_layer.ops(left_cnn)
            right_fc = fc_layer.ops(right_cnn)
            cos_sim_layer = CosSimLayer()
            pred = cos_sim_layer.ops(left_fc, right_fc)
            # pairwiseʱ ����ľ�������� һ��
            return left_fc, pred
        else:
            concat_layer = ConcatLayer(1)
            concat = concat_layer.ops([left_cnn, right_cnn])
            fc_layer = FCLayer(self.hidden_num, None, "fc")
            concat_fc = fc_layer.ops(concat)
            softmax_layer = FCLayer(2, "softmax", "cos_sim")
            pred = softmax_layer.ops(concat_fc)
            # pointwiseʱ �����ʱ�����softmax���� ����
            return left_cnn, pred


class EmbeddingLayer(object):
    """��������
    """
    def __init__(self, dict_size, emb_dim, name="emb"):
        """��ʼ��
        """
        self.dict_size = dict_size
        self.emb_dim = emb_dim
        self.name = name

    def ops(self, input):
        """����
        """
        emb = fluid.embedding(
            input=input,
            size=[self.dict_size, self.emb_dim],
            is_sparse=True,
            param_attr=attr.ParamAttr(name=self.name))
        return emb


class SequenceConvPoolLayer(object):
    """SequenceConvPoolLayer��
    """
    def __init__(self, filter_size, num_filters, name):
        """��ʼ��
        [in] filter_size: ��������С
             num_filters: ����������
             name: ����
        """
        self.filter_size = filter_size
        self.num_filters = num_filters
        self.name = name

    def ops(self, input):
        """����
        """
        conv = fluid.nets.sequence_conv_pool(
            input=input,
            filter_size=self.filter_size,
            num_filters=self.num_filters,
            param_attr=attr.ParamAttr(name=self.name),
            act="relu")
        return conv


class FCLayer(object):
    """FC��
    """
    def __init__(self, fc_dim, act, name="fc"):
        """��ʼ��
        [in] fc_dim: ��Ԫ��
             act: �����
             name: ����
        """
        self.fc_dim = fc_dim
        self.act = act
        self.name = name

    def ops(self, input):
        """����
        """
        fc = fluid.layers.fc(input=input,
                             size=self.fc_dim,
                             param_attr=attr.ParamAttr(name="%s.w" % self.name),
                             bias_attr=attr.ParamAttr(name="%s.b" % self.name),
                             act=self.act,
                             name=self.name)
        return fc


class CosSimLayer(object):
    """CosSimLayer��
    """
    def __init__(self):
        """��ʼ��
        """
        pass

    def ops(self, x, y):
        """����
        """
        sim = fluid.layers.cos_sim(x, y)
        return sim


class ConcatLayer(object):
    """ConcatLayer��
    """
    def __init__(self, axis):
        """��ʼ��
        """
        self.axis = axis

    def ops(self, inputs):
        """����
        """
        concat = fluid.layers.concat(inputs, axis=self.axis)
        return concat


if __name__ == "__main__":
    pass
