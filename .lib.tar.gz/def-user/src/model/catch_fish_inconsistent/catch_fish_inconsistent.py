#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/05/14 15:25:19
Desc  :   
"""

#import json
import os
import sys
import codecs
import numpy as np

from siamese_cnn_model import SiameseCNNModel
from utils import get_config

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)
import review_object.review_object as review_object


class CatchFishInconsistent(object):
    """�������ϡ�ע��ҳ��һ��ʶ��
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword: ͣ�ôʼ���
              model_dir: ģ��Ŀ¼
        [out] None
        """
        self.word_segger = word_segger
        self.conf_dict = get_config(os.path.join(model_dir, "conf.json"))
        self.url_type_scope_dict = {k: set(v) for k, v in self.conf_dict["monitor_scope"].items()}
        self.send_id_scope_set = set(self.url_type_scope_dict.keys())
        #print("send_id_scope: {}".format(self.send_id_scope_set))
        #print("url_type_scope: {}".format(self.url_type_scope_dict))
        self.matching_model = SiameseCNNModel(
                model_dir=os.path.join(model_dir, "model_ckpt"),
                vocab_path=os.path.join(model_dir, "vocab.txt"),
                conf_dict=self.conf_dict,
                )
        # siameseģ�͵ı�ǩ��ʵ��ҵ���ǩ��ӳ��
        self.model_label_dict = {
                0: ("1", u"�������ϡ�ע��ҳ��һ��"),
                1: ("0", u"�������ϡ�ע��ҳһ��"),
                }

    def check(self, r_obj):
        """��������е�Ʒ��
        [in]  r_obj: ��Ԥ�����
        [out] check_ad_result_obj: {
                "label": Ԥ���ǩ, 
                "lable_name": Ԥ���ǩ����, 
                "label_list": ��ϸԤ����[[label1, name, val], [...], ...],
                "opt": ������Ϣ}
        """

        check_url_result_obj  = review_object.CheckUrlResultObj()

        #print("process url: %s" % r_obj.url)
        #print("process obj:")
        #print(json.dumps(r_obj.review_result()))

        send_ids = set(r_obj.send_dict.keys())
        type_set = set(r_obj.type_list)
        #print("send ids: {}".format(send_ids))
        #print("url types: {}".format(type_set))
        # ���ݼ�ط�Χʶ���˻�
        # ������ָ��send_id��Χ
        match_send_id_set = send_ids & self.send_id_scope_set
        if len(match_send_id_set) == 0:
            return None

        # ������ָ��url����
        url_type_scope_set = set()
        for send_id in match_send_id_set:
            #print("match send id: {}".format(send_id))
            url_type_scope_set |= self.url_type_scope_dict[send_id]
        match_url_type_set = type_set & url_type_scope_set
        if len(match_url_type_set) == 0:
            return None

        # print("in scope")

        if r_obj.url_crawl_res["feature_seg_dict"] is None:
            return check_url_result_obj.convert_to_dict()

        # ���������Ϻ�URL����
        url_feature_list = list()
        for _, seg_list in r_obj.url_crawl_res["feature_seg_dict"].items():
            url_feature_list.extend(seg_list)

        url_text = " ".join(url_feature_list)

        evidence_text_list = list()

        # �ؼ���
        for label_id in self.send_id_scope_set:
            cur_evidence_word_list = r_obj.send_dict.get(label_id, dict())\
                    .get("evidence_content", dict()).get("word", list())
            evidence_text_list.extend(cur_evidence_word_list)

        # ����
        for label_id in self.send_id_scope_set:
            cur_evidence_idea_list = r_obj.send_dict.get(label_id, dict())\
                    .get("evidence_content", dict()).get("idea", list())
            evidence_text_list.extend(cur_evidence_idea_list)

        ad_text = ",".join(evidence_text_list).encode("gb18030")

        ad_seg_text = [x.decode("gb18030") for x in self.word_segger.seg_words(ad_text)]

        ad_text = " ".join(ad_seg_text)

        pred_res = self.matching_model.pred(ad_text, url_text)

        if pred_res is not None:
            label_list = list()
            for pred_label, confidence in enumerate(pred_res):
                cur_label, cur_label_name = self.model_label_dict[pred_label]
                label_list.append((confidence, [cur_label, cur_label_name, str(confidence)]))

            label_list = [x[1] for x in sorted(label_list, key=lambda x:x[0], reverse=True)]

            check_url_result_obj.label = label_list[0][0]
            check_url_result_obj.label_name = label_list[0][1]
            check_url_result_obj.label_list = label_list
            if check_url_result_obj.label != "0":
                check_url_result_obj.opt = {
                        "ad_text": evidence_text_list[-5:],
                        "url_text": r_obj.url_crawl_res["feature_dict"].values(),
                        "url": r_obj.url,
                        }
            #print(check_url_result_obj.label_name.encode("gb18030"))

        return check_url_result_obj.convert_to_dict()


if __name__ == "__main__":
    pass
    #import word_seg
    #import conf
    #segdict_path = "dict/chinese_gbk"
    #word_segger = word_seg.WordSeg(segdict_path)
    #word_segger.init_wordseg_handle()
    #detector = BrandDetector()
    #detector.init(word_segger, None, "model/model_13_brand_detect")

    #for line in sys.stdin:
    #    parts = line.strip("\n").lower().decode("gbk", "ignore").split("\t")
    #    r_obj = review_object.ReviewAdObj()
    #    r_obj.init(parts, conf.IDEA)
    #    check_result = detector.check(r_obj)
    #    if check_result is None:
    #        continue
    #    display_check_result(r_obj.text, check_result)

    #word_segger.destroy_wordseg_handle()
