#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/04/03 11:53:32
"""

import codecs
import json
import numpy as np
import os
import paddle.fluid as fluid
import sys


def get_config(config_path):
    """
    �����������ò���
    [in]  config_path: �����ļ���ַ
    [out] config_dict: �����ֵ�
    [author] zhanghao55
    """
    with codecs.open(config_path, "r") as json_file:
        config_dict = json.load(json_file)
    return config_dict


def import_class(module_path, module_name, class_name):
    """
    Load class dynamically
    Args:
      module_path: The current path of the module
      module_name: The module name
      class_name: The name of class in the import module
    Return:
      Return the attribute value of the class object
    """
    if module_path:
        sys.path.append(module_path)
    module = __import__(module_name, fromlist = ['default'])
    return getattr(module, class_name)


def read_from_file(file_path, read_func=lambda x:x, encoding="gb18030"):
    """�����ļ��еĴ�
    [in] file_path: str, �ļ���ַ
    [out] word_list: generator(str), �����б�
    """
    with codecs.open(file_path, "r", encoding) as rf:
        for line in rf:
            read_line = read_func(line.strip("\n"))
            if read_line is None:
                continue
            yield read_line


def init_checkpoint(exe, init_checkpoint_path, main_program):
    """�����ʼ��
    """
    assert os.path.exists(
        init_checkpoint_path), "[%s] cann't be found." % init_checkpoint_path

    def existed_persitables(var):
        """�ж��Ƿ�־û�
        """
        if not fluid.io.is_persistable(var):
            return False
        return os.path.exists(os.path.join(init_checkpoint_path, var.name))

    fluid.io.load_vars(
        exe,
        init_checkpoint_path,
        main_program=main_program,
        predicate=existed_persitables)


def lodtensor_to_list(lod_tensor):
    """2άlodtensorתlist
    [in]  lod_tensor: LoDTensor������
    [out] res: list����ά����
    [author] zhanghao55
    """
    # ��ȡ LoD-Tensor �� lod ��Ϣ
    lod_ind_list = lod_tensor.lod()[0]
    # ת���� array
    lod_array = np.array(lod_tensor)
    res = list()
    # ����ԭLoD-Tensor�Ĳ㼶��Ϣ��ת����Tensor
    for ind_pos in range(1, len(lod_ind_list)):
        res.append(lod_array[lod_ind_list[ind_pos - 1]:lod_ind_list[ind_pos]])
    return res


def check_version():
    """
    Log error and exit when the installed version of paddlepaddle is
    not satisfied.
    """
    err = "PaddlePaddle version 1.6 or higher is required, " \
        "or a suitable develop version is satisfied as well. \n" \
        "Please make sure the version is good with your code." \

    try:
        fluid.require_version('1.6.0')
    except Exception as e:
        sys.stderr.write(err + "\n")
        sys.exit(1)

def check_cuda(use_cuda, err="\nYou can not set use_cuda = True in the model " \
        "because you are using paddlepaddle-cpu.\n " \
        "Please: 1. Install paddlepaddle-gpu to run your models on GPU or " \
        "2. Set use_cuda = False to run models on CPU.\n"):
    """
    Log error and exit when set use_gpu=true in paddlepaddle
    cpu version.
    """
    try:
        if use_cuda == True and fluid.is_compiled_with_cuda() == False:
            sys.stderr.write(err + "\n")
            sys.exit(1)
    except Exception as e:
        pass
