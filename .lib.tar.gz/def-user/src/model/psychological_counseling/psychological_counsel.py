#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: psychological_counsel.py
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2020/03/02 19:04:41
"""
import os
import sys
import re
reload(sys)
sys.setdefaultencoding("gbk") 

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)
import review_object.review_object as review_object
import common.xgboost_model_tool as xgboost_model_tool

class PysCounselingPredict(object):
    """��������������ѯģ��
    """
    def __init__(self):
        pass

    def init(self, word_segger, stopword, model_dir):
        """
        [in]:
            word_segger �д�
            stopword ͣ�ôʼ���
            model_dir : ģ���ļ�·����.
        [out]:
            None
        """
        #binary_model_conf.txt ������ģ����ֵ�������
        self.binary_model_conf_path = os.path.join(model_dir, "binary_model_conf.txt") 
        
        #binary_model.txt ������ģ���ļ�,�ж��Ƿ���������ѯ
        self.binary_model_path = os.path.join(model_dir, "binary_model.txt") 
        
        #binary_model_feature.txt ������ģ�������ʼ�ID
        self.binary_model_feature_path = os.path.join(model_dir, "binary_model_feature.txt")

        #mult_model_conf.txt �����ģ����ֵ�������
        self.mult_model_conf_path = os.path.join(model_dir, "mult_model_conf.txt")
        
        #mult_model.txt �����ģ���ļ�,�ж�����һ��������ѯ
        self.mult_model_path = os.path.join(model_dir, "mult_model.txt")
        
        #mult_model_feature.txt �����ģ�������ʼ�ID
        self.mult_model_feature_path = os.path.join(model_dir, "mult_model_feature.txt")
        
        #stopword.txt ͣ�ô�
        self.stopword_path = os.path.join(model_dir, "stopword.txt")
        
        self.key_word_path = os.path.join(model_dir, "keyword.txt") #��Ч˵��Υ���
        self.key_word_dict = self.load_key_word(self.key_word_path)
        self.binary_conf = self.load_model_conf(self.binary_model_conf_path)
        self.mult_conf = self.load_model_conf(self.mult_model_conf_path)
        self.load_stop_word(self.stopword_path)
       
        #class_nums ģ�ͷּ��� 
        mult_class_num = int(self.mult_conf["class_nums"][0])
        #iter_num ģ��ѵ���˼���
        mult_iter_num = int(self.mult_conf["iter_num"][0])
        self.mult_model = xgboost_model_tool.load_predcit(self.mult_model_path, 
                self.mult_model_feature_path, mult_class_num, mult_iter_num)

        binary_class_num = int(self.binary_conf["class_nums"][0])
        binary_iter_num = int(self.binary_conf["iter_num"][0])
        self.binary_model = xgboost_model_tool.load_predcit(self.binary_model_path, 
                self.binary_model_feature_path, binary_class_num, binary_iter_num)

    def load_model_conf(self, conf_path):
        """����ģ������
        [in]:
            conf_path �����ļ�
        [out]:
            tmp_dict ����
        """
        tmp_dict = {}
        with open(conf_path) as f:
            for line in f:
                one = line.strip("\n").decode("gbk").split("\t")
                tmp_dict[one[0]] = one[1:]
        return tmp_dict
    
    def load_stop_word(self, stopword_file_name_path):
        """����ͣ�ô�
        [in]:
            stopword_file_name_path ͣ�ô��ļ�
        [out]:
            None
        """
        self.stopword_dict = {}
        with open(stopword_file_name_path, 'r') as f:
            for line in f:
                line = line.strip("\n").decode("gbk")
                word = line.split("\t")[0]
                if word:
                    self.stopword_dict[word] = " "
    
    def load_key_word(self, keyword_file_path):
        """����Υ�������
        [in]:
            keyword_file_path Υ����ļ�
        [out]:
            None
        """
        tmp_dict = {}
        with open(keyword_file_path, 'r') as f:
            for line in f:
                line = line.strip("\n").decode("gbk")
                one = line.split("\t")
                word = one[0]
                if word:
                    tmp_dict[word] = [int(one[1]), word]
        return tmp_dict
    
    def detect_keyword(self, ngram_feature):
        """Υ��ʼ��
        [in]:
            ngram ����
        [out]:
            ���ɹ���label:Υ���ID��label_name:Υ������档
            ���ʧ�ܣ�None
        """
        hit_key = []
        for nf in ngram_feature:
            id_word = self.key_word_dict.get(nf, None)
            if id_word is not None:
                hit_key.append(id_word)
            
        if not hit_key:
            return None
        hit_key = sorted(hit_key, key=lambda x: x[0])
        label = hit_key[0][0]
        label_name = hit_key[0][1]
        return (label, label_name)

    def get_ngram_list(self, words_list):
        """����ngram����
        [in]:
            words_list �ִʺ���б�
        [out]:
            words ngram����
        """
        w_1gram = words_list
        w_2gram = [ w_1gram[i] + w_1gram[i + 1] for i in range(0, len(w_1gram) - 1) ]
        w_3gram = [ w_1gram[i] + w_1gram[i + 1] + w_1gram[i + 2] for i in range(0, len(w_1gram) - 2)]
        words = w_1gram + w_2gram + w_3gram
        return words
    
    def pre_text_process(self, word_list):
        """�ı�Ԥ����
        [in]:
            word_list �ִʺ���б�
        [out]:
            tmp_list ���˺�Ĵ��б�
        """
        rule = re.compile(ur"[^\u4e00-\u9fa5]")
        tmp_list = []
        for word in word_list:
            if self.stopword_dict.get(word, None) is None:
                tmp_list.append(rule.sub("", word))
        return tmp_list
    
    def detect_psychological_counsel(self, ngram_feature):
        """������ѯʶ��
        [in]:
            ngram ����
        [out]:
            ��������ѯ��label��label_name��label_list
            ��������ѯ��None
        """
        binary_feature = self.binary_model.get_sentence_vec(ngram_feature)
        binary_rate = self.binary_model.xgboost_predict(binary_feature)[0]
        ere = 0.000000001
        if binary_rate - float(self.binary_conf["rate"][0]) > ere:
            mult_feature = self.mult_model.get_sentence_vec(ngram_feature)
            mult_rate = self.mult_model.xgboost_predict(mult_feature)
            label = mult_rate.argmax()
            label_name = self.mult_conf[str(label)][1]

            if mult_rate[label] - float(self.mult_conf[str(label)][0]) < ere:
                return None
            label_list = []
            for site in range(len(mult_rate)):
                label_list.append([str(site), self.mult_conf[str(site)][1], str(mult_rate[site])])
            return (str(label), label_name, label_list)
        return None

    def check(self, r_obj):
        """
        [in]:
            r_obj ��Ԥ��Ķ���
        [out]:
            check_result {"label": ģ�ͽ���ı�ǩ, 
                            "lable_name": ģ�ͽ���ı�ǩ��, 
                            "label_list": ��ϸԤ����[[label1, name, val], [...], ...]}
        """
        try:
            check_ad_result_obj = review_object.CheckAdResultObj()
            word_list = r_obj.text_seg_list
            word_list = self.pre_text_process(word_list)
            ngram_feature = self.get_ngram_list(word_list)
            #print "\t".join(ngram_feature).encode("gbk")
            detect_psy_counsel_res = self.detect_psychological_counsel(ngram_feature)
            keyword_detect_res = self.detect_keyword(ngram_feature)
            if detect_psy_counsel_res is not None and keyword_detect_res is not None:
                check_ad_result_obj.label = detect_psy_counsel_res[0]
                check_ad_result_obj.label_name = detect_psy_counsel_res[1]
                check_ad_result_obj.label_list = detect_psy_counsel_res[2]
                return check_ad_result_obj.convert_to_dict()
            return None
        except:
            return None
if __name__ == "__main__":
    pass
