#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   19/03/20 22:22:19
DESC  :   base_model, Common, ֧��LR�����, ���ļ���ȡ��
"""
import os
import sys
import random
import re
import numpy as np
import conf

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import common.common as common
import review_object.review_object as review_object

import paddle.fluid as fluid


class BaseModel(object):
    """ʾ��ģ��, LR�����ģ��
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword: ͣ�ôʼ���
              model_dir: ģ��Ŀ¼
        [out] None
        """
        self.word_segger = word_segger
        self.stopword = stopword

        model_file = os.path.join(model_dir, "model.txt")
        feature_id_file = os.path.join(model_dir, "feature_id.txt")
        class_id_file = os.path.join(model_dir, "class_id.txt")

        self.model_dict, self.model_feature_num = common.Common.load_multiclass_lr_model_file(model_file)
        self.class_dict = common.Common.load_class_id_file(class_id_file)
        self.feature_dict = common.Common.load_feature_id_file(feature_id_file)
        self.feature_dict_keys = set(self.feature_dict.keys())
        self.class_thres = common.Common.load_class_thres(class_id_file)
        self.null_label_set = set(["-100", "-10", "0"])

    def extract_text_ngram_feature(self, text_list):
        """��ȡngram feature, text_list��δ�д�
        [in]  text_list: ����ȡ���ı�, [text, text, ...]
        [out] ngram_feature: �д�ngram�����������
        """
        ngram_feature = set()
        for text in text_list:
            text_ngram = common.Common.ngram_feature_text(self.word_segger, text, self.stopword)
            ngram_feature |= text_ngram
        return ngram_feature

    def extract_seglist_ngram_feature(self, seg_list):
        """��ȡngram feature, seg_list�Ѿ��й���, ��Ҫ��ngram
        [in]  seg_list: [[��һ���ؼ��ʵ��д�list], [�ڶ���], ...]
        [out] ngram_feature: ngram�����������
        """
        ngram_feature = set()
        for seg in seg_list:
            text_ngram = common.Common.ngram_feature(seg, self.stopword)
            ngram_feature |= text_ngram
        return ngram_feature

    def get_features(self, r_obj):
        """����r_obj���������б�
        [in]  r_obj: ��Ԥ��Ķ���
        [out] features: set(str), ��������
        """
        if r_obj.data_type in \
                [conf. MODEL_TYPE_AD, conf.MODEL_TYPE_CLICK_AD, \
                conf.MODEL_TYPE_FEED_AD, conf.MODEL_TYPE_METEOR_AD, \
                conf.MODEL_TYPE_FEED_IDEA_AD]:
            return self.extract_seglist_ngram_feature([r_obj.text_seg])
        elif r_obj.data_type in [conf.MODEL_TYPE_FEED_USER]:
            return self.extract_seglist_ngram_feature(r_obj.text_seg_list)
        elif r_obj.data_type in [conf.MODEL_TYPE_FEED_IDEA_UNIT, conf.MODEL_TYPE_FEED_IDEA_USER]:
            return self.extract_seglist_ngram_feature(r_obj.idea_seg_list)
        elif r_obj.data_type in [conf.MODEL_TYPE_UNIT, conf.MODEL_TYPE_CLICK_USER, conf.MODEL_TYPE_USER]:
        ######�Լ��дʽӿ�
        #word_ngram = self.extract_text_ngram_feature(r_obj.word_list)
        #idea_ngram = self.extract_text_ngram_feature(r_obj.idea_list)
        ######
            word_ngram = self.extract_seglist_ngram_feature(r_obj.word_seg_list)
            idea_ngram = self.extract_seglist_ngram_feature(r_obj.idea_seg_list)
            features = word_ngram | idea_ngram
            return features
        else:
            raise ValueError("unknow data_type " + r_obj.data_type)

    def res_parse(self, check_result, r_obj):
        """Ԥ��������
        """
        if r_obj.data_type in [conf.MODEL_TYPE_CLICK_AD, conf.MODEL_TYPE_FEED_AD]:
            if check_result.label in self.null_label_set:
                return None
        return check_result.convert_to_dict()

    def check(self, r_obj):
        """����, Ԥ��
        [in]  r_obj: ��Ԥ��Ķ���
        [out] check_result: {"label": ģ�ͽ���ı�ǩ, 
                             "lable_name": ģ�ͽ���ı�ǩ��, 
                             "label_list": ��ϸԤ����[[label1, name, val], [...], ...]}
        """
        check_result_obj = review_object.CheckResultObj()

        features = self.get_features(r_obj)

        hit_feature = features & self.feature_dict_keys
        hit_feature_num = len(hit_feature)

        while True:
            if hit_feature_num < 5:
                break

            label_list = common.Common.cal_multiclass_lr_predict(self.model_dict, self.model_feature_num, \
                    self.feature_dict, self.class_dict, hit_feature)

            if len(label_list) == 0:
                check_result_obj.label = "-10"
                break

            check_result_obj.label = label_list[0][0]
            check_result_obj.label_name = label_list[0][1]
            check_result_obj.label_list = label_list

            if label_list[0][0] in self.class_thres and \
                    float(label_list[0][2]) < self.class_thres[label_list[0][0]]:
                check_result_obj.label = "0"
                check_result_obj.label_name = u'����'
            break

        return self.res_parse(check_result_obj, r_obj)

class CrossNgramLRModel(BaseModel):
    """��һ��ngram��LR�����ģ��
    """
    def extract_seglist_ngram_feature(self, token_lists):
        """��ȡngram feature, seg_list�Ѿ��й���, ��Ҫ��ngram
        ������õ�ngram �����ɿ�Խͣ�ôʵ�ngram
        [in]  seg_list: [[��һ���ؼ��ʵ��д�list], [�ڶ���], ...]
        [out] ngram_feature: ngram�����������
        """
        ngram_feature = set()
        for token_list in token_lists:
            text_ngram = common.Common.cross_ngram_feature(token_list, self.stopword,
                    ngram=3, feature_min_length=2, duplicate=False)
            # ��ΪduplicateΪFalse ���Է���Ϊ���� ���Կ������ò���
            # duplicateΪTrueʱ����list
            ngram_feature |= text_ngram
        return ngram_feature

class IdeaNgramLRModel(BaseModel):
    """ֻʹ�ô������ݽ���ģ��Ԥ��,�һ����˵�����ͣ�ôʱ�(ֻȥ�������ź͵�������ĸ����)
    """
    def init(self, word_segger, stopword, model_dir):
        """�����ʼ���Զ���ͣ�ôʱ�
        """
        super(IdeaNgramLRModel, self).init(word_segger, stopword, model_dir)
        stopword_file = os.path.join(model_dir, "stopword.txt")
        self.stopword = common.Common.load_word_file(stopword_file)

    def filter_single_char(self, ngram_words):
        """���˵������ַ��Ĵ�
        """
        ngram_out = set()
        for word in ngram_words:
            if len(word) >= 2:
                ngram_out.add(word)
        return ngram_out

    def get_features(self, r_obj):
        """��ȡ����
        """
        idea_ngram = set()
        if r_obj.data_type in [conf.MODEL_TYPE_UNIT, conf.MODEL_TYPE_CLICK_USER, conf.MODEL_TYPE_USER, \
                conf.MODEL_TYPE_FEED_IDEA_UNIT, conf.MODEL_TYPE_FEED_IDEA_USER]:
            idea_ngram = self.extract_seglist_ngram_feature(r_obj.idea_seg_list)
            idea_ngram = self.filter_single_char(idea_ngram)
        elif r_obj.data_type in [conf.MODEL_TYPE_FEED_USER]:
            idea_ngram = self.extract_seglist_ngram_feature(r_obj.text_seg_list)
            idea_ngram = self.filter_single_char(idea_ngram)
        elif r_obj.data_type in \
                [conf. MODEL_TYPE_AD, conf.MODEL_TYPE_CLICK_AD, \
                conf.MODEL_TYPE_FEED_AD, conf.MODEL_TYPE_METEOR_AD, \
                conf.MODEL_TYPE_FEED_IDEA_AD]:
            idea_ngram = self.extract_seglist_ngram_feature(r_obj.text_seg)
            idea_ngram = self.filter_single_char(idea_ngram)
        else:
            raise ValueError("unknow data_type " + r_obj.data_type)
        features = idea_ngram 
        return features

class FoodDrinkUnitLRModel(IdeaNgramLRModel):
    """��Ԫ����ģ��-ʳƷ����ģ��
    """
    def init(self, word_segger, stopword, model_dir):
        """
        """
        super(FoodDrinkUnitLRModel, self).init(word_segger, stopword, model_dir)
        #��ȡ�������ʹʱ�
        huishou_word_file = os.path.join(model_dir, "food_drink_huishou_word.txt")
        self.huishou_word = common.Common.load_word_file(huishou_word_file)
        huishou_list = [word.encode('gb18030') for word in self.huishou_word]
        self.huishou_regex = ('|'.join(huishou_list)).decode('gb18030')
        self.huishou_filter_labels = set(["38"])
        #��ȡ���̼������ʹʱ�
        zsjm_word_file = os.path.join(model_dir, "food_drink_zsjm_word.txt")
        self.zsjm_word = common.Common.load_word_file(zsjm_word_file)
        zsjm_list = [word.encode('gb18030') for word in self.zsjm_word]
        self.zsjm_regex = ('|'.join(zsjm_list)).decode('gb18030')
        self.zsjm_filter_labels  = set(["6", "13", "24"])
        #��ȡ���ӹ����ʹʱ�
        djg_word_file = os.path.join(model_dir, "food_drink_djg_word.txt")
        self.djg_word = common.Common.load_word_file(djg_word_file)
        djg_list = [word.encode('gb18030') for word in self.djg_word]
        self.djg_regex = ('|'.join(djg_list)).decode('gb18030')

    def check_rule_is_match(self, content, regex_str):
        """����Ƿ����������еĹ����,TrueΪ����
        """
        if len(re.findall(regex_str, content)) > 0:
            return True
        return False

    def check(self, r_obj):
        """����, Ԥ��
        [in]  r_obj: ��Ԥ��Ķ���
        [out] check_result: {"label": ģ�ͽ���ı�ǩ, 
                             "lable_name": ģ�ͽ���ı�ǩ��, 
                             "label_list": ��ϸԤ����[[label1, name, val], [...], ...]}
        """
        check_result_obj = review_object.CheckResultObj()
        features = self.get_features(r_obj)
        hit_feature = features & self.feature_dict_keys
        hit_feature_num = len(hit_feature)

        while True:
            if hit_feature_num < 5:
                break

            label_list = common.Common.cal_multiclass_lr_predict(self.model_dict, self.model_feature_num, \
                    self.feature_dict, self.class_dict, hit_feature)

            if len(label_list) == 0:
                check_result_obj.label = "-10"
                break
            
            if label_list[0][0] in self.class_thres and \
                    float(label_list[0][2]) < self.class_thres[label_list[0][0]]:
                check_result_obj.label = "0"
                check_result_obj.label_name = u'����'
                check_result_obj.label_list = label_list
                break

            idea_content = ''
            if r_obj.data_type in [conf.MODEL_TYPE_UNIT, conf.MODEL_TYPE_CLICK_USER, conf.MODEL_TYPE_USER, \
                    conf.MODEL_TYPE_FEED_IDEA_UNIT, conf.MODEL_TYPE_FEED_IDEA_USER]:
                idea_content = ''.join([''.join(item) for item in r_obj.idea_seg_list])
            elif r_obj.data_type in [conf.MODEL_TYPE_FEED_USER]:
                idea_content = ''.join([''.join(item) for item in r_obj.text_seg_list])
            else:
                raise ValueError("unknow data_type " + r_obj.data_type)

            lr_predict_label = str(label_list[0][0])
            #�ôʱ����˴��ӹ�
            if self.check_rule_is_match(idea_content, self.djg_regex):
                check_result_obj.label = "-10"
                break

            #�ôʱ����˻���-���
            if lr_predict_label in self.huishou_filter_labels and \
                    self.check_rule_is_match(idea_content, self.huishou_regex):
                check_result_obj.label = "-10"
                break

            #�ôʱ��������̼���-��ζ��|��֭����|ʳ����
            if lr_predict_label in self.zsjm_filter_labels and \
                    self.check_rule_is_match(idea_content, self.zsjm_regex):
                check_result_obj.label = "-10"
                break

            check_result_obj.label = label_list[0][0]
            check_result_obj.label_name = label_list[0][1]
            check_result_obj.label_list = label_list
            break

        return self.res_parse(check_result_obj, r_obj)

class SpyxUnitLRModel(IdeaNgramLRModel):
    """��Ԫ����-��Ʒһеģ��
    """
    def init(self, word_segger, stopword, model_dir):
        """����������̼��˺ʹ��ӹ����߼�,����ؼ���ʶ���ػ����߼�
        """
        super(SpyxUnitLRModel, self).init(word_segger, stopword, model_dir)
        #��ȡ�ػ��ʱ�
        tehua_word_file = os.path.join(model_dir, "tehua_word.txt")
        self.tehua_word = common.Common.load_word_file(tehua_word_file)
        tehua_list = [word.encode('gb18030') for word in self.tehua_word]
        self.tehua_regex = ('|'.join(tehua_list)).decode('gb18030')
        #��ȡ���ӹ������̼��˴ʱ�
        djg_word_file = os.path.join(model_dir, "djg_word.txt")
        self.djg_word = common.Common.load_word_file(djg_word_file)
        djg_list = [word.encode('gb18030') for word in self.djg_word]
        self.djg_regex = ('|'.join(djg_list)).decode('gb18030')

    def check_rule_is_match(self, content, regex_str):
        """����Ƿ����������еĹ����,TrueΪ����
        """
        if len(re.findall(regex_str, content)) > 0:
            return True
        return False

    def check(self, r_obj):
        """����, Ԥ��
        [in]  r_obj: ��Ԥ��Ķ���
        [out] check_result: {"label": ģ�ͽ���ı�ǩ, 
                             "lable_name": ģ�ͽ���ı�ǩ��, 
                             "label_list": ��ϸԤ����[[label1, name, val], [...], ...]}
        """
        check_result_obj = review_object.CheckResultObj()

        features = self.get_features(r_obj)

        hit_feature = features & self.feature_dict_keys
        hit_feature_num = len(hit_feature)

        while True:
            if hit_feature_num < 5:
                break

            label_list = common.Common.cal_multiclass_lr_predict(self.model_dict, self.model_feature_num, \
                    self.feature_dict, self.class_dict, hit_feature)

            if len(label_list) == 0:
                check_result_obj.label = "-10"
                break
            
            #�ôʱ����˴��ӹ������̼���
            idea_content = ''
            if r_obj.data_type in [conf.MODEL_TYPE_UNIT, conf.MODEL_TYPE_CLICK_USER, conf.MODEL_TYPE_USER, \
                    conf.MODEL_TYPE_FEED_IDEA_UNIT, conf.MODEL_TYPE_FEED_IDEA_USER]:
                idea_content = ''.join([''.join(item) for item in r_obj.idea_seg_list])
            elif r_obj.data_type in [conf.MODEL_TYPE_FEED_USER]:
                idea_content = ''.join([''.join(item) for item in r_obj.text_seg_list])
            else:
                raise ValueError("unknow data_type " + r_obj.data_type)

            if self.check_rule_is_match(idea_content, self.djg_regex):
                check_result_obj.label = "-10"
                break

            check_result_obj.label = label_list[0][0]
            check_result_obj.label_name = label_list[0][1]
            check_result_obj.label_list = label_list

            if label_list[0][0] in self.class_thres and \
                    float(label_list[0][2]) < self.class_thres[label_list[0][0]]:
                check_result_obj.label = "0"
                check_result_obj.label_name = u'����'

            #���ػ��ʱ�ʶ�����ױƷ�е����⻯ױƷ
            if str(check_result_obj.label) == "4" and self.check_rule_is_match(idea_content, self.tehua_regex):
                check_result_obj.label = "7"
                check_result_obj.label_name = u'���⻯ױƷ'
            break

        return self.res_parse(check_result_obj, r_obj)


class CrossNgramLRModelWithPosition(BaseModel):
    """��һ��ngram��LR�����ģ��
    1.�ı�Ϊ�ؼ���+���⣬������ؼ��ʺʹ���ı�־����"���:desc;","���;words"
    2.����MODEL_TYPE_UNIT,MODEL_TYPE_CLICK_USER,MODEL_TYPE_USER����ʹ��
    """
    def filter_word(self, word):
        """ngramǰ��word���й���
        1.ͣ�ô�
        2.����
        3.��Ӣ���ַ�
        """
        if word in self.stopword:
            return False
        if word.isdigit():
            return False
        w = word.encode('gb18030', 'ignore')
        if w.isalpha():
            return False
        return True

    def extract_seglist_ngram_feature(self, token_lists):
        """��ȡngram feature, seg_list�Ѿ��й���, ��Ҫ��ngram
        ������õ�ngram �����ɿ�Խͣ�ôʵ�ngram
        [in]  seg_list: [[��һ���ؼ��ʵ��д�list], [�ڶ���], ...]
        [out] ngram_feature: ngram�����������
        """
        ngram_feature = set()
        for token_list in token_lists:
            text_ngram = common.Common.cross_ngram_feature(token_list, self.stopword,
                    ngram=3, feature_min_length=2, duplicate=False)
            # ��ΪduplicateΪFalse ���Է���Ϊ���� ���Կ������ò���
            # duplicateΪTrueʱ����list
            ngram_feature |= text_ngram
        return ngram_feature
    
    def get_features(self, r_obj):
        word_tag = "keyword;"
        desc_tag = "desc;"
        if r_obj.data_type in [conf.MODEL_TYPE_UNIT, conf.MODEL_TYPE_CLICK_USER, conf.MODEL_TYPE_USER]:
            words_pro = [[x + word_tag for x in sum(r_obj.word_seg_list, []) if self.filter_word(x) == True]]
            ideas_pro = [[x + desc_tag for x in sum(r_obj.idea_seg_list, []) if self.filter_word(x) == True]]
            word_ngram = self.extract_seglist_ngram_feature(words_pro)
            idea_ngram = self.extract_seglist_ngram_feature(ideas_pro)
            features = set(word_ngram) | set(idea_ngram)
            return features
        else:
            raise ValueError("unknow data_type " + r_obj.data_type)


class CNNModel(object):
    """ʾ��ģ��, CNN�����ģ��
    """
    def __init__(self):
        """init"""
        pass

    def init(self, word_segger, stopword, model_dir):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword: ͣ�ôʼ���
              model_dir: ģ��Ŀ¼
        [out] None
        """
        self.word_segger = word_segger
        self.stopword = stopword

        class_id_file = os.path.join(model_dir, "class_id.txt")
        vocab2cls_file = os.path.join(model_dir, "vocab2.txt")
        vocab6cls_file = os.path.join(model_dir, "vocab6.txt")
        vocab2cls_path = os.path.join(model_dir, "wlbj2model/")
        vocab6cls_path = os.path.join(model_dir, "wlbj6model/")

        self.class_dict = common.Common.load_class_id_file(class_id_file)
        self.vocab2cls = common.Common.load_vocab(vocab2cls_file)
        self.vocab6cls = common.Common.load_vocab(vocab6cls_file)
        self.cascade_first_level = self.init_cnn_model(vocab2cls_path)
        self.cascade_second_level = self.init_cnn_model(vocab6cls_path)

    def init_cnn_model(self, model_path, use_gpu=False):
        """����cnnģ��
        [in]  model_path: cnnģ���ļ�·��
              use_gpu: �Ƿ�ʹ��gpu��Ĭ��Ϊfasle

        """
        place = fluid.CUDAPlace(0) if use_gpu else fluid.CPUPlace()
        exe = fluid.Executor(place)
        inference_scope = fluid.core.Scope()
        with fluid.scope_guard(inference_scope):
            # ����cnnģ��
            [inference_program, feed_target_names,
                fetch_targets] = fluid.io.load_inference_model(model_path, exe)
        component = [place, exe, inference_scope, inference_program, fetch_targets]
        return component

    def cnn_seg_input_sequence(self, word_list, vocab):
        """�и���ı��б�תΪCNNģ������feature
        [in]  word_list: �д��ı��б�
        [out] cnn_input_feature: ģ������feature
        """
        return common.Common.data_map(word_list, vocab)

    def cnn_infer(self, input_sequence, component):
        """�����ı���ids�����б�Ԥ����
        [in]  input_sequence: �ı���ids����
              componet: cnnģ���ļ�Ԥ�����
        [out] ����Ԥ������б�
        """
        # ����place, executor
        predict_prob = []
        [place, exe, inference_scope, inference_program, fetch_targets] = component
        with fluid.scope_guard(inference_scope):
            pred = exe.run(inference_program,
                feed = common.Common.data2tensor(input_sequence, place),
                fetch_list=fetch_targets,
                return_numpy=True)
            predict_prob = pred[0][0]
        return predict_prob

    def check(self, r_obj):
        """����, Ԥ��
        [in]  r_obj: ��Ԥ��Ķ���
        [out] check_result: {"label": ģ�ͽ���ı�ǩ, 
                             "lable_name": ģ�ͽ���ı�ǩ��, 
                             "label_list": ��ϸԤ����[[label1, name, val], [...], ...]}
        """
        check_user_result_obj = review_object.CheckUserResultObj()

        # һ��������ֵ
        FIRST_THRES = 0.85
        # ���һ���±�
        BJINDEX = 1

        # �û����ϳ���,�ؼ��ʴ������3��
        word_seg_list_sample = common.Common.sample_list(r_obj.word_seg_list)
        idea_seg_list_sample = common.Common.sample_list(r_obj.idea_seg_list)
        word_idea = []
        for seg_list in (word_seg_list_sample + idea_seg_list_sample):
            word_idea += seg_list
        word_idea = common.Common.process_list(word_idea, self.stopword)
        user_input_sequence = self.cnn_seg_input_sequence(word_idea, self.vocab2cls)
        if len(user_input_sequence) == 0:
            return check_user_result_obj.convert_to_dict()
        first_level_predict = self.cnn_infer([user_input_sequence], self.cascade_first_level)

        # ���������Ԥ��ϸ����ҵ
        idea_label_list = []
        for idea in r_obj.idea_seg_list:
            idea = common.Common.process_list(idea, self.stopword)
            idea_input_sequence = self.cnn_seg_input_sequence(idea, self.vocab6cls)
            if len(idea_input_sequence) == 0:
                continue
            label_list = self.cnn_infer([idea_input_sequence], self.cascade_second_level)
            idea_label_list.append(label_list)
        if len(idea_label_list) == 0:
            return check_user_result_obj.convert_to_dict()
        second_level_predict = np.mean(idea_label_list, axis = 0)

        label_list = []
        for k in range(len(second_level_predict)):
            label_list.append([str(k), self.class_dict[str(k)], "%.4f" % second_level_predict[k]])
        label_list = sorted(label_list, key = lambda d: d[2], reverse = True)

        check_user_result_obj.label = label_list[0][0]
        check_user_result_obj.label_name = label_list[0][1]
        check_user_result_obj.label_list = label_list

        if first_level_predict[BJINDEX] < FIRST_THRES and check_user_result_obj.label != "0":
            check_user_result_obj.label = "0"
            check_user_result_obj.label_name = u"�ǰ��"

        return check_user_result_obj.convert_to_dict()


class ZsjmLRModel(BaseModel):
    """���̼���LRģ��--���ı��г�Ƭ��ʶ���Ƿ����̼�����ͼ
    """
    def cut_longtext(self, text):
        """�дʺ�ĳ��ı������гɶ��ı�Ƭ��(�ʼ���ַ�������)
        [in] text, unicode string, �дʺ���ı�
        [out] text_list, �дʵĶ��ı�list, ��['�д� �� �� �� ��', '���� �� �� �� �ı�']
        """
        max_len = 40
        min_len = 30
        chars = u",|;|!| |\?|��|��|��|��" #Ƭ���и����
        text = text.replace('\x01', ',').strip()
        text_segs = re.split(chars, text)
        sub_text_list = []
        out_text_list = []
        if text_segs[-1] == "":
            text_segs = text_segs[:-1]

        print_tag = False
        segs_len = 0
        for idx in range(len(text_segs)):
            sub_text = ",".join(sub_text_list)
            if len(sub_text) <= max_len:
                sub_text_list.append(text_segs[idx])
                segs_len += 1
            else:
                out_text_list.append(sub_text)
                print_tag = True
                sub_text_list = []
                sub_text_list.append(text_segs[idx])
                segs_len = 1

        if len(sub_text_list) != 0:
            sub_text = ",".join(sub_text_list)
            if len(sub_text) < min_len:
                new_list = [text_segs[len(text_segs) - segs_len - 1]]
                new_list.append(sub_text)
                sub_text = ",".join(new_list)
            out_text_list.append(sub_text)
        return out_text_list

    def check_short(self, words_text, hit_feature_nums):
        """���ı�Ԥ��
        """
        words_list = [words_text.split('\x02')]
        features = self.extract_seglist_ngram_feature(words_list)
        hit_feature = features & self.feature_dict_keys
        hit_feature_num = len(hit_feature)
        hit_list = ["-1", "����", "0.01"]

        #����������С��
        if hit_feature_num < hit_feature_nums:
            return False, hit_list 

        label_list = common.Common.cal_multiclass_lr_predict(self.model_dict, self.model_feature_num, \
                self.feature_dict, self.class_dict, hit_feature)

        if len(label_list) == 0:
            return False, hit_list

        if label_list[0][0] in self.class_thres and \
                float(label_list[0][2]) < self.class_thres[label_list[0][0]]:
            return False, hit_list 
        return True, label_list[0]

    def judge_result(self, idea_len, hit_results, r_obj):
        """���к��ҵ���߼��ж�
        """
        hit_seg_len = len(hit_results)
        check_result_obj = review_object.CheckResultObj()
        labels = set()
        min_idea_len = 2     #ʵ�ʳ����Ĵ�����Ŀ
        min_hit_seg_len = 1  #ʵ�����еĶ�����С��Ŀ

        #���ݶ��ı��������������ж�
        if (idea_len <= min_idea_len  and hit_seg_len >= min_hit_seg_len) or \
                (idea_len > min_idea_len and hit_seg_len >= min_idea_len):
            labels = [int(result[0]) for result in hit_results]
            label_names = [result[1] for result in hit_results]
            label_rates = [result[2] for result in hit_results]
            label = max(labels)
            label_name = label_names[labels.index(label)]
            label_rate = label_rates[labels.index(label)]
            check_result_obj.label = str(label)
            check_result_obj.label_name = label_name
            check_result_obj.label_rate = label_rate
            return self.res_parse(check_result_obj, r_obj)
        else:
            return self.res_parse(check_result_obj, r_obj)

    def check(self, r_obj, hit_feature_nums=5):
        """���̼���ģ��Ԥ�����
        """
        idea_words_text = ""
        idea_len = 0
        if r_obj.data_type in [conf.MODEL_TYPE_FEED_USER]:
            idea_words_text = r_obj.idea_text
            idea_len = len(r_obj.text_list) 
        elif r_obj.data_type in [conf.MODEL_TYPE_FEED_IDEA_UNIT, conf.MODEL_TYPE_FEED_IDEA_USER, \
                conf.MODEL_TYPE_UNIT, conf.MODEL_TYPE_CLICK_USER]:
            idea_words_text = r_obj.idea_words
            idea_len = len(r_obj.idea_list) 

        cut_text_segs = self.cut_longtext(idea_words_text)
        hit_results = []

        for segs in cut_text_segs:
            short_tag, short_hit_result = self.check_short(segs, hit_feature_nums)
            if short_tag:
                hit_results.append(short_hit_result)

        return self.judge_result(idea_len, hit_results, r_obj)

if __name__ == "__main__":
    pass
