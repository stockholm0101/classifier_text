#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/02/17 17:11:11
Desc  :   feed���ϰ��˻������ۺ�
"""
import sys
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)


if __name__ == "__main__":

    for line in sys.stdin:
        parts = line.strip("\n").split("\t")
        if len(parts) != 8:
            continue

        userid = parts[0]
        text = parts[5]
        text_seg = parts[6]
        url = parts[7]
        print("\t".join([userid, text, text_seg, url]))
