#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhanghao55@baidu.com
Date  :   19/07/08 14:12:57
Desc  :   ���˻�����
"""
import sys
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import common.sampler as sampler
import conf

def gen_sample(userid, text_sampler):
    """���ݵ�ǰ������� ���ɸ�key�ĳ������
    """
    text_sample_list = text_sampler.get_sample_list()

    ## �����key������Ϊ�� ������
    if len(text_sample_list) == 0:
        return

    text_list, text_seg_list, url_list = zip(*text_sample_list)

    print("\t".join([userid,
            "\x01".join(text_list),
            "\x01".join(text_seg_list),
            "\x01".join(url_list)]))


if __name__ == "__main__":
    data_type = sys.argv[1]
    previous_key = None
    #text_sampler = sampler.Sampler(conf.FEED_SAMPLE_BY_USER_NUM)
    sample_num = conf.FEED_SAMPLE_BY_USER_NUM 
    if data_type == conf.MODEL_TYPE_FEED_IDEA_USER:
        sample_num = conf.FEED_IDEA_SAMPLE_BY_USER_NUM
    text_sampler = sampler.Sampler(sample_num)

    for line in sys.stdin:
        # ����userid, text, text_seg, url
        parts = line.strip("\n").split("\t")
        # key: userid
        key = parts[0]
        if key != previous_key:
            if previous_key is not None:
                gen_sample(previous_key, text_sampler)
            text_sampler.clear()
            previous_key = key
        text = parts[1]
        text_seg = parts[2]
        url = parts[3]
        text_sampler.put((text, text_seg, url))

    if previous_key is not None:
        gen_sample(previous_key, text_sampler)
