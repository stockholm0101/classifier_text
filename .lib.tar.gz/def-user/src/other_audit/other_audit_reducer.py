#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/06/19 20:53:57
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import json

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object

if __name__ == "__main__":
    for eachline in sys.stdin:
        line = eachline.strip("\n").decode('gbk', 'ignore')
        cols = line.split("\t")
        if len(cols) < 8:
            continue

        rru_obj = review_object.ReviewRiskUserObj()
        rru_obj.init(cols)
        result = rru_obj.merge_result()
        print "%s" % (json.dumps(result))

