# -*- coding: utf-8 -*-
"""air flow conf
"""
from datetime import datetime
from datetime import timedelta
import re

from airflow import DAG
from airflow.operators.bash_operator import BashOperator
import pendulum

# local_timezone
local_tz = pendulum.timezone('Asia/Shanghai')

default_args = {
    'owner': 'def-user',
    'depends_on_past': False,
    'start_date': datetime(2020, 03, 10, 15, 0, tzinfo=local_tz),
    'email': ['zhukaiwen@baidu.com', 'zhuxiaodong01@baidu.com', 'zhanghao55@baidu.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
    'queue': 'def-kg',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(
    'def_user_feed', default_args=default_args, 
    schedule_interval="0 */3 * * *")

ttoday="{{ (execution_date + macros.timedelta(hours=11)).strftime('%Y%m%d') }}"
ttime="{{ (execution_date + macros.timedelta(hours=11)).strftime('%Y%m%d%H') }}"


cmd_format = """
    cd /home/work/workspace/def-user-mult/def-user/bin
    python ../src/main.py \
            --today={today} \
            --time={time} \
            --task_config_file={task_config_file} \
            --exe_type={exe_type} \
            --cluster={cluster} \
            --queue={queue} \
            --{func_name}
"""

# ͳһ����
base_val = {"today": ttoday, "time": ttime, \
        "task_config_file": "conf_task.sh", "exe_type": "feed"}

command_pattern = re.compile(r'(?P<func_name>.*)_\d+_(?P<cluster>(khan|mulan|shaolin))_' \
        '(?P<queue>(fengkong-patrol-online_normal|fengkong-galaxy-online_normal|fengkong|galaxy|spark-fengkong-batch))')

def get_command(command_name):
    """������ȷ����ִ�в���
       ���Ƹ�ʽ:${������}_${ģ�ͷ���}_${��Ⱥ��}_${������}
       ע�⣺ģ�ͷ��������ͣ���Ⱥ��'mulan'��'khan'��ѡһ��
             ������'fengkong'��'galaxy'��'spark-fengkong-batch'ѡһ
    """
    res = re.match(command_pattern, command_name)
    # ��������д����Ⱥ�Ͷ���
    if res is None:
    #    # ˵����������������ûд������顢��Ⱥ���������� ������Щ��ȡĬ��ֵ
        raise ValueError("unknown command")

    res_dict = res.groupdict()
    return cmd_format.format(**dict({
            "func_name": res_dict["func_name"],
            "cluster": res_dict["cluster"],
            "queue": res_dict["queue"]}, **base_val))

local_command = [
        "del_feed_files",
        "get_files",
        "init_dirs",
        "tar_all_package",
        "send_risk",
        ]

command = [
        "upload_tar_package_1_shaolin_fengkong-galaxy-online_normal",
        "process_feed_1_shaolin_fengkong-galaxy-online_normal",
        "sample_feed_by_user_1_shaolin_fengkong-patrol-online_normal",
        "predict_trade_feed_ad_1_shaolin_fengkong-galaxy-online_normal",
        "append_trade_feed_ad_1_shaolin_fengkong-galaxy-online_normal",
        "merge_trade_feed_ad_1_shaolin_fengkong-galaxy-online_normal",
        "predict_trade_feed_user_1_shaolin_fengkong-patrol-online_normal",
        "append_trade_feed_user_1_shaolin_fengkong-patrol-online_normal",
        "merge_feed_ad_user_1_shaolin_fengkong-galaxy-online_normal",
        "add_user_info_1_shaolin_fengkong-galaxy-online_normal",
        "service_filter_1_shaolin_fengkong-galaxy-online_normal",
        "service_filter_hit_record_1_shaolin_fengkong-galaxy-online_normal",
        ]

bash_operator = {}
for cmd in local_command:
    bash_operator[cmd] = BashOperator(
        task_id = cmd,
        # ����ִ�е�����������û��д��ģ�ͷ��顢��Ⱥ�����У�����Ĭ��ֵ
        bash_command = get_command(cmd + "_1_shaolin_fengkong-galaxy-online_normal"),
        task_concurrency = 1,
        dag = dag)

for cmd in command:
    bash_operator[cmd] = BashOperator(
        task_id = cmd,
        bash_command = get_command(cmd), 
        dag = dag)

bash_operator["init_dirs"] >> bash_operator["get_files"] >> \
        bash_operator["tar_all_package"] >> \
        bash_operator["upload_tar_package_1_shaolin_fengkong-galaxy-online_normal"] >> \
        bash_operator["process_feed_1_shaolin_fengkong-galaxy-online_normal"] >> \
        bash_operator["predict_trade_feed_ad_1_shaolin_fengkong-galaxy-online_normal"] >> \
        bash_operator["append_trade_feed_ad_1_shaolin_fengkong-galaxy-online_normal"] >> \
        bash_operator["merge_trade_feed_ad_1_shaolin_fengkong-galaxy-online_normal"] >> \
        bash_operator["merge_feed_ad_user_1_shaolin_fengkong-galaxy-online_normal"] >> \
        bash_operator["add_user_info_1_shaolin_fengkong-galaxy-online_normal"] >> \
        bash_operator["service_filter_1_shaolin_fengkong-galaxy-online_normal"] >> \
        bash_operator["service_filter_hit_record_1_shaolin_fengkong-galaxy-online_normal"] >> \
        bash_operator["send_risk"]

bash_operator["process_feed_1_shaolin_fengkong-galaxy-online_normal"] >> \
        bash_operator["sample_feed_by_user_1_shaolin_fengkong-patrol-online_normal"] >> \
        bash_operator["predict_trade_feed_user_1_shaolin_fengkong-patrol-online_normal"] >> \
        bash_operator["append_trade_feed_user_1_shaolin_fengkong-patrol-online_normal"] >> \
        bash_operator["merge_feed_ad_user_1_shaolin_fengkong-galaxy-online_normal"]

bash_operator["del_feed_files"] >> bash_operator["service_filter_hit_record_1_shaolin_fengkong-galaxy-online_normal"]
