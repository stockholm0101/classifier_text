#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2019 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: test_lp_softtext_model.py
Author: workliu(workliu@baidu.com)
Date: 2019/12/16 15:40:20
"""

import sys
sys.path.append('../../src/model/lp_softtext_model/')
import lp_softtext_model

class data_test(object):
    def __init__(self, input_dict):
        self.feature_seg_dict = input_dict

def test_check_softtext():
    lp_model = lp_softtext_model.LrPredict()
    lp_model.init(None, None, '../../model/model_34_lp_softtext')
    feature = None
    with open("./test_data/func_case_soft") as f:
        for line in f:
            feature = line.strip("\n").decode("gb18030").split("\t")
            break

    feature_list = []
    for one_fea in feature:
        print(one_fea)
        feature_list.append(one_fea.split(" "))

    input_dict = {
            "title" : feature_list[0],
            "navi" : feature_list[1],
            "content" : feature_list[2],
            "meta_keywords" : feature_list[3],
            "meta_desc" : feature_list[4],
            "in_anchor" : feature_list[5],
            "out_anchor" : feature_list[6]
    }
    r_obj = data_test(input_dict)
    #r_obj['feature_seg_dict'] = input_dict
    print(lp_model.check(r_obj))

def test_check_not_softtext():
    lp_model = lp_softtext_model.LrPredict()
    lp_model.init(None, None, '../../model/model_34_lp_softtext')
    feature = None
    with open("./test_data/func_case_not_soft") as f:
        for line in f:
            feature = line.strip("\n").decode("gb18030").split("\t")
            break

    feature_list = []
    for one_fea in feature:
        print(one_fea)
        feature_list.append(one_fea.split(" "))

    input_dict = {
            "title" : feature_list[0],
            "navi" : feature_list[1],
            "content" : feature_list[2],
            "meta_keywords" : feature_list[3],
            "meta_desc" : feature_list[4],
            "in_anchor" : feature_list[5],
            "out_anchor" : feature_list[6]
    }
    r_obj = data_test(input_dict)
    #r_obj['feature_seg_dict'] = input_dict
    print(lp_model.check(r_obj))

def test_check_text_process():
    lp_model = lp_softtext_model.LrPredict()
    lp_model.init(None, None, '../../model/model_34_lp_softtext')
    feature = None
    with open("./test_data/func_case_stop_word") as f:
        for line in f:
            feature = line.strip("\n").decode("gb18030").split("\t")
            break

    feature_list = []
    for one_fea in feature:
        print(one_fea)
        feature_list.append(one_fea.split(" "))

    input_dict = {
            "title" : feature_list[0],
            "navi" : feature_list[1],
            "content" : feature_list[2],
            "meta_keywords" : feature_list[3],
            "meta_desc" : feature_list[4],
            "in_anchor" : feature_list[5],
            "out_anchor" : feature_list[6]
    }
    #r_obj['feature_seg_dict'] = input_dict
    r_obj = data_test(input_dict)
    features = lp_model.text_pro_preces(r_obj)
    print("\t".join(features))
if __name__ == '__main__':
    test_check_softtext()
    test_check_not_softtext()
    test_check_text_process()


