#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: test_psy_counsel_model.py
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2020/03/10 17:03:03
"""
import sys
import os
import unittest
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../src/" % _cur_dir)
import model.psychological_counseling_unqualified.counselling_unqualified as counselling_unqualified
import review_object.review_object as review_object
class TestCounselingUnqualified(unittest.TestCase):
    def test_case_posi(self):
        """����������ѯ-��������ѯ
        """ 
        one_case = []
        with open("./test/test_data/psychological_counseling_model/case_posi") as f:
            for line in f:
                one_case = line.strip("\n").decode("gbk", "ignore").split("\t")

        r_obj = review_object.ReviewAdObj()
        a_line = [" "] * 8
        a_line[6] = "\x02".join(one_case)
        r_obj.init(a_line, 1)
        check_obj = counselling_unqualified.CounselingUnqualifiedPredict()
        check_obj.init(None, None, "./model/model_45_psychological_counseling")
        check_res = check_obj.check(r_obj)
        self.assertEqual(check_res['label'], '7')

    def test_case_posi_two(self):
        """����������ѯ-��������ѯ
        """ 
        one_case = []
        with open("./test/test_data/psychological_counseling_model/case_posi_2") as f:
            for line in f:
                one_case = line.strip("\n").decode("gbk", "ignore").split("\t")

        r_obj = review_object.ReviewAdObj()
        a_line = [" "] * 8
        a_line[6] = "\x02".join(one_case)
        r_obj.init(a_line, 1)
        check_obj = counselling_unqualified.CounselingUnqualifiedPredict()
        check_obj.init(None, None, "./model/model_45_psychological_counseling")
        check_res = check_obj.check(r_obj)
        self.assertEqual(check_res['label'], '5')

    def test_case_nage(self):
        """����������ѯ-��������ѯ
        """ 
        one_case = []
        with open("./test/test_data/psychological_counseling_model/case_nage") as f:
            for line in f:
                one_case = line.strip("\n").decode("gbk", "ignore").split("\t")

        r_obj = review_object.ReviewAdObj()
        a_line = [" "] * 8
        a_line[6] = "\x02".join(one_case)
        r_obj.init(a_line, 1)
        check_obj = counselling_unqualified.CounselingUnqualifiedPredict()
        check_obj.init(None, None, "./model/model_45_psychological_counseling")
        check_res = check_obj.check(r_obj)
        self.assertIsNone(check_res, None)

if __name__ == "__main__":
    unittest.main()
