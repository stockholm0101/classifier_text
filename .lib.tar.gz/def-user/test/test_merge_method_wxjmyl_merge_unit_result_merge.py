#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   20/03/13 16:49:21
Desc  :   
"""
import sys
import unittest
import io
import os
import json
import copy
import mock

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../src/" % _cur_dir)
import merge_method.wxjmyl_merge.unit_result_merge as t
import review_object.review_object as review_object

class redirect(object):
    """stdout -> redirect"""
    def __init__(self, std):
        self.content = ""
        self.std = std

    def write(self, string):
        """��дwrite"""
        self.content += string

    def flush(self):
        self.content = ""

class TestUnitResultMerge(unittest.TestCase):
    """unit_result_merge.py
    """
    def setUp(self):
        """set up, every time"""
        pass

    def tearDown(self):
        """tear down, every time"""
        pass

    @classmethod
    def setUpClass(cls):
        """set up, once"""
        cls.unit_info = {
            "info": {
                "userid": "1", "planid": "1", "unitid": "1", 
                "idea_list": ["idea1", "idea2"], "word_list": ["word1", "word2"], 
                "idea_seg_list": [], "word_seg_list": [], 
                "idea_url_list": [], "word_url_list": []
                }, 
            "check_result": [
                {"model_id": 7, "model_name": u"ҽ��ģ��", 
                 "model_result": {"opt": {}, "label_name": u"��θ����", 
                     "label_list": [["5002", u"��θ����", "0.98"], 
                         ["-1", u"������ҵ", "0.02"]], 
                     "label": "5002"}}, 
                {"model_id": 1001, "model_name": u"����ģ��", 
                 "model_result": {"opt": {}, "label_name": u"����", 
                     "label_list": [["1", u"����", "1.0"]], 
                     "label": "1"}}
                ]
            }

    @classmethod
    def tearDownClass(cls):
        """tear down, once"""
        pass

    def test_merge_method(self):
        """test merge_method"""
        # ��������
        unit_info_1 = copy.deepcopy(self.unit_info)
        unit_info_2 = copy.deepcopy(self.unit_info)
        unit_info_2["info"]["unitid"] = "2"
        unit_info_2["check_result"] = [
                {"model_id": 7, "model_name": u"ҽ��ģ��", 
                 "model_result": {"opt": {}, "label_name": u"Ƥ������", 
                     "label_list": [["5001", u"Ƥ������", "1.0"]],
                     "label": "5001"}}, 
                {"model_id": 1003, "model_name": u"����ģ��", 
                 "model_result": {"opt": {}, "label_name": u"΢��", 
                     "label_list": [["5001", u"΢��", "1.0"]],
                     "label": "5001"}}
                ]
        unit_obj_1 = review_object.ReviewUnitObj()
        unit_obj_1.init_from_json(json.dumps(unit_info_1))
        unit_obj_2 = review_object.ReviewUnitObj()
        unit_obj_2.init_from_json(json.dumps(unit_info_2))
        user_result = [unit_obj_1, unit_obj_2]
        obj = t.TradeUnitResultMerge()
        merge_result = obj.merge_method(7, user_result)
        self.assertTrue("5001" in merge_result["label"])
        self.assertTrue("5002" in merge_result["label"])

        # default label -1
        unit_info_1 = copy.deepcopy(self.unit_info)
        unit_info_1["check_result"] = [
                {"model_id": 7, "model_name": u"ҽ��ģ��", 
                 "model_result": {"opt": {}, "label_name": u"������ҵ", 
                     "label_list": [["-1", u"Ƥ������", "1.0"]],
                     "label": "-1"}}, 
                {"model_id": 1003, "model_name": u"����ģ��", 
                 "model_result": {"opt": {}, "label_name": u"΢��", 
                     "label_list": [["5001", u"΢��", "1.0"]],
                     "label": "5001"}}
                ]
        unit_obj_1 = review_object.ReviewUnitObj()
        unit_obj_1.init_from_json(json.dumps(unit_info_1))
        user_result = [unit_obj_1]
        obj = t.TradeUnitResultMerge()
        merge_result = obj.merge_method(7, user_result)
        self.assertTrue("|" not in merge_result["label"])
        self.assertTrue("-1" in merge_result["label"])

        # ��ǩռ��С��unit_percent(0.2)
        unit_info_1 = copy.deepcopy(self.unit_info) # 5002
        unit_info_2 = copy.deepcopy(self.unit_info)
        unit_info_2["check_result"] = [
                {"model_id": 7, "model_name": u"ҽ��ģ��", 
                 "model_result": {"opt": {}, "label_name": u"Ƥ������", 
                     "label_list": [["5001", u"Ƥ������", "1.0"]],
                     "label": "5001"}}, 
                {"model_id": 1003, "model_name": u"����ģ��", 
                 "model_result": {"opt": {}, "label_name": u"΢��", 
                     "label_list": [["5001", u"΢��", "1.0"]],
                     "label": "5001"}}
                ]
        unit_obj_1 = review_object.ReviewUnitObj()
        unit_obj_1.init_from_json(json.dumps(unit_info_1))
        unit_obj_2 = review_object.ReviewUnitObj()
        unit_obj_2.init_from_json(json.dumps(unit_info_2))
        unit_obj_3 = copy.deepcopy(unit_obj_2)
        unit_obj_4 = copy.deepcopy(unit_obj_2)
        unit_obj_5 = copy.deepcopy(unit_obj_2)
        unit_obj_6 = copy.deepcopy(unit_obj_2)
        user_result = [unit_obj_1, unit_obj_2, unit_obj_3, unit_obj_4,
                unit_obj_5, unit_obj_6]
        obj = t.TradeUnitResultMerge()
        merge_result = obj.merge_method(7, user_result)
        self.assertTrue("5002" not in merge_result["label"])
        self.assertTrue("5001" in merge_result["label"])

        # ��ǩ����������unit_num(10)
        unit_info_1 = copy.deepcopy(self.unit_info) # 5002
        unit_info_2 = copy.deepcopy(self.unit_info)
        unit_info_2["check_result"] = [
                {"model_id": 7, "model_name": u"ҽ��ģ��", 
                 "model_result": {"opt": {}, "label_name": u"������ҵ", 
                     "label_list": [["-1", u"������ҵ", "1.0"]],
                     "label": "-1"}}, 
                {"model_id": 1003, "model_name": u"����ģ��", 
                 "model_result": {"opt": {}, "label_name": u"΢��", 
                     "label_list": [["5001", u"΢��", "1.0"]],
                     "label": "5001"}}
                ]
        unit_obj_1 = review_object.ReviewUnitObj()
        unit_obj_1.init_from_json(json.dumps(unit_info_1))
        unit_obj_2 = review_object.ReviewUnitObj()
        unit_obj_2.init_from_json(json.dumps(unit_info_2))
        user_result = []
        for i in range(0, 11):
            u = review_object.ReviewUnitObj()
            u.init_from_json(json.dumps(unit_info_1))
            user_result.append(u)
        for i in range(0, 100):
            u = review_object.ReviewUnitObj()
            u.init_from_json(json.dumps(unit_info_2))
            user_result.append(u)
        merge_result = obj.merge_method(7, user_result)
        self.assertTrue("5002" in merge_result["label"])
        self.assertTrue("|" not in merge_result["label"])

if __name__ == "__main__":
    unittest.main()
