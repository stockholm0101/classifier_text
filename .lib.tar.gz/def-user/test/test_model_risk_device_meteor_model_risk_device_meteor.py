#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   zhubenchang@baidu.com
#Date  :   20/03/24 17:01:37
import sys

import os
import random
import re
import numpy as np

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../src/" % _cur_dir)
import common.common as common
import review_object.review_object as review_object
import unittest
from model.risk_device_meteor_model.risk_device_meteor import RiskDeviceMeteor

import conf
import time
import mock

import word_seg


class TestRiskDeviceMeteor(unittest.TestCase):
    def setUp(self):
        """��ʼ��
        """
        segdict_path = "dict/chinese_gbk"
        self.stopword = set(["stopwords"])
        self.model_dir = "my_model_path"

        self.word_segger = word_seg.WordSeg(segdict_path)
        self.word_segger.init_wordseg_handle()

        self.riskDeviceMeteor = RiskDeviceMeteor()

    def test_check_hit(self):
        """����check-������
        """
        self.riskDeviceMeteor.get_risk_user = mock.Mock(return_value=set(["25514828"]))
        self.riskDeviceMeteor.init(self.word_segger, self.stopword, self.model_dir)
        line = """25514828\tword\t458544217\t155070966413\t1\t��ɽզ������й����������Ǯ\t��ɽզ������й����������Ǯ\thttps://ada.baidu.com/site/ysh1.com/imlp/?imid=82dca46bdda47fafa9f656e58babd734&zzx-&gmsxpf-24483345&={adposition}"""
        line = line.strip("\n").lower().decode("gbk", "ignore").split("\t")
        r_obj = None
        r_obj = review_object.ReviewClickAdObj()
        r_obj.init(line)
        check_result = self.riskDeviceMeteor.check(r_obj)
        self.assertEqual(check_result["label"], "1")

    def test_check_NOT_hit_useridNotIn(self):
        """����check: userid���ڼ�ط�Χ
        """
        self.riskDeviceMeteor.get_risk_user = mock.Mock(return_value=set(["110"]))
        self.riskDeviceMeteor.init(self.word_segger, self.stopword, self.model_dir)
        line = """25514828\tword\t458544217\t155070966413\t1\t��ɽզ������й����������Ǯ\t��ɽզ������й����������Ǯ\thttps://ada.baidu.com/site/ysh1.com/imlp/?imid=82dca46bdda47fafa9f656e58babd734&zzx-&gmsxpf-24483345&={adposition}"""
        line = line.strip("\n").lower().decode("gbk", "ignore").split("\t")
        r_obj = None
        r_obj = review_object.ReviewClickAdObj()
        r_obj.init(line)
        check_result = self.riskDeviceMeteor.check(r_obj)
        self.assertEqual(check_result, None)

    def test_check_NOT_hit_emptytext(self):
        """����check: ����Ϊ��
        """
        self.riskDeviceMeteor.get_risk_user = mock.Mock(return_value=set(["25514828"]))
        self.riskDeviceMeteor.init(self.word_segger, self.stopword, self.model_dir)
        line = """25514828\tword\t458544217\t155070966413\t1\t\t\thttps://ada.baidu.com/site/ysh1.com/imlp/?imid=82dca46bdda47fafa9f656e58babd734&zzx-&gmsxpf-24483345&={adposition}"""
        line = line.strip("\n").lower().decode("gbk", "ignore").split("\t")
        r_obj = None
        r_obj = review_object.ReviewClickAdObj()
        r_obj.init(line)
        check_result = self.riskDeviceMeteor.check(r_obj)
        self.assertEqual(check_result, None)

    def tearDown(self):
        """���Խ���
        """
        print("case���Խ���")

if __name__ == "__main__":
    unittest.main()

