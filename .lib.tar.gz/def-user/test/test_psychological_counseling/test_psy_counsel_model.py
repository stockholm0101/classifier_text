#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: test_psy_counsel_model.py
Author: workliu(workliu@baidu.com)
Date: 2020/03/10 17:03:03
"""
import sys 
import psychological_counsel
import review_object.review_object as review_object

def test_case_posi():
    """����������ѯ-��������ѯ
    """ 
    one_case = []
    with open("./test/test_psychological_counseling/data/case_posi") as f:
        for line in f:
            one_case = line.strip("\n").decode("gbk", "ignore").split("\t")

    r_obj = review_object.ReviewAdObj()
    a_line = [" "] * 8
    a_line[6] = "\x02".join(one_case)
    r_obj.init(a_line, 1)
    check_obj = psychological_counsel.PysCounselingPredict()
    check_obj.init(None, None, "./model/model_45_psychological_counseling")
    print(check_obj.check(r_obj))

def test_case_nage():
    """����������ѯ-��������ѯ
    """ 
    one_case = []
    with open("./test/test_psychological_counseling/data/case_nage") as f:
        for line in f:
            one_case = line.strip("\n").decode("gbk", "ignore").split("\t")

    r_obj = review_object.ReviewAdObj()
    a_line = [" "] * 8
    a_line[6] = "\x02".join(one_case)
    r_obj.init(a_line, 1)
    check_obj = psychological_counsel.PysCounselingPredict()
    check_obj.init(None, None, "./model/model_45_psychological_counseling")
    print(check_obj.check(r_obj))

if __name__ == "__main__":
    test_case_posi()
    test_case_nage()
