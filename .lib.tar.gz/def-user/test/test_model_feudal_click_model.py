#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   shenhao02@baidu.com
Date  :   20/06/08 10:33:29
Desc  :   click feudal unittest
"""
import sys
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../src/" % _cur_dir)
import common.common as common
import review_object.review_object as review_object
import unittest
import word_seg
from model.click_model.click_feudal_model import ClickModel

import conf
import time

segdict_path = "dict/chinese_gbk"
stopword_file = "data/stopword.txt"
stopword = common.Common.load_word_file(stopword_file)
word_segger = word_seg.WordSeg(segdict_path)
word_segger.init_wordseg_handle()
model_dir = "model/model_110200100600_fjmx/"
feudalmodel = ClickModel()

class TestBaseModel(unittest.TestCase):
    def setUp(self):
        """��ʼ��
        """
        self.feudalmodel = feudalmodel
        self.feudalmodel.init(word_segger, stopword, model_dir)

    def test_check_labelf1(self):
        """����check_labelf1
           �Ƿ⽨����
        """
        one_case = None
        with open("./test/test_data/feudal_click_model/case_not_feudal.txt") as f:
            for line in f:
                one_case = line.strip("\n").decode("gbk", "ignore").split("\t")
        r_obj = None
        r_obj = review_object.ReviewClickAdObj()
        r_obj.init(one_case)
        check_result = self.feudalmodel.check(r_obj)
        self.assertEqual(check_result["label"], "-1")

    def test_check_label0(self):
        """����check-label0
           �⽨����-��ˮ����
        """
        one_case = None
        with open("./test/test_data/feudal_click_model/case_feudal.txt") as f:
            for line in f:
                one_case = line.strip("\n").decode("gbk", "ignore").split("\t")
        r_obj = None
        r_obj = review_object.ReviewClickAdObj()
        r_obj.init(one_case)
        check_result = self.feudalmodel.check(r_obj)
        self.assertEqual(check_result["label"], "0")

    def test_check_label8(self):
        """����check-label8
           �⽨����-��Ʒ�ڼ�-ת�ˣ���а��Υ�����ϣ�����
        """
        one_case = None
        with open("./test/test_data/feudal_click_model/case_feudal_risk.txt") as f:
            for line in f:
                one_case = line.strip("\n").decode("gbk", "ignore").split("\t")
        r_obj = None
        r_obj = review_object.ReviewClickAdObj()
        r_obj.init(one_case)
        check_result = self.feudalmodel.check(r_obj)
        self.assertEqual(check_result["label"], "8")

    def tearDown(self):
        """���Խ���
        """
        print("case���Խ���")

if __name__ == "__main__":
    unittest.main()