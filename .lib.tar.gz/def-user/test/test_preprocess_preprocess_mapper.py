#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   20/02/10 18:47:11
Desc  :   ��${root_dir}ִ��
"""
import sys
import unittest
import io
import os
import json
import mock

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../src/" % _cur_dir)
import common.word_segger as word_segger
import preprocess.preprocess_mapper as t

class redirect(object):
    """stdout -> redirect"""
    def __init__(self, std):
        self.content = ""
        self.std = std

    def write(self, string):
        """��дwrite"""
        self.content += string

    def flush(self):
        self.content = ""

class TestPreprocessMapper(unittest.TestCase):
    """preprocess_mapper.py
    """
    def setUp(self):
        """set up, every time"""
        pass

    def tearDown(self):
        """tear down, every time"""
        pass

    @classmethod
    def setUpClass(cls):
        """set up, once"""
        dict_path = "%s/../dict/chinese_gbk" % _cur_dir
        cls.segger = word_segger.WordSegger(segdict_path = dict_path)

    @classmethod
    def tearDownClass(cls):
        """tear down, once"""
        cls.segger.destroy()

    def test_idea_process(self):
        """test idea_process"""
        # userid not in user_set
        line = ["0" for i in range(0, 21)]
        user_set = set(["1", "2"])
        line[4] = "10"
        eachline = "\t".join(line)
        self.assertIsNone(t.idea_process(eachline, user_set))

        # ignore true
        line = ["0" for i in range(0, 21)]
        user_set = set(["1", "2"])
        line[4] = "1"
        eachline = "\t".join(line)
        self.assertIsNotNone(t.idea_process(eachline, user_set, ignore = True))

        # idea����Ч
        line = ["0" for i in range(0, 21)]
        user_set = set(["1", "2"])
        line[4] = "1"
        line[5] = "1"  # isdel, 1.ɾ��
        line[16] = "2020-01-01 00:00:00"
        eachline = "\t".join(line)
        self.assertIsNone(t.idea_process(eachline, user_set))
        line[14] = "4" # ideastat5 0/2.��Ч
        eachline = "\t".join(line)
        self.assertIsNone(t.idea_process(eachline, user_set))

        # ����
        line = ["0" for i in range(0, 21)]
        user_set = set(["1", "2"])
        line[4] = "1"
        line[17] = "title"
        line[18] = "desc1"
        line[19] = "desc2"
        line[20] = "www.baidu.com"
        eachline = "\t".join(line)
        self.assertTrue("1" == t.idea_process(eachline, user_set)["userid"])
        self.assertTrue("www.baidu.com" == t.idea_process(eachline, user_set)["url"])

    def test_word_process(self):
        """test word_process"""
        # userid not in user_set
        line = ["0" for i in range(0, 30)]
        user_set = set(["1", "2"])
        line[3] = "10"
        eachline = "\t".join(line)
        self.assertIsNone(t.word_process(eachline, user_set))

        # ignore true
        line = ["0" for i in range(0, 30)]
        user_set = set(["1", "2"])
        line[3] = "1"
        eachline = "\t".join(line)
        self.assertIsNotNone(t.word_process(eachline, user_set, ignore = True))

        # word����Ч
        line = ["0" for i in range(0, 30)]
        user_set = set(["1", "2"])
        line[3] = "1"
        line[20] = "1" # 1.ɾ��
        line[19] = "2020-01-01 00:00:00"
        eachline = "\t".join(line)
        self.assertIsNone(t.word_process(eachline, user_set))
        line[20] = "0" # 0.δɾ��
        line[13] = "4" # wstat3, 4.ʧЧ
        eachline = "\t".join(line)
        self.assertIsNone(t.word_process(eachline, user_set))

        # ����
        line = ["0" for i in range(0, 30)]
        user_set = set(["1", "2"])
        line[3] = "1"
        line[5] = u"�ؼ���\n����".encode("utf-8", "ignore")
        eachline = "\t".join(line)
        self.assertTrue(u"�ؼ��� ����" == t.word_process(eachline, user_set)["text"])

    def test_click_process(self):
        """test click_process"""
        # line length
        line = ["0" for i in range(0, 25)]
        user_set = set(["1", "2"])
        eachline = "\t".join(line)
        self.assertIsNone(t.click_process(eachline, user_set))

        # ����
        line = ["0" for i in range(0, 26)]
        user_set = set(["1", "2"])
        line[13] = "����"
        eachline = "\t".join(line)
        self.assertTrue(u"0,����,0,0" == t.click_process(eachline, user_set)["text"])

    def test_meteor_process(self):
        """test meteor_process, �ﳲ�ܾ�������"""
        # length
        line = ["0" for i in range(0, 70)]
        user_set = set(["1", "2"])
        eachline = "\t".join(line)
        self.assertIsNone(t.meteor_process(eachline, user_set))

        # audit_type��word, idea
        line = ["0" for i in range(0, 80)]
        user_set = set(["1", "2"])
        line[2] = "pair" # audit_type
        eachline = "\t".join(line)
        self.assertIsNone(t.meteor_process(eachline, user_set))

        # �Ƿﳲ
        line = ["0" for i in range(0, 80)]
        user_set = set(["1", "2"])
        line[1] = "output-trad-fc" # pipe_type, output-trad-fc�ﳲ
        line[41] = "1"             # productid, 0.�ﳲ
        eachline = "\t".join(line)
        self.assertIsNone(t.meteor_process(eachline, user_set))
        line[41] = "0"
        line[74] = "2"             # audit_channel_type, 1.����, 3.һ��
        self.assertIsNone(t.meteor_process(eachline, user_set))
        line[74] = "1"
        line[1] = "output-trad-other"
        self.assertIsNone(t.meteor_process(eachline, user_set))
        line[1] = "output-trad-fc"
        line[45] = "DISAPPROVED"   # review_result
        self.assertIsNone(t.meteor_process(eachline, user_set))

        # ����word
        line = ["0" for i in range(0, 80)]
        user_set = set(["1", "2"])
        line[1] = "output-trad-fc" # pipe_type, output-trad-fc�ﳲ
        line[2] = "word"           # audit_type, word
        line[74] = "1"             # audit_channel_type, 1.����
        line[45] = "APPROVED"      # review_result
        line[16] = u"��\n��"       # wordtext
        eachline = "\t".join(line)
        self.assertTrue(u"�� ��" == t.meteor_process(eachline, user_set)["text"])

        # ����idea
        line = ["0" for i in range(0, 80)]
        user_set = set(["1", "2"])
        line[1] = "output-trad-fc" # pipe_type, output-trad-fc�ﳲ
        line[2] = "idea"           # audit_type, idea
        line[74] = "1"             # audit_channel_type, 1.����
        line[45] = "APPROVED"      # review_result
        line[19] = u"����{�ؼ���}" # title
        line[20] = u"����1"        # desc1
        line[21] = u"����2"        # desc2
        eachline = "\t".join(line)
        self.assertTrue(u"���� ����1 ����2" == t.meteor_process(eachline, user_set)["text"])

    def test_url_process(self):
        """test url_process"""
        # length
        line = ["0" for i in range(0, 3)]
        user_set = set(["1", "2"])
        eachline = "\t".join(line)
        self.assertIsNone(t.url_process(eachline, user_set))

        # feature��json
        line = ["0" for i in range(0, 4)]
        user_set = set(["1", "2"])
        line[3] = "not json"
        eachline = "\t".join(line)
        self.assertIsNone(t.url_process(eachline, user_set))

        # ����
        line = ["0" for i in range(0, 4)]
        user_set = set(["1", "2"])
        line[3] = '{"content": "src content"}'
        eachline = "\t".join(line)
        self.assertTrue(type(t.url_process(eachline, user_set)["feature"]).__name__ == "dict")

    def test_format_str(self):
        """test format_str"""
        # length = 0
        string = "\n\n"
        self.assertIsNone(t.format_str(string))

        # ����
        string = "test\n\nstring\t"
        self.assertTrue("test string" == t.format_str(string))

    def test_print_url_line(self):
        """test print_url_line"""
        # ����
        res = {"url": "http://www.baidu.com",
               "userids": "1|2",
               "src": "<html>content</html>",
               "feature": {"title": "title",
                   "navigation": "navigation",
                   "sem_central_content": "sem_central_content",
                   "reserved1": "reserved1",
                   "abstract_s": "abstract_s",
                   "reserved3": json.dumps({"links": [{"text": "r1"}, {"text": "r2"}]}),
                   "links": json.dumps({"links": [{"text": "l1"}, {"text": "l2"}]})
                   }
               }

        r = redirect(sys.stdout)
        sys.stdout = r
        t.print_url_line(self.segger, res)
        sys.stdout = r.std
        content = r.content
        r.flush()

        self.assertTrue(6 == len(content.split("\t")))
        self.assertTrue("l1 l2" == json.loads(content.split("\t")[4]).get("links"))

        # ���ֶ�
        res = {"url": "http://www.baidu.com",
               "userids": "1|2",
               "src": "<html>content</html>",
               "feature": {"title": "title",
                   "navigation": "navigation",
                   "sem_central_content": "sem_central_content",
                   "reserved1": "reserved1",
                   "abstract_s": "abstract_s",
                   "reserved3": ""
                   }
               }

        r = redirect(sys.stdout)
        sys.stdout = r
        t.print_url_line(self.segger, res)
        sys.stdout = r.std
        content = r.content
        r.flush()

        self.assertTrue(6 == len(content.split("\t")))
        self.assertTrue("" == json.loads(content.split("\t")[4]).get("links"))

    def test_get_users(self):
        """test get_users"""
        user_set = t.get_users("test/test_data/test_preprocess_preprocess_mapper_user_info.txt")
        self.assertTrue("2246" in user_set)

    def test_feed_process(self):
        """test feed_process"""
        # parts length < 35
        line = "\t".join(["1", "2", "3", "4"])
        self.assertTrue(t.feed_process(line, set()) is None)

        # cmatch not in
        line = "\t".join(["1"] * 35)
        self.assertTrue(t.feed_process(line, set()) is None)

        # ����
        line = ["1"] * 35
        line[8] = "545"
        line = "\t".join(line)
        self.assertTrue(t.feed_process(line, set()).get("text", None) == "1,1,1")

if __name__ == "__main__":
    unittest.main()
