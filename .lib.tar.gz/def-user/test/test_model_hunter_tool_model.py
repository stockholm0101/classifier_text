#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   shenhao02g@baidu.com
import sys
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../src/" % _cur_dir)
import common.common as common
import review_object.review_object as review_object
import unittest
from model.hunter_tool_model.model import HunterPredict

import conf
import time

segdict_path = "dict/chinese_gbk"
stopword_file = "data/stopword.txt"
import word_seg
stopword = common.Common.load_word_file(stopword_file)
word_segger = word_seg.WordSeg(segdict_path)
word_segger.init_wordseg_handle()
model_dir = "model/model_49_hunter_tool"
hunter_predict = HunterPredict()

class TestLpBaseModel(unittest.TestCase):
    def setUp(self):
        """��ʼ��
        """
        self.hunter_predict = hunter_predict
        self.hunter_predict.init(word_segger, stopword, model_dir)

    def test_extract_seg_ngram_feature(self):
        """����extract_seg_ngram_feature
        """
        text_seg = [u'��ˮ', u'�����', u'��', u'����', u'�����', u'������', u'һ��']
        features = set()
        skip_stopword = []
        for x in text_seg:
            if x in stopword:
                features |= common.Common.ngram(skip_stopword, 3)
                skip_stopword = []
                continue
            skip_stopword.append(x)
        if len(skip_stopword) > 0:
            features |= common.Common.ngram(skip_stopword, 3)
        expect = set([u'\u7535\u6355\u9c7c', u'\u54b8\u6c34\u6355\u9c7c\u673a', u'\u6355\u9c7c', u'\u6355\u9c7c\u673a\u7535', u'\u8d85\u58f0\u6ce2\u4e00\u4f53', u'\u9006\u53d8\u5668\u8d85\u58f0\u6ce2', u'\u6355\u9c7c\u673a', u'\u4e00\u4f53', u'\u6355\u9c7c\u9006\u53d8\u5668', u'\u7535', u'\u9006\u53d8\u5668', u'\u8d85\u58f0\u6ce2', u'\u54b8\u6c34'])
        self.assertSetEqual(features, expect)

    def test_check_label5(self):
        """����check_label5
        """
        one_case = None
        with open("./test/test_data/hunter_tool_model/case_tool.txt") as f:
            for line in f:
                one_case = line.strip("\n").decode("gbk", "ignore").split("\t")
        r_obj = None
        r_obj = review_object.ReviewUnitObj()
        r_obj.init(one_case)
        check_result = self.hunter_predict.check(r_obj)
        self.assertEqual(check_result["label"], "5")

    def test_check_label2(self):
        """����check-label2
        """
        one_case = None
        with open("./test/test_data/hunter_tool_model/case_water.txt") as f:
            for line in f:
                one_case = line.strip("\n").decode("gbk", "ignore").split("\t")
        r_obj = None
        r_obj = review_object.ReviewUnitObj()
        r_obj.init(one_case)
        check_result = self.hunter_predict.check(r_obj)
        self.assertEqual(check_result["label"], "2")

    def test_check_label4(self):
        """����check-label4
        """
        one_case = None
        with open("./test/test_data/hunter_tool_model/case_other.txt") as f:
            for line in f:
                one_case = line.strip("\n").decode("gbk", "ignore").split("\t")
        r_obj = None
        r_obj = review_object.ReviewUnitObj()
        r_obj.init(one_case)
        check_result = self.hunter_predict.check(r_obj)
        self.assertEqual(check_result["label"], "4")

    def tearDown(self):
        """���Խ���
        """
        print("case���Խ���")

if __name__ == "__main__":
    unittest.main()
