#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   20/05/18 14:48:34
Desc  :   
"""
import sys
import unittest
import os
import copy

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../src/" % _cur_dir)
import service_method.label_operation as l
import review_object.service_object as service_object

class TestLabelOperation(unittest.TestCase):
    """label_operation.py
    """
    def setUp(self):
        """set up, every time"""
        self.s_obj = service_object.ServiceResultObj()
        self.s_obj.user_info = copy.deepcopy(self.user_info)

    def tearDown(self):
        """tear down, every time"""
        pass

    @classmethod
    def setUpClass(cls):
        """set up, once"""
        cls.user_info = {"info": {"product": "fc",
                "ulevel": "10104",
                "consume": "0.0",
                "url": "http://www.maodou.com",
                "company": "��˾��",
                "register": "2019-10-10 12:12:30",
                "userid": "1",
                "main_lice_ids": "1004",
                "isztc": "0",
                "uname": "�û���",
                "ustatus": "3",
                "optids": "20||1109",
                "main_lices": "��½��ҵ��λ��ͻ�",
                "opts": "ƽ̨||�����ƹ�"
                },
            "check_result": [{}],
            "userid": "1"
            }

        cls.service_conf = {"enable": True,
            "service_id": "1",
            "service_name": "service_name",
            "model_id": "",
            "label_id": "",
            "intersection": "",
            "difference": "",
            "limit_ulevel": "",
            "opt_intersection": "",
            "opt_difference": "",
            "main_intersection": "",
            "main_difference": ""
            }

        cls.lo = l.LabelOperation()

    @classmethod
    def tearDownClass(cls):
        """tear down, once"""
        pass

    def test_check_userstatus(self):
        """test check userstatus"""
        self.s_obj.user_info["info"]["ustatus"] = "1"
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

    def test_check_isztc(self):
        """test check isztc"""
        self.s_obj.user_info["info"]["ustatus"] = "2"
        self.s_obj.user_info["info"]["isztc"] = "1"
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

    def test_check_ulevel(self):
        """test check ulevel"""
        self.s_obj.user_info["info"]["ustatus"] = "2"
        self.s_obj.user_info["info"]["isztc"] = "0"
        self.s_obj.user_info["info"]["ulevel"] = "10101"
        self.service_conf["limit_ulevel"] = "10104"
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

    def test_check_register(self):
        """test check register"""
        self.s_obj.user_info["info"]["ustatus"] = "2"
        self.s_obj.user_info["info"]["isztc"] = "0"
        self.s_obj.user_info["info"]["ulevel"] = "10104"
        self.s_obj.user_info["info"]["register"] = "2020-01-01 10:00:00"

        self.service_conf["limit_ulevel"] = "10104"
        self.service_conf["limit_time"] = "2020-05-01 10:00:00"
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

    def test_check_consume(self):
        """test check consume"""
        self.s_obj.user_info["info"]["ustatus"] = "2"
        self.s_obj.user_info["info"]["isztc"] = "0"
        self.s_obj.user_info["info"]["ulevel"] = "10104"
        self.s_obj.user_info["info"]["register"] = "2020-01-01 10:00:00"
        self.s_obj.user_info["info"]["consume"] = "10.0"

        self.service_conf["limit_ulevel"] = "10104"
        self.service_conf["limit_time"] = "2019-05-01 10:00:00"
        self.service_conf["limit_consume"] = 100.0
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

    def test_check_product(self):
        """test check product"""
        self.s_obj.user_info["info"]["ustatus"] = "2"
        self.s_obj.user_info["info"]["isztc"] = "0"
        self.s_obj.user_info["info"]["ulevel"] = "10104"
        self.s_obj.user_info["info"]["register"] = "2020-01-01 10:00:00"
        self.s_obj.user_info["info"]["consume"] = "10.0"
        self.s_obj.user_info["info"]["product"] = "fc"

        self.service_conf["limit_ulevel"] = "10104"
        self.service_conf["limit_time"] = "2019-05-01 10:00:00"
        self.service_conf["limit_consume"] = 1.0
        self.service_conf["limit_product"] = "feed"
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

    def _init_user_service(self):
        """��ʼ��user_info��service, ʹuser_info��ͨ������ļ��
        """
        self.s_obj.user_info["info"]["ustatus"] = "2"
        self.s_obj.user_info["info"]["isztc"] = "0"
        self.s_obj.user_info["info"]["ulevel"] = "10104"
        self.s_obj.user_info["info"]["register"] = "2020-01-01 10:00:00"
        self.s_obj.user_info["info"]["consume"] = "10.0"
        self.s_obj.user_info["info"]["product"] = "fc"

        self.service_conf["limit_ulevel"] = "10104"
        self.service_conf["limit_time"] = "2019-05-01 10:00:00"
        self.service_conf["limit_consume"] = 1.0
        self.service_conf["limit_product"] = "fc"

        self.s_obj.user_info["check_result"] = [
            {"model_type": 2, "model_id": "6", "model_name": "name", 
             "model_result": {"label": "6", "label_name": "name", 
             "label_list": [["6", "", ""]]}}, 
            {"model_type": 2, "model_id": "7", "model_name": "name", 
             "model_result": {"label": "7|77", "label_name": "name", 
             "label_list": [["7", "", ""]]}},
            {"model_type": 2, "model_id": "8", "model_name": "name", 
             "model_result": {"label": "8", "label_name": "name", 
             "label_list": [["8", "", ""]]}}
            ]
        self.s_obj.user_info["info"]["optids"] = "20||1109"
        self.s_obj.user_info["info"]["main_lice_ids"] = "1004||1005"

    def test_check_modelsresult_mid(self):
        """test check models_result"""
        self._init_user_service()
        # ��ģ��δ����
        self.service_conf["model_id"] = "6"
        self.service_conf["label_id"] = "10"
        self.service_conf["intersection"] = {}
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

    def test_check_modelsresult_intersection(self):
        self._init_user_service()
        # ����δ����
        self.service_conf["model_id"] = "6"
        self.service_conf["label_id"] = "6"
        self.service_conf["intersection"] = {"7": "1|2"}
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

    def test_check_modelsresult_difference(self):
        self._init_user_service()
        # ��������
        self.service_conf["model_id"] = "6"
        self.service_conf["label_id"] = "6"
        self.service_conf["intersection"] = {"7": "7"}
        self.service_conf["difference"] = {"8": "8"}
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

    def test_check_modelsresult_opt_intersection(self):
        self._init_user_service()
        # ���ƿ�ѡ����δ����
        self.service_conf["model_id"] = "6"
        self.service_conf["label_id"] = "6"
        self.service_conf["intersection"] = {"7": "7"} # ��������
        self.service_conf["difference"] = {"8": "88"}  # δ���з���
        self.service_conf["opt_intersection"] = "200"  # δ����
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

        self.lo.opt_conf = {"1": set(["200"])}
        self.service_conf["opt_intersection"] = ""
        self.service_conf["opttype_intersection"] = "1"
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

    def test_check_modelsresult_opt_difference(self):
        self._init_user_service()
        # ���޿�ѡ��������
        self.service_conf["model_id"] = "6"
        self.service_conf["label_id"] = "6"
        self.service_conf["intersection"] = {"7": "7"} # ��������
        self.service_conf["difference"] = {"8": "88"}  # δ���з���
        self.service_conf["opt_intersection"] = "20"   # ����
        self.service_conf["opt_difference"] = "1109"   # ��������
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

        self.lo.opt_conf = {"1": set(["1109"])}
        self.service_conf["opt_difference"] = ""
        self.service_conf["opttype_difference"] = "1"
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

    def test_check_modelsresult_main_intersection(self):
        self._init_user_service()
        # ������������δ����
        self.service_conf["model_id"] = "6"
        self.service_conf["label_id"] = "6"
        self.service_conf["intersection"] = {"7": "7"} # ��������
        self.service_conf["difference"] = {"8": "88"}  # δ���з���
        self.service_conf["opt_intersection"] = "20"   # ����
        self.service_conf["opt_difference"] = "9109"   # ����δ����
        self.service_conf["main_intersection"] = "104" # ����δ����
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

    def test_check_modelsresult_main_difference(self):
        self._init_user_service()
        # ����������������
        self.service_conf["model_id"] = "6"
        self.service_conf["label_id"] = "6"
        self.service_conf["intersection"] = {"7": "7"}  # ��������
        self.service_conf["difference"] = {"8": "88"}   # δ���з���
        self.service_conf["opt_intersection"] = "20"    # ����
        self.service_conf["opt_difference"] = "9109"    # ����δ����
        self.service_conf["main_intersection"] = "1004" # ��������
        self.service_conf["main_difference"] = "1005"   # ��������
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

    def test_check_modelsresult_model_id_dict(self):
        self._init_user_service()
        # ����ģ�Ͳ�������
        self.service_conf["model_id"] = "6"
        self.service_conf["label_id"] = "6"
        self.service_conf["intersection"] = {"7": "7", "777": "777"}  # ������������
        self.service_conf["difference"] = {"8": "88"}   # δ���з���
        self.service_conf["opt_intersection"] = "20"    # ����
        self.service_conf["opt_difference"] = "9109"    # ����δ����
        self.service_conf["main_intersection"] = "1004" # ��������
        self.service_conf["main_difference"] = "9005"   # ����δ����
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertFalse(check_result)

    def test_check_modelsresult_hit(self):
        # ����
        self._init_user_service()
        self.service_conf["model_id"] = "6"
        self.service_conf["label_id"] = "6"
        self.service_conf["intersection"] = {"7": "7"}  # ������������
        self.service_conf["difference"] = {"8": "88"}   # δ���з���
        self.service_conf["opt_intersection"] = "20"    # ����
        self.service_conf["opt_difference"] = "9109"    # ����δ����
        self.service_conf["main_intersection"] = "1004" # ��������
        self.service_conf["main_difference"] = "9005"   # ����δ����
        check_result, model_id = self.lo.check(self.s_obj, self.service_conf)
        self.assertTrue(check_result)


if __name__ == "__main__":
    unittest.main()
