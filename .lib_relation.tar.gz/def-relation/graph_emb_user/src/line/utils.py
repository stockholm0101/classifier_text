#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/09/10 20:52:46
Desc  :
"""
import numpy as np


class DBLPDataLoader(object):
    """
    ���ݼ��غ������ɼ�����
    """
    def __init__(self, graph_file):
        """
        init
        """
        self.g = {}
        self.count = {}
        with open(graph_file, "r+") as f:
            for line in f:
                edge = []
                parts = line.strip("\n").split(" ")
                node = parts[0]
                adjs = parts[1:]
                self.g[node] = adjs
                self.count[node] = len(adjs)
        self.num_of_nodes = len(self.g)

        self.node_negative_distribution = np.power(np.array([self.count[node] for node in self.g], \
                dtype=np.float32), 0.75)
        self.node_negative_distribution /= np.sum(self.node_negative_distribution)
        self.node_sampling = AliasSampling(prob=self.node_negative_distribution)

        self.node_index = {}
        self.node_index_reversed = {}
        index = 0
        for node in self.g:
            self.node_index[node] = index
            self.node_index_reversed[index] = node
            index += 1

    def fetch_batch(self, batch_size=16, K=10, edge_sampling='atlas', node_sampling='atlas'):
        """
        ����ѵ�������������ڵ�ͱ�
        """
        if edge_sampling == 'numpy':
            edge_batch_index = np.random.choice(self.num_of_edges, size=batch_size, p=self.edge_distribution)
        elif edge_sampling == 'atlas':
            edge_batch_index = []
            node_batch_index = self.node_sampling.sampling(batch_size)
            for index in node_batch_index:
                adjs = self.g[self.node_index_reversed[index]]
                while True:
                    adj_local_index = np.random.randint(0, len(adjs))
                    adj_node = adjs[adj_local_index]
                    if adj_node in self.node_index:
                        adj_index = self.node_index[adj_node]
                        edge_batch_index.append((index, adj_index))
                        break
        elif edge_sampling == 'uniform':
            edge_batch_index = []
            node_batch_index = np.random.randint(0, self.num_of_nodes, size=batch_size)
            for index in node_batch_index:
                adjs = self.g[self.node_index_reversed[index]]
                while True:
                    adj_local_index = np.random.randint(0, len(adjs))
                    adj_node = adjs[adj_local_index]
                    if adj_node in self.node_index:
                        adj_index = self.node_index[adj_node]
                        edge_batch_index.append((index, adj_index))
                        break
        u_i = []
        u_j = []
        label = []
        for edge in edge_batch_index:
            u_i.append(edge[0])
            u_j.append(edge[1])
            label.append(1)
            for i in range(K):
                while True:
                    if node_sampling == 'numpy':
                        negative_node_index = np.random.choice(self.num_of_nodes, p=self.node_negative_distribution)
                    elif node_sampling == 'atlas':
                        negative_node_index = self.node_sampling.sampling()
                    elif node_sampling == 'uniform':
                        negative_node_index = np.random.randint(0, self.num_of_nodes)
                    if self.node_index_reversed[negative_node_index] not in \
                            self.g[self.node_index_reversed[edge[0]]] \
                            and self.node_index_reversed[edge[0]] not in \
                            self.g[self.node_index_reversed[negative_node_index]]:
                        break
                u_i.append(edge[0])
                u_j.append(negative_node_index)
                label.append(-1)
        return u_i, u_j, label

    def embedding_mapping(self, embedding):
        """
        ������: ��ȡ�����ڵ��embedding
        """
        def generate():
            """������
            """
            for node in self.g:
                yield " ".join([node] + list(map(str, embedding[self.node_index[node]])))
        return generate()

class AliasSampling(object):
    """
    # Reference: https://en.wikipedia.org/wiki/Alias_method
    """
    def __init__(self, prob):
        """
        init
        """
        self.n = len(prob)
        self.U = np.array(prob) * self.n
        self.K = [i for i in range(len(prob))]
        overfull, underfull = [], []
        for i, U_i in enumerate(self.U):
            if U_i > 1:
                overfull.append(i)
            elif U_i < 1:
                underfull.append(i)
        while len(overfull) and len(underfull):
            i, j = overfull.pop(), underfull.pop()
            self.K[j] = i
            self.U[i] = self.U[i] - (1 - self.U[j])
            if self.U[i] > 1:
                overfull.append(i)
            elif self.U[i] < 1:
                underfull.append(i)

    def sampling(self, n=1):
        """
        ��������
        """
        x = np.random.rand(n)
        i = np.floor(self.n * x)
        y = self.n * x - i
        i = i.astype(np.int32)
        res = [i[k] if y[k] < self.U[i[k]] else self.K[i[k]] for k in range(n)]
        if n == 1:
            return res[0]
        else:
            return res

