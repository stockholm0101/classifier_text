#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/08/13 20:52:46
Desc  :
"""
from graph import Graph
from sdne import Sdne
import numpy as np
import scipy.io as sio

import sys
import time
import copy
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import conf.conf as conf


def write_embedding_tofile(embedding, file_name):
    """
    д embeding ���ļ�
    """
    with open(file_name, "w+", encoding="gbk") as f:
        for line in embedding:
            f.write("%s\n" % (" ".join(list(map(str, line)))))

class ARGS(object):
    """
    ������,����ģ��ѵ���ĸ��ֲ���
    """

    def __init__(self, input, output, struct=[-1, 1000, 64], alpha=100,
                gamma=1, reg=1, beta=10, batch_size=64, epochs_limit=50,
                learning_rate=0.01, dbn_init=True, dbn_epochs=2,
                dbn_batch_size=64, dbn_learning_rate=0.1, ng_sample_ratio=0.0,
                sparse_dot=False, restore_model=False):
        self.train_graph_file = input
        self.output_path = output
        self.struct = struct
        self.alpha = alpha
        self.gamma = gamma
        self.reg = reg
        self.beta = beta
        self.batch_size = batch_size
        self.epochs_limit = epochs_limit
        self.learning_rate = learning_rate
        self.dbn_init = True
        self.dbn_epochs = dbn_epochs
        self.dbn_batch_size = dbn_batch_size
        self.dbn_learning_rate = dbn_learning_rate
        self.ng_sample_ratio = ng_sample_ratio
        self.sparse_dot = sparse_dot
        self.restore_model = restore_model

def main():
    """������
    """
    args = ARGS(input=conf.train_path, output=conf.sdne_conf["res_path"], struct=conf.sdne_conf["struct"],
                alpha=conf.sdne_conf["alpha"],
                gamma=conf.sdne_conf["gamma"],
                reg=conf.sdne_conf["reg"],
                beta=conf.sdne_conf["beta"],
                batch_size=conf.sdne_conf["batch_size"],
                epochs_limit=conf.sdne_conf["epochs_limit"],
                learning_rate=conf.sdne_conf["learning_rate"],
                dbn_init=conf.sdne_conf["dbn_init"],
                dbn_epochs=conf.sdne_conf["dbn_epochs"],
                dbn_batch_size=conf.sdne_conf["dbn_batch_size"],
                dbn_learning_rate=conf.sdne_conf["dbn_learning_rate"],
                ng_sample_ratio=conf.sdne_conf["ng_sample_ratio"],
                sparse_dot=conf.sdne_conf["sparse_dot"],
                restore_model=False
                )

    train_graph_data = Graph(args.train_graph_file, args.ng_sample_ratio)
    args.struct[0] = train_graph_data.N
    
    model = Sdne(args)
    model.do_variables_init(train_graph_data)
    embedding = None
    while (True):
        mini_batch = train_graph_data.sample(args.batch_size, do_shuffle = False)
        if embedding is None:
            embedding = model.get_embedding(mini_batch)
        else:
            embedding = np.vstack((embedding, model.get_embedding(mini_batch))) 
        if train_graph_data.is_epoch_end:
            break

    epochs = 0
    batch_n = 0
    
    model.save_model(args.output_path + '/sdne_poch0.model')

    write_embedding_tofile(embedding, args.output_path + '/sdne_embedding.txt')
    print("train start")
    while (True):
        if train_graph_data.is_epoch_end:
            loss = 0
            if epochs % 2 == 0:
                embedding = None
                while (True):
                    mini_batch = train_graph_data.sample(args.batch_size, do_shuffle = False)
                    loss += model.get_loss(mini_batch)
                    if embedding is None:
                        embedding = model.get_embedding(mini_batch)
                    else:
                        embedding = np.vstack((embedding, model.get_embedding(mini_batch))) 
                    if train_graph_data.is_epoch_end:
                        break

                print("Epoch : %d loss : %.3f" % (epochs, loss))
                if epochs % 10 == 0 or epochs == args.epochs_limit:
                    model.save_model(args.output_path + '/sdne_epoch' + str(epochs) + ".model")
                    write_embedding_tofile(embedding, args.output_path + '/sdne_embedding.txt')
            if epochs == args.epochs_limit:
                print("exceed epochs limit terminating")
                break
            epochs += 1
        mini_batch = train_graph_data.sample(args.batch_size)
        loss = model.fit(mini_batch)

    write_embedding_tofile(embedding, args.output_path + '/sdne_embedding.txt')


if __name__ == "__main__":
    os.environ["CUDA_VISIBLE_DEVICES"] = '1'
    main()
