#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/04/29 16:43:06
Desc  :   
"""
import os
import sys

_cur_dir = os.path.dirname(os.path.abspath(__file__))
#train_path = _cur_dir + "/../../data/merge.adjlist"
#train_path = _cur_dir + "/../../data/test.adjlist"
train_path = _cur_dir + "/../../data/id_edges.txt"
#res_path = _cur_dir + "/../../data/node2vec_emb.txt"
res_path = _cur_dir + "/../../data/line_emb.txt"

deepwalk_conf = {"format": "adjlist",
                 "max_memory_data_size": 0,
                 "number_walks": 20,
                 "representation_size": 64,
                 "walk_length": 20,
                 "window_size": 10,
                 "workers": 1,
                 }

node2vec_conf = {"format": "adjlist",
                 "max_memory_data_size": 0,
                 "number_walks": 10,
                 "representation_size": 64,
                 "walk_length": 10,
                 "window_size": 5,
                 "workers": 10,
                 "p": 0.5,
                 "q": 1,
                 }

line_conf = {"embedding_dim": 64,
                 "batch_size": 128,
                 "K": 5,
                 "proximity": "second-order",
                 "learning_rate": 0.025,
                 "num_batches": 10000,
                 }

# edges �ļ�,�ڵ���Ҫ���,��Ŵ�0��ʼ
sdne_conf = {"struct": [-1, 1000, 64],
                 "alpha": 100,
                 "gamma": 1,
                 "reg": 1,
                 "beta": 10,
                 "batch_size": 64,
                 "epochs_limit": 50,
                 "learning_rate": 0.01,
                 "dbn_init": True,
                 "dbn_epochs": 2,
                 "dbn_batch_size": 64,
                 "dbn_learning_rate": 0.1,
                 "ng_sample_ratio": 0.0,
                 "sparse_dot": True,
                 "res_path": _cur_dir + "/../../data"
                 }

model_type = "deepwalk"


#��������
# users.embeddings
evaluate_para = {"emb_file": _cur_dir + "/../../data/node2vec_emb.txt",
                 "clust_label_file": _cur_dir + "/../../data/clust_labels",
                 "seed_user_file": _cur_dir + "/../../data/risk_users_06",
                 "relation_file": _cur_dir + "/../../data/relation_file",
                 "top_k": 5,
                 "risk_userid_file": _cur_dir + "/../../data/risk_users_07_5days_in6"
                 }
