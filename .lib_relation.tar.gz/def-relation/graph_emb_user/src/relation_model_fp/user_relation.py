#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/07/23 13:03:41
Desc  :   �ھ�Ƶ���,ͨ�������˻���ȡ���������˻�
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import codecs
import os
import sys

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
sys.path.append("%s/../relation_model_fp/" % _cur_dir)
import fp_growth


def load_data(file_name):
    """����items
    [IN] file_name : string  items����ļ�
    [OUT] items : [[userid1, userid2, userid3, ...], ...]    ������
    """
    items = []
    with codecs.open(file_name, "r+", encoding="gbk") as f:
        for line in f:
            parts = line.strip("\n").split("\t")
            key = parts[0]
            if not key:
                continue
            userids = list(set(parts[1].split("|")))
            items.append(userids)
    return items


if __name__ == "__main__":
    """
    �ھ�Ƶ�������ȡ�������
    """
    parser = argparse.ArgumentParser(description="get_relation_fp_res")
    parser.add_argument("--item_file", action="store", required=True,
                        help="items(���ֵ��˻�)", default="None")
    parser.add_argument("--min_sup", action="store", required=True,
                        help="��С֧�ֶ�", default="None")
    parser.add_argument("--relation_res_file", action="store", required=True,
                        help="�����������ļ�", default="None")

    args = parser.parse_args()

    item_file = args.item_file
    min_sup = int(args.min_sup)
    relation_res_file = args.relation_res_file

    data_iter = load_data(item_file)
    res = fp_growth.find_frequent_itemsets(data_iter, minimum_support=min_sup, include_support=True)
    sys.stderr.write("fp_growth.find_frequent_itemsets end")

    with codecs.open(relation_res_file, "w+", "gb18030") as f:
        for users in res:
            f.write("%s\t%s\n" % ("|".join(users[0]), str(users[1])))
