#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/08/31 11:46:43
Desc  :   
"""
import pandas as pd
import time
import datetime 
import numpy as np
from sklearn.cluster import KMeans
import sys
import os
import codecs

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import conf.conf as conf


class Estimater(object):
    """ģ��Ч������
    """
    def __init__(self, evaluate_para, update_cluster, update_relation_users):
        """init
        """
        self.emb_file = evaluate_para["emb_file"]
        self.clust_label_file = evaluate_para["clust_label_file"]
        self.seed_user_file = evaluate_para["seed_user_file"]
        self.top_k = evaluate_para["top_k"]
        self.relation_file = evaluate_para["relation_file"] + "_" + str(self.top_k)
        self.risk_userid_file = evaluate_para["risk_userid_file"]

        self.update_cluster = update_cluster
        self.update_relation_users = update_relation_users

    def exe(self):
        """��ȡembeddind�����ࡢͨ�������˻�����������
        """
        self.embedding = self.read_data()

        t1 = time.time()
        print("kmeans start")
        self.labels = self.clust()
        print("kmeans end, cost %s s" % (str(time.time() - t1)))

        self.seed_users = self.load_user("seed_user")
        self.relation_userid = self.get_relation_users()

        self.risk_userid = self.load_user("risk_userid")
        pre, recall = self.esti()
        print("%s sim relation, pre: %f, recall: %f" % (str(conf.evaluate_para["top_k"]), pre, recall))

    def read_data(self):
        """��ȡembedding �ļ�
        """
        read_time = pd.read_csv(self.emb_file, sep = " ", header = None)
        read_time.index = read_time[0]
        read_time.drop(0, axis = 1, inplace = True)
        return read_time
    
    def clust(self):
        """����
        """
        if self.update_cluster:
            kmeans = KMeans(n_clusters=1000, random_state=9).fit(self.embedding)
            labels = kmeans.labels_
            self.write_to_file(self.clust_label_file, labels)
            print("write_labels_to_file end")
        else:
            labels = self.load_labels()
            print("load labels  from file end")
        return labels
    
    def load_user(self, type_file):
        """���ļ�����userid
        [IN] type_file : string   ָ�������ļ����� seed_user or risk_userid
        """
        user_file = ""
        user_set = set()
        if type_file == "seed_user":
            user_file = self.seed_user_file
        elif type_file == "risk_userid":
            user_file = self.risk_userid_file
        elif type_file == "relation_user":
            user_file = self.relation_file
        else:
            print("type_file not in seed_user or risk_userid")
            return user_set

        with codecs.open(user_file, "r+", encoding="gb18030") as f:
            for line in f:
                parts = line.strip("\n").split("\t")
                seed_user = int(parts[0])
                user_set.add(seed_user)
        return user_set
    
    def get_relation_users(self):
        """��ȡ�����˻�
        [IN] self.labels      ��  list  �����ǩ
             self.embedding :   dataframe  �˻�embedding����
             self.seed_users  :   set   �����˻�����
             self.top_k       ��  int   ѡȡtop����
        [OUT] relation_users :  set  �����˻�����
        """
        if not self.update_relation_users:
            try:
                relation_users = self.load_user("relation_user")
                print("load relation_users from file")
            except Exception as e:
                print("relation_user file not exits")
                print(e)
            return relation_users

        relation_users = set()
        for user in self.seed_users:
            one_seed_label = self.labels[self.embedding.index == user]
            if len(one_seed_label) <= 0:
                continue
            one_seed_relation_user = self.embedding[self.labels == one_seed_label[0]]
    
            dis_dic = {}
            for index in one_seed_relation_user.index:
                dist = np.linalg.norm(one_seed_relation_user.loc[index, :].values - self.embedding.loc[user, :].values)
                dis_dic[index] = dist
    
            items = np.array(sorted(dis_dic.items(), key = lambda a:a[1], reverse=False))[:self.top_k, 0]
    
            top_users = set(items)
    
            relation_users = relation_users | top_users

        self.write_to_file(self.relation_file, relation_users)
        print("write_relation_users_to_file end")
    
        return set(map(int, relation_users))
    
    def write_to_file(self, file_name, relation_userid):
        """write_to_file
        """
        with codecs.open(file_name, "w+") as f:
            for user in relation_userid:
                f.write("%s\n" % (str(user)) )
    
    def load_labels(self):
        """�����˻�����labels
        """
        label_list = []
        with codecs.open(self.clust_label_file, "r+", encoding="gb18030") as f:
            for line in f:
                parts = line.strip("\n").split("\t")
                label = int(parts[0])
                label_list.append(label)
        return np.array(label_list)
    
    def esti(self):
        """����׼��
        [IN] self.relation_userid : set  �����˻���
             self.risk_userid     : set  �����˻�����-���Լ�
        """
        if len(self.relation_userid) == 0:
            return 0.0, 0.0
        common = self.relation_userid & self.risk_userid
        pre = len(common)/float(len(self.relation_userid))
        recall = len(common)/float(len(self.risk_userid))
        return pre, recall

if __name__ == "__main__":
    estimater = Estimater(conf.evaluate_para, update_cluster=False, update_relation_users=True)
    estimater.exe()
