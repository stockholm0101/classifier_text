#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/08/11 17:34:27
Desc  :   
"""
import codecs
import os
import sys
import argparse

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % (_cur_dir))
from relation_model_rule.relation_common_edge import EntityEdge


def produce_adj(entity_edge, preprocess_res_file):
    """�����ڽӾ���
    [IN] entity_edge : EntityEdge ʵ��-�˻�������
         preprocess_res_file ��string  �ڽӾ������ļ�
    """
    with codecs.open(preprocess_res_file, "w+", encoding="gb18030") as f:
        for userid in entity_edge.userid_entity_dict:
            entitys = entity_edge.userid_entity_dict[userid]
            for entity in entitys:
                userids = entity_edge.entity_userid_dict[entity]
                userids = list(set(userids) - {userid})
                if userids:
                    f.write("%s %s\n" % (userid, " ".join(userids)))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="preprocess_adj")
    parser.add_argument("--entity_user_file", action="store", required=True, 
                        help="ԭʼ�ļ�", default="None")
    parser.add_argument("--preprocess_res_file", action="store", required=True,
                        help="�ڽӾ������ļ�", default="None")

    args = parser.parse_args()

    entity_user_file = args.entity_user_file
    preprocess_res_file = args.preprocess_res_file

    entity_edge = EntityEdge(entity_user_file)
    produce_adj(entity_edge, preprocess_res_file)
