#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/09/16 17:03:39
Desc  :   
"""
import sys
import json
import codecs
import argparse

def preprocess(user_adj_file, user_edges_file, user_dic_file):
    """
    �����Ա�Ϊά�ȵ��ļ�,�ڵ�ʹ�ñ��
    """
    count = 0
    dic_user = {}
    with codecs.open(user_adj_file, "r+") as fr, \
        codecs.open(user_edges_file, "w+") as fw:
        for line in fr:
            parts = line.strip("\n").split(" ")

            userid = parts[0]
            dic_user[userid] = count

            adj_list = parts[1:]
            for adj in adj_list:
                if int(adj) < int(userid):
                    fw.write("%d %d\n" % (dic_user[userid], dic_user[adj]))
            count += 1
    print(count)

    with codecs.open(user_dic_file, "w+") as f:
        json.dump(dic_user, f)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="preprocess_edges")
    parser.add_argument("--user_adj_file", action="store", required=True, 
                        help="�ڽӾ����ļ�", default="None")
    parser.add_argument("--user_edges_file", action="store", required=True,
                        help="�ڽӾ������ļ�", default="None")
    parser.add_argument("--user_dic_file", action="store", required=True,
                        help="�˻�ID�����IDӳ���ļ�", default="None")

    args = parser.parse_args()

    user_adj_file = args.user_adj_file
    user_edges_file = args.user_edges_file
    user_dic_file = args.user_dic_file

    preprocess(user_adj_file, user_edges_file, user_dic_file)
