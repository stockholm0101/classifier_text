#!/usr/bin/env python
# -*- coding: gbk -*-
"""
@author: zhubenchang@baidu.com
@description: Graph utilities.
"""

import logging
import random
import sys
from collections import defaultdict, Iterable
from glob import glob
from io import open
from itertools import product, permutations
from os import path
from random import shuffle
from time import time

from scipy.io import loadmat
from scipy.sparse import issparse
from six import iterkeys
from six.moves import range, zip, zip_longest
import numpy as np

logger = logging.getLogger("node2vec")

LOGFORMAT = "%(asctime).19s %(levelname)s %(filename)s: %(lineno)s %(message)s"


class Graph(defaultdict):
    """Efficient basic implementation of nx `Graph'  Undirected graphs with self loops"""

    def __init__(self):
        super(Graph, self).__init__(list)
        self.alias_edges = {}

    def nodes(self):
        """�ڵ�
        """
        return self.keys()

    def adjacency_iter(self):
        """��ȡitems
        """
        return self.iteritems()

    def subgraph(self, nodes={}):
        """��ͼ
        """
        subgraph = Graph()

        for n in nodes:
            if n in self:
                subgraph[n] = [x for x in self[n] if x in nodes]

        return subgraph

    def make_undirected(self):
        """����
        """

        t0 = time()

        for v in list(self):
            for other in self[v]:
                if v != other:
                    self[other].append(v)

        t1 = time()
        logger.info('make_directed: added missing edges {}s'.format(t1 - t0))

        self.make_consistent()
        return self

    def make_consistent(self):
        """consistent
        """
        t0 = time()
        for k in iterkeys(self):
            self[k] = list(sorted(set(self[k])))

        t1 = time()
        logger.info('make_consistent: made consistent in {}s'.format(t1 - t0))

        self.remove_self_loops()

        return self

    def remove_self_loops(self):
        """remove_self form self_adj
        """

        removed = 0
        t0 = time()

        for x in self:
            if x in self[x]:
                self[x].remove(x)
                removed += 1

        t1 = time()

        logger.info('remove_self_loops: removed {} loops in {}s'.format(removed, (t1 - t0)))
        return self

    def check_self_loops(self):
        """ check
        """
        for x in self:
            for y in self[x]:
                if x == y:
                    return True

        return False

    def has_edge(self, v1, v2):
        """ �ж����ޱ�����
        """
        if v2 in self[v1] or v1 in self[v2]:
            return True
        return False

    def degree(self, nodes=None):
        """����ڵ�Ķ�
        """
        if isinstance(nodes, Iterable):
            return {v: len(self[v]) for v in nodes}
        else:
            return len(self[nodes])

    def order(self):
        "Returns the number of nodes in the graph"
        return len(self)

    def number_of_edges(self):
        "Returns the number of nodes in the graph"
        return sum([self.degree(x) for x in self.keys()]) / 2

    def number_of_nodes(self):
        "Returns the number of nodes in the graph"
        return self.order()

    def random_walk_simple(self, path_length, p, q, rand=random.Random(), start=None):
        """ Returns a truncated random walk.

            path_length: Length of the random walk.
            p: probability of BFS.
            q: probability of DFS
            start: the start node of the random walk.
        """
        G = self
        if start:
            path = [start]
        else:
            # Sampling is uniform w.r.t V, and not w.r.t E
            path = [rand.choice(list(G.keys()))]

        while len(path) < path_length:
            cur = path[-1]
            if len(G[cur]) > 0:
                if len(path) == 1:
                    path.append(rand.choice(G[cur]))
                else:
                    if len(G[cur]) > 10:
                        path.append(rand.choice(G[cur]))
                    else:
                        prev = path[-2]
                        P, M, Q = [], [], []
                        for dst_nbr in G[cur]:
                            if dst_nbr == prev:
                                P.append(dst_nbr)
                            elif G.has_edge(dst_nbr, prev):
                                M.append(dst_nbr)
                            else:
                                Q.append(dst_nbr)
                        select = {0:P, 1:M, 2:Q}

                        unnormalized_probs = [len(P)/float(p), float(len(M)), len(Q)/float(q)]
                        norm_const = sum(unnormalized_probs)
                        normalized_probs =  [float(u_prob)/norm_const for u_prob in unnormalized_probs]

                        normalized_probs_accu = [normalized_probs[0]]
                        for index in range(1, len(normalized_probs), 1):
                            normalized_probs_accu.append(normalized_probs_accu[index - 1] + normalized_probs[index])

                        rand_pro = np.random.rand()
                        key_select = 0
                        for index, pro in enumerate(normalized_probs_accu):
                            if rand_pro <= pro:
                                key_select = index
                                break;
                        pool_select = select[key_select]
                        path.append(rand.choice(pool_select))
            else:
                break
        return [str(node) for node in path]

    def random_walk(self, path_length, p, q, rand=random.Random(), start=None):
        """ Returns a truncated random walk.

            path_length: Length of the random walk.
            p: probability of BFS.
            q: probability of DFS
            start: the start node of the random walk.
        """
        G = self
        if start:
            path = [start]
        else:
            # Sampling is uniform w.r.t V, and not w.r.t E
            path = [rand.choice(list(G.keys()))]

        while len(path) < path_length:
            cur = path[-1]
            if len(G[cur]) > 0:
                if len(path) == 1:
                    path.append(rand.choice(G[cur]))
                else:
                    prev = path[-2]
                    edge = str(prev) + "|" + str(cur)
                    if edge in self.alias_edges:
                        J, Q = self.alias_edges[edge]
                    else:
                        J, Q = self.get_alias_edge(prev, cur, p, q)
                        self.alias_edges[edge] = (J, Q)
                    try:
                        next = G[cur][alias_draw(J, Q)]
                    except Exception as e:
                        print(e)
                        print("error", prev, cur, alias_draw(J, Q), len(G[cur]))
                        print(len(J), len(Q))
                        exit()
                    path.append(next)
            else:
                break
        return [str(node) for node in path]

    def get_alias_edge(self, src, dst, p, q):
        """
        Get the alias edge setup lists for a given edge.
        """
        G = self

        unnormalized_probs = []
        for dst_nbr in G[dst]:
            if dst_nbr == src:
                unnormalized_probs.append(1 / float(p))
            elif G.has_edge(dst_nbr, src):
                unnormalized_probs.append(1.0)
            else:
                unnormalized_probs.append(1 / float(q))
        norm_const = sum(unnormalized_probs)
        normalized_probs =  [float(u_prob)/norm_const for u_prob in unnormalized_probs]

        return alias_setup(normalized_probs)

def alias_setup(probs):
    """
    Compute utility lists for non-uniform sampling from discrete distributions.
    Refer to https://hips.seas.harvard.edu/blog/2013/03/03/the-alias-method-efficient-sampling-with-many-discrete-outcomes/
    for details
    """
    K = len(probs)
    q = np.zeros(K)
    J = np.zeros(K, dtype=np.int)
    
    smaller = []
    larger = []
    for kk, prob in enumerate(probs):
        q[kk] = K * prob
        if q[kk] < 1.0:
            smaller.append(kk)
        else:
            larger.append(kk)
    
    while len(smaller) > 0 and len(larger) > 0:
        small = smaller.pop()
        large = larger.pop()
    
        J[small] = large
        q[large] = q[large] + q[small] - 1.0
        if q[large] < 1.0:
            smaller.append(large)
        else:
            larger.append(large)
    
    return J, q

def alias_draw(J, q):
    """
    Draw sample from a non-uniform discrete distribution using alias sampling.
    """
    K = len(J)
    
    kk = int(np.floor(np.random.rand()*K))
    if np.random.rand() < q[kk]:
        return kk
    else:
        return J[kk]

# TODO add build_walks in here
def build_node2vec_corpus(G, num_paths, path_length, p=1, q=1,
                          rand=random.Random(0)):
    """ͨ��������߹���ѵ������
    """
    walks = []

    nodes = list(G.nodes())

    for cnt in range(num_paths):
        rand.shuffle(nodes)
        for node in nodes:
            #walks.append(G.random_walk(path_length, p=p, q=q, rand=rand, start=node))
            walks.append(G.random_walk_simple(path_length, p=p, q=q, rand=rand, start=node))

    return walks


def build_node2vec_corpus_iter(G, num_paths, path_length, p=1, q=1,
                               rand=random.Random(0)):
    """������-ͨ��������߹���ѵ������
    """
    walks = []

    nodes = list(G.nodes())

    for cnt in range(num_paths):
        rand.shuffle(nodes)
        for node in nodes:
            #yield G.random_walk(path_length, p=p, q=q, rand=rand, start=node)
            yield G.random_walk_simple(path_length, p=p, q=q, rand=rand, start=node)


def clique(size):
    """ clique
    """
    return from_adjlist(permutations(range(1, size + 1)))


# http://stackoverflow.com/questions/312443/how-do-you-split-a-list-into-evenly-sized-chunks-in-python
def grouper(n, iterable, padvalue=None):
    "grouper(3, 'abcdefg', 'x') --> ('a','b','c'), ('d','e','f'), ('g','x','x')"
    return zip_longest(*[iter(iterable)] * n, fillvalue=padvalue)


def parse_adjacencylist(f):
    """ ��ʽ��
    """
    adjlist = []
    for l in f:
        if l and l[0] != "#":
            introw = [int(x) for x in l.strip().split()]
            row = [introw[0]]
            row.extend(set(sorted(introw[1:])))
            adjlist.extend([row])

    return adjlist


def parse_adjacencylist_unchecked(f):
    """ ��ʽ��
    """
    adjlist = []
    for l in f:
        if l and l[0] != "#":
            adjlist.extend([[int(x) for x in l.strip().split()]])

    return adjlist


def load_adjacencylist(file_, undirected=True, chunksize=10000, unchecked=False):
    """ ���ļ������ڽӾ���
    """
    if unchecked:
        parse_func = parse_adjacencylist_unchecked
        convert_func = from_adjlist_unchecked
    else:
        parse_func = parse_adjacencylist
        convert_func = from_adjlist

    adjlist = []

    t0 = time()

    total = 0
    with open(file_) as f:
        for idx, adj_chunk in enumerate(map(parse_func, grouper(int(chunksize), f))):
            adjlist.extend(adj_chunk)
            total += len(adj_chunk)

    t1 = time()

    logger.info('Parsed {} edges with {} chunks in {}s'.format(total, idx, t1 - t0))

    t0 = time()
    G = convert_func(adjlist)
    t1 = time()

    logger.info('Converted edges to graph in {}s'.format(t1 - t0))

    if undirected:
        t0 = time()
        G = G.make_undirected()
        t1 = time()
        logger.info('Made graph undirected in {}s'.format(t1 - t0))

    return G


def load_edgelist(file_, undirected=True):
    """���ձ� ����ͼ
    """
    G = Graph()
    with open(file_) as f:
        for l in f:
            x, y = l.strip().split()[:2]
            x = int(x)
            y = int(y)
            G[x].append(y)
            if undirected:
                G[y].append(x)

    G.make_consistent()
    return G


def load_matfile(file_, variable_name="network", undirected=True):
    """ from matfile ����
    """
    mat_varables = loadmat(file_)
    mat_matrix = mat_varables[variable_name]

    return from_numpy(mat_matrix, undirected)


def from_networkx(G_input, undirected=True):
    """ from networkx ����
    """
    G = Graph()

    for idx, x in enumerate(G_input.nodes()):
        for y in iterkeys(G_input[x]):
            G[x].append(y)

    if undirected:
        G.make_undirected()

    return G


def from_numpy(x, undirected=True):
    """ from numpy ����
    """
    G = Graph()

    if issparse(x):
        cx = x.tocoo()
        for i, j, v in zip(cx.row, cx.col, cx.data):
            G[i].append(j)
    else:
        raise Exception("Dense matrices not yet supported.")

    if undirected:
        G.make_undirected()

    G.make_consistent()
    return G


def from_adjlist(adjlist):
    """ͨ���ڽӾ��󹹽�ͼ
    """
    G = Graph()

    for row in adjlist:
        node = row[0]
        neighbors = row[1:]
        G[node] = list(sorted(set(neighbors)))

    return G


def from_adjlist_unchecked(adjlist):
    """ ͨ�������ڽӾ��󹹽�ͼ
    """
    G = Graph()

    for row in adjlist:
        node = row[0]
        neighbors = row[1:]
        G[node] = neighbors

    return G

class WalksIter(object):
    """������߽����ȡ��- ������
    """

    def __init__(self, walks):
        self.walks = walks

    def __iter__(self):
        return self.walks
