#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/08/13 20:52:46
Desc  :
"""
import logging
import os
import random
import sys
from argparse import ArgumentParser, FileType, ArgumentDefaultsHelpFormatter
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from io import open
from multiprocessing import cpu_count

import graph
import psutil
import walks as serialized_walks
from gensim.models import Word2Vec
from six import iteritems
from six import text_type as unicode
from six.moves import range
from skipgram import Skipgram

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import conf.conf as conf

p = psutil.Process(os.getpid())
try:
    p.set_cpu_affinity(list(range(cpu_count())))
except AttributeError:
    try:
        p.cpu_affinity(list(range(cpu_count())))
    except AttributeError:
        pass

logger = logging.getLogger(__name__)
LOGFORMAT = "%(asctime).19s %(levelname)s %(filename)s: %(lineno)s %(message)s"


def debug(type_, value, tb):
    """debug
    """
    if hasattr(sys, 'ps1') or not sys.stderr.isatty():
        sys.__excepthook__(type_, value, tb)
    else:
        import traceback
        import pdb
        traceback.print_exception(type_, value, tb)
        print(u"\n")
        pdb.pm()


def process(args):
    """����ͼ�ṹ,��ѵ��ģ��
    """
    if args.format == "adjlist":
        G = graph.load_adjacencylist(args.input, undirected=args.undirected)
    elif args.format == "edgelist":
        G = graph.load_edgelist(args.input, undirected=args.undirected)
    elif args.format == "mat":
        G = graph.load_matfile(args.input, variable_name=args.matfile_variable_name, undirected=args.undirected)
    else:
        raise Exception("Unknown file format: '%s'.  Valid formats: 'adjlist', 'edgelist', 'mat'" % args.format)

    print("Number of nodes: {}".format(len(G.nodes())))
    num_walks = len(G.nodes()) * args.number_walks
    print("Number of walks: {}".format(num_walks))
    data_size = num_walks * args.walk_length
    print("Data size (walks*length): {}".format(data_size))

    if data_size < args.max_memory_data_size:
        print("Walking...")
        walks = graph.build_node2vec_corpus(G, num_paths=args.number_walks, \
                path_length=args.walk_length, p=args.p, q=args.q, rand=random.Random(args.seed))
        print("Training...")
        model = Word2Vec(walks, size=args.representation_size, window=args.window_size,
                         min_count=0, sg=1, hs=1, workers=args.workers)
    else:
        print("Data size {} is larger than limit (max-memory-data-size: {}).  "
              "Dumping walks to disk.".format(data_size, args.max_memory_data_size))
        print("Walking...")

        walks_filebase = args.output + ".walks"
        walk_files = serialized_walks.write_walks_to_disk(G, walks_filebase, num_paths=args.number_walks,
                                                          path_length=args.walk_length, alpha=0,
                                                          rand=random.Random(args.seed),
                                                          num_workers=args.workers)

        print("Counting vertex frequency...")
        if not args.vertex_freq_degree:
            vertex_counts = serialized_walks.count_textfiles(walk_files, args.workers)
        else:
            # use degree distribution for frequency in tree
            vertex_counts = G.degree(nodes=G.iterkeys())

        print("Training...")
        walks_corpus = serialized_walks.WalksCorpus(walk_files)
        model = Skipgram(sentences=walks_corpus, vocabulary_counts=vertex_counts,
                         size=args.representation_size,
                         window=args.window_size, min_count=0, trim_rule=None, workers=args.workers)

    model.wv.save_word2vec_format(args.output)


class ARGS():
    """������,����ģ��ѵ���ĸ��ֲ���"""

    def __init__(self, input, output, p=1, q=1, number_walks=10, representation_size=64, walk_length=20,
                window_size=5, workers=1,
                 log="INFO", debug=False, format="adjlist", matfile_variable_name="network",
                 max_memory_data_size=1000000000,
                 seed=0, undirected=True):
        self.log = log
        self.debug = debug
        self.format = format
        self.matfile_variable_name = matfile_variable_name
        self.max_memory_data_size = max_memory_data_size
        self.seed = seed
        self.undirected = undirected

        self.input = input
        self.number_walks = number_walks
        self.output = output
        self.p = p
        self.q = q
        self.representation_size = representation_size
        self.walk_length = walk_length
        self.window_size = window_size
        self.workers = workers


def main():
    """������
    """
    args = ARGS(input=conf.train_path, output=conf.res_path, p=conf.node2vec_conf["p"], q=conf.node2vec_conf["q"],
                number_walks=conf.node2vec_conf["number_walks"],
                representation_size=conf.node2vec_conf["representation_size"],
                walk_length=conf.node2vec_conf["walk_length"],
                window_size=conf.node2vec_conf["window_size"], workers=conf.node2vec_conf["workers"])

    numeric_level = getattr(logging, args.log.upper(), None)
    logging.basicConfig(format=LOGFORMAT)
    logger.setLevel(numeric_level)

    if args.debug:
        sys.excepthook = debug

    process(args)


if __name__ == "__main__":
    sys.exit(main())
