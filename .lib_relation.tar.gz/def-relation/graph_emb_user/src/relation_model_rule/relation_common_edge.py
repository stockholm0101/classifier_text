#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/07/23 19:39:34
Desc  :   ��������ģ�͵ı�
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import sys

_cur_dir = os.path.dirname(os.path.abspath(__file__))


class EntityEdge(object):
    """
    �������ӱ�����
    """

    def __init__(self, file_path="", entity_site=1):
        """
        ��ʼ��
        """
        self.userid_entity_file = file_path
        self.entity_site = entity_site

        self.userid_entity_dict = self.load_userid_entity(self.userid_entity_file)
        self.entity_userid_dict = self.build_entity_userid()

    def load_userid_entity(self, file_path):
        """
        �����˻�-ʵ������
        [IN] file_path : string  ����ʵ���ļ���
        [OUT] userid_entity : dict  {userid : set(entity...),...}
        """
        userid_entity = dict()
        if file_path and os.path.exists(file_path):
            with open(file_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    terms = line.split("\t")
                    if len(terms) <= self.entity_site:
                        continue
                    userid = terms[0]
                    entity = terms[self.entity_site]
                    if userid not in userid_entity:
                        userid_entity[userid] = set([entity])
                    else:
                        userid_entity[userid].add(entity)
        else:
            sys.stderr.write("%s is not exists\n" % (file_path))
        print('userid entity size: %s' % len(userid_entity))
        return userid_entity

    def build_entity_userid(self):
        """
        ͨ���˻�-ʵ�幹��ʵ��-�˻��Ĺ�����
        [IN] self
        [OUT] entity_userid : dict  {entity : set(userid...), ...}
        """
        entity_userid = dict()
        for key, value in self.userid_entity_dict.items():
            for v in value:
                if v not in entity_userid:
                    entity_userid[v] = set([key])
                else:
                    entity_userid[v].add(key)
        print('entity userid size: %s' % len(entity_userid))
        return entity_userid

    def get_relation_userids(self, userid):
        """
        ��ȡָ���˻��Ĺ����˻����
        [IN] userid : string  ��������ԭʼ�˻�ID
        [OUT] relation_userids : set  set(relation_userid, ...)
        """
        relation_userids = set()
        if userid in self.userid_entity_dict:
            entitys = self.userid_entity_dict[userid]
            for entity in entitys:
                if entity in self.entity_userid_dict:
                    for u in self.entity_userid_dict[entity]:
                        # ���˵���ͬ�˻�id������
                        if u == userid:
                            continue
                        relation_userids.add(u)
        return relation_userids
