#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/07/23 13:03:41
Desc  :   ͨ�������˻���ȡ���������˻�
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import codecs
import os
import sys

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
sys.path.append("%s/../relation_model_rule/" % _cur_dir)
from relation_common_edge import EntityEdge

userid_device_file = "%s/../../data/user_device_ip_6month.txt" % _cur_dir
userid_ip_file = "%s/../../data/user_device_ip_6month.txt" % _cur_dir
userid_client_file = "%s/../../data/user_client_6month.txt" % _cur_dir
userid_acs_info_file = "%s/../../data/user_org_acs_info_6month.txt" % _cur_dir


class UserRelation(object):
    """
    �˻�����
    """

    def __init__(self, user_file="",
                 userid_device_file=userid_device_file,
                 userid_ip_file=userid_ip_file,
                 userid_client_file=userid_client_file,
                 userid_acs_info_file=userid_acs_info_file
                 ):
        """
        ��ʼ��
        """
        self.user_file = user_file
        self.device_edge = EntityEdge(userid_device_file, 3)
        self.ip_edge = EntityEdge(userid_ip_file, 2)
        self.client_edge = EntityEdge(userid_client_file, 2)
        self.acs_edge = EntityEdge(userid_acs_info_file, 3)
        self.seed_user_dict = self.load_userids(user_file)

    @staticmethod
    def load_userids(user_file):
        """
        ���������˻�����
        [in] user_file, format:7��  userid, Υ������, �Ƿ�A��, ��Դ, ��עռλ, ���ʱ��, �Ƿ���
        [out] user_dict, dict
        """
        user_dict = dict()
        if user_file and os.path.exists(user_file):
            with codecs.open(user_file, 'r', encoding='gb18030') as f:
                for line in f:
                    line = line.strip()
                    if line.startswith("#"):
                        continue
                    terms = line.split("\t")
                    if len(terms) < 6:
                        continue

                    userid = terms[0]
                    risktype = terms[1]
                    is_A = terms[2]
                    cvremark = terms[4]
                    audit_time = terms[5]
                    user_dict[userid] = [risktype, is_A, cvremark, audit_time]
        print("seed_risk user size are %d" % (len(user_dict)))
        return user_dict

    def get_relation_feature(self):
        """
        ��ȡ��������
        [in] user_file
        [out] relation_feature_dict
        """
        relation_feature_dict = dict()
        for userid in self.seed_user_dict:
            device_relation_userids = self.device_edge.get_relation_userids(
                userid)
            ip_relation_userids = self.ip_edge.get_relation_userids(userid)
            client_relation_userids = self.client_edge.get_relation_userids(
                userid)
            acs_relation_userids = self.acs_edge.get_relation_userids(
                userid)
            relation_feature_dict[userid] = {"device_relation_userids": device_relation_userids,
                                             "ip_relation_userids": ip_relation_userids,
                                             "client_relation_userids": client_relation_userids,
                                             "acs_relation_userids": acs_relation_userids
                                             }
        print("relation_feature size are %d" % (len(relation_feature_dict)))
        return relation_feature_dict

    def process_relation_feature(self, relation_feature_dict):
        """
        ������������
        [in] relation_feature_dict
        [out] relation_dict, format: relation_userid, [[relation_userid, origin_userid, type]]
        """
        relation_dict = dict()
        features = []
        for userid, v in relation_feature_dict.items():
            device_relation_userids = v.get(
                "device_relation_userids", set())
            ip_relation_userids = v.get("ip_relation_userids", set())
            client_relation_userids = v.get(
                "client_relation_userids", set())
            acs_relation_userids = v.get(
                "acs_relation_userids", set())
            # relation_feature_file, format: relation_userid, origin_userid, type
            for relation_userid in device_relation_userids:
                out = [str(relation_userid), str(userid), 'device']
                features.append(out)
            for relation_userid in ip_relation_userids:
                out = [str(relation_userid), str(userid), 'ip']
                features.append(out)
            for relation_userid in client_relation_userids:
                out = [str(relation_userid), str(userid), 'client']
                features.append(out)
            for relation_userid in acs_relation_userids:
                out = [str(relation_userid), str(userid), 'acs']
                features.append(out)
        print("features size:%d " % len(features))

        for terms in features:
            relation_userid = terms[0]
            origin_userid = terms[1]
            type = terms[2]
            if relation_userid not in relation_dict:
                relation_dict[relation_userid] = [terms]
            else:
                relation_dict[relation_userid].append(terms)
        print('relation_dict size: %s' % len(relation_dict))
        return relation_dict

    def relation_grade(self, feature_dict, relation_grade_file):
        """
        ��������ּ�
        [in] feature_dict format: relation_userid, [[relation_userid, origin_userid, type]]
        [out] relation_grade_file, format: label, relation_userid, evidence(Υ������, �Ƿ�A��)
        """
        relation_grade_dict = dict()
        # feature_dict format: relation_userid, [[relation_userid, origin_userid, type]]
        for relation_userid, features in feature_dict.items():
            feature_size = len(features)
            types = [fea[2] for fea in features]
            label = get_label_by_types(types)
            origin_userids = [fea[1] for fea in features]
            evidences = [self.seed_user_dict[i] for i in origin_userids]
            relation_grade_dict[relation_userid] = [label, evidences]

        with codecs.open(relation_grade_file, 'w', encoding='gb18030') as f:
            for relation_userid, value in relation_grade_dict.items():
                label = value[0]
                evidences = value[1]
                risknames = [i[0] for i in evidences]
                riskname = risknames[0] if risknames else ''
                evidence_strs = [','.join(i) for i in evidences]
                out = [str(label), str(relation_userid), riskname,
                       "|".join(evidence_strs)]
                f.write('\t'.join(out) + '\n')
            print("save relation_grade_file to:%s, size:%d " %
                  (relation_grade_file, len(relation_grade_dict)))


def get_label_by_types(types):
    """
    ͨ���������ͻ�ȡlabel
    [IN] types : list  [����ʵ��,...]
    [OUT] label: int   ����ʵ�尴�����ȼ�ѡȡһ����ӳ�䵽label
    """
    type_label = {
        # type, label
        "client": 1,
        "device": 2,
        "ip": 3,
        "acs": 4
    }

    types = set(types)
    has_client = [i for i in types if i == "client"]
    has_device = [i for i in types if i == "device"]
    has_ip = [i for i in types if i == "ip"]
    has_acs = [i for i in types if i == "acs"]

    if has_client:
        label = type_label['client']
    elif has_device:
        label = type_label['device']
    elif has_ip:
        label = type_label['ip']
    elif has_acs:
        label = type_label['acs']
    else:
        label = 0
    return label


if __name__ == "__main__":
    """
    ��ȡ�����ּ����, label���
    """
    parser = argparse.ArgumentParser(description="get_relation_res")
    parser.add_argument("--seed_user_file", action="store", required=True,
                        help="Υ�������˻�", default="None")
    parser.add_argument("--relation_res_file", action="store", required=True,
                        help="�����������ļ�", default="None")

    args = parser.parse_args()

    seed_user_file = args.seed_user_file
    relation_res_file = args.relation_res_file

    m = UserRelation(seed_user_file)
    raw_feature_dict = m.get_relation_feature()
    feature_dict = m.process_relation_feature(raw_feature_dict)
    m.relation_grade(feature_dict, relation_res_file)
