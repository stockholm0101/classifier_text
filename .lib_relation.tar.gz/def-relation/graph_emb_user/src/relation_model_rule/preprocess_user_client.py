#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/07/23 20:01:33
Desc  :   
"""
import codecs
import re
import sys

patt = u"(^[\u4e00-\u9fa5����]{2,50}$)|(^[\u4e00-\u9fa5a-zA-Z0-9����]{3,100}$)"

if __name__ == "__main__":
    """�޳���Ч����
    """
    user_latest_6month_file = sys.argv[1]
    user_client_6month_file = sys.argv[2]

    with codecs.open(user_latest_6month_file, "r+", encoding="gb18030") as f, \
            codecs.open(user_client_6month_file, "w+", encoding="gb18030") as wf:
        for line in f:
            parts = line.strip("\n").split("\t")
            comp = parts[2]
            if not re.search(patt, comp):
                continue
            wf.write("%s\n" % ("\t".join(parts)))


