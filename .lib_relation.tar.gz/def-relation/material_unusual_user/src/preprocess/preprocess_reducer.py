#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/04/29 21:03:38
Desc  :   
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import os
import random
import json
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import conf.conf as conf

if __name__ == "__main__":
    old_key = ""
    old_unitid = ""
    info = []
    pool_size = conf.UserSampleSize
    count = 0
    for line in sys.stdin:
        parts = line.strip("\n").split("\t")
        key = parts[0]
        unitid = parts[1]
        temp_words = parts[3].split("\x02")
        
        if old_key == "" or old_key == key:
            if count < pool_size:
                info.append(parts)
            else:
                r = random.randint(0, count + 1)
                if r < pool_size:
                    info[r] = parts

        else:
            print("\t".join([old_key] + [json.dumps(info, encoding = "gb18030")]))
            info = [parts]
            count = 0

        old_key = key
        old_unitid = unitid
        count += 1

    if info:
        print("\t".join([old_key] + [json.dumps(info, encoding = "gb18030")]))

