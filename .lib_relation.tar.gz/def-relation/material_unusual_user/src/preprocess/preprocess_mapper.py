#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/04/29 21:01:42
Desc  :   
"""
import sys
reload(sys)
sys.setdefaultencoding("gb18030")

if __name__ == "__main__":
    for line in sys.stdin:
        parts = line.strip("\n").lower().decode("gb18030", "ignore").split("\t")
        userid = parts[0]
        unitid = parts[2]
        text = parts[5]
        text_seg = parts[6]
        print("\t".join([userid, unitid, text, text_seg]))


