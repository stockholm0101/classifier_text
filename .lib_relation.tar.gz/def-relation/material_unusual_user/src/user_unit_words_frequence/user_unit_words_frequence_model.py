#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/05/09 15:02:16
Desc  :   
"""
import sys
reload(sys)
sys.setdefaultencoding("gb18030")
import os
import math
import copy
import numpy as np
import json
from collections import defaultdict
import random

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object


class UserUnitWordFrequence(object):
    """�˻�top��Ƶ�ڵ�Ԫ�ڵķֲ�
    """
    def __init__(self):
        """init"""
        pass

    def init(self, stopword_file, word_segger, model_conf):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword_file: ͣ�ô��ļ�
              model_conf: ģ������
        [out] None
        """
        self.word_segger = word_segger
        self.stopword_file = stopword_file
        self.model_conf = model_conf


    def check(self, r_obj):
        """����, Ԥ��
        ���Ȼ�ȡ�˻���top��Ƶ�Ĵ�,Ȼ����Щ���ڸ���Ԫ�ķֲ��Ƿ��쳣
        [in]  r_obj: ��Ԥ��Ķ���
        [out] UserUnitEntropy  ����label��label_name���˻�top��Ƶ�Ĵʡ�top���ڸ���Ԫ�ķֲ���top�����쳣��Ԫ�ֲ���top�ʷֲ�ƽ��ֵ��top�ʷֲ���׼��
        """
        check_result_obj = review_object.UserWordFrequence()

        user_info = r_obj.text_info
        unit = {}
        for eachline in user_info:
            line = eachline
            userid = line[0]
            unitid = line[1]
            word = line[2]
            word_list = line[3].split("\x02")
            if unitid not in unit:
                unit[unitid] = []
            unit[unitid].extend(word_list)

        word_fre = {}
        for u in unit:
            for word in unit[u]:
                if word not in word_fre:
                    word_fre[word] = 0
                word_fre[word] += 1
        
        sorted_freq = sorted(word_fre.items(), key = lambda x: x[1], reverse = True)
        user_top_words = []
        index = 0
        while index < len(sorted_freq) and index < self.model_conf["top_words_frequence"]:
            user_top_words.append(sorted_freq[index][0])
            index += 1


        count = defaultdict(int)
        for u in unit:
            for word in unit[u]:
                if word in set(user_top_words):
                    count[u] += 1

        res = {}
        for u in unit:
            pro = count[u]/float(len(unit[u]))
            res[u] = pro
        
        avr = np.mean(list(res.values()))
        std = np.std(list(res.values()))

        Flag = False
        words_freq_unit_diff = {}
        evidence = {}
        evidence["unusual"] = {}
        for unitid in res:
            if res[unitid] == 0 or res[unitid] < (avr - self.model_conf["std_times"] * std):
                Flag = True
                words_freq_unit_diff[unitid] = res[unitid]
                evidence["unusual"][unitid] = [ele for ele in unit[unitid][:10]]

        if Flag:
            check_result_obj.label = "1"
            check_result_obj.label_name = u"�˻�top���ڵ�Ԫ�ֲ��쳣"
            check_result_obj.init(user_top_words, res, words_freq_unit_diff, avr, std, evidence)
            return check_result_obj.convert_to_dict()
        else:
            return None

if __name__ == "__main__":
    pass


