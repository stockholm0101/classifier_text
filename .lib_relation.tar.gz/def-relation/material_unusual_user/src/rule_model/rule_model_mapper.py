#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/04/30 10:45:20
Desc  :   
"""
import os
import sys
reload(sys)
sys.setdefaultencoding("gb18030")
import random
import re
import numpy as np
import math
import json
import argparse
parse = argparse.ArgumentParser()
parse.add_argument("--ruleFile", action = "store", dest = "RuleFile", required = True)
args = parse.parse_args()

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
sys.path.append("%s/../tools/" % _cur_dir)

import review_object.review_object as review_object
from rule_detector_relation import RuleDetector


if __name__ == "__main__":
    import word_seg
    rule_file = args.RuleFile

    segdict_path = "dict/chinese_gbk"
    stopword_file = "data/stopword.txt"
    word_segger = word_seg.WordSeg(segdict_path)
    word_segger.init_wordseg_handle()
    rule_detector = RuleDetector(word_segger,
            rule_path = rule_file)


    for line in sys.stdin:
        part = line.strip("\n").decode("gb18030", "ignore")

        res = json.loads(part)
        userid = res["userid"]
        check_result = res["check_result"]
        for model_info in check_result:
            model_id = model_info["model_id"]

            model_name = model_info["model_name"]

            model_result = model_info["model_result"]
            label_id = model_result["label"]
            label_name = model_result["label_name"]

            text = ""
            evidence = ""
            riskwords = ""
            evidence_words = model_result["evidence"]
            if model_id == 1:
                for type_word in evidence_words:
                    evidence += type_word + ":" + "|".join(evidence_words[type_word]) + "||"

                if "unusual" in evidence_words:
                    text += ",".join(evidence_words["unusual"]) + ","
                else:
                    text = evidence.replace("|", ",")

                res = rule_detector.check(userid, text, is_debug=False)
                riskwords = ",".join([x.riskword for x in res])
            elif model_id == 2:
                if "unusual" in evidence_words:
                    evidence_words = evidence_words["unusual"]
                keys = evidence_words.keys()
                use_keys = []
                for key in keys:
                    text = ",".join(evidence_words[key])
                    res = rule_detector.check(userid, text, is_debug=False)
                    if res:
                        use_keys.append(key)
                        riskwords += ",".join([x.riskword for x in res]) + "|"

                for type_word in use_keys:
                    evidence += type_word + ":" + "|".join(evidence_words[type_word]) + "||"

                unuse_keys = list(set(evidence_words.keys()) - set(use_keys))
                if len(unuse_keys) <= 2:
                    sample_unuse_keys = unuse_keys
                else:
                    sample_unuse_keys = random.sample(unuse_keys, 2)
                for type_word in sample_unuse_keys:
                    evidence += type_word + ":" + "|".join(evidence_words[type_word]) + "||"


            if riskwords:
                print("\t".join([userid, u"5", u"110203100100", u'����ضĲ��ʻ�', label_id, label_name, \
                        evidence, riskwords]).encode("gb18030", "ignore"))
                break


    word_segger.destroy_wordseg_handle()


