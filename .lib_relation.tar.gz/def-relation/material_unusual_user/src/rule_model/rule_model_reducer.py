#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/05/02 13:45:31
Desc  :   Ԥ��
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")

if __name__ == "__main__":
    for eachline in sys.stdin:
        print(eachline.strip("\n"))
