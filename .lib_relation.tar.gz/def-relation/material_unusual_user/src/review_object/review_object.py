#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/04/29 15:52:38
Desc  :   
"""
import sys
import json
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import conf.conf as conf

class UserUnitEntropy():
    """�˻��¸���Ԫ��Ϣ�طֲ�
    """
    def __init__(self):
        """init
        """
        self.label = "0"
        self.label_name = u"���쳣"
        self.user_entropy = 0
        self.units_entropy_gain = {}
        self.units_entropy_gain_diff = {}
        self.average = 0
        self.std = 0
        self.evidence = {}
        self.unusual_words = {}

    def init(self, user_entropy, units_entropy_gain, units_entropy_gain_diff, average, std, evidence, unusual_words):
        """Ĭ��ֵΪ0
        """
        self.user_entropy = user_entropy
        self.units_entropy_gain = units_entropy_gain
        self.units_entropy_gain_diff = units_entropy_gain_diff
        self.average = average
        self.std = std
        self.evidence = evidence
        self.unusual_words = unusual_words

    def init_from_dict(self, check_result):
        """��json������ʵ�����
        """
        self.user_entropy = check_result["user_entropy"]
        self.units_entropy_gain = json.loads(check_result["units_entropy_gain"])
        self.units_entropy_gain_diff = json.loads(check_result["units_entropy_gain_diff"])
        self.average = check_result["average"]
        self.std = check_result["std"]
        self.evidence = check_result["evidence"]
        self.unusual_words = check_result["unusual_words"]

    def convert_to_dict(self):
        """dumps enty to dict
        """
        check_result = {}
        check_result["label"] = self.label
        check_result["label_name"] = self.label_name
        check_result["user_entropy"] = self.user_entropy
        check_result["units_entropy_gain"] = self.units_entropy_gain
        check_result["units_entropy_gain_diff"] = self.units_entropy_gain_diff
        check_result["average"] = self.average
        check_result["std"] = self.std
        check_result["evidence"] = self.evidence
        check_result["unusual_words"] = self.unusual_words
        
        return check_result


class UserWordFrequence():
    """�˻���top���ڸ�����Ԫ�ķֲ�
    """
    def __init__(self):
        """init
        """
        self.label = "0"
        self.label_name = u"���쳣"
        self.user_top_words = []
        self.unit_top_words_frequence = {}
        self.unit_top_words_frequence_diff = {}
        self.average = 0
        self.std = 0
        self.evidence = {}

    def init(self, user_top_words, unit_top_words_frequence, unit_top_words_frequence_diff, average, std, evidence):
        """Ĭ��ֵΪ0
        """
        self.user_top_words = user_top_words
        self.unit_top_words_frequence = unit_top_words_frequence
        self.unit_top_words_frequence_diff = unit_top_words_frequence_diff
        self.average = average
        self.std = std
        self.evidence = evidence

    def init_from_dict(self, check_result):
        """��json������ʵ�����
        """
        self.label = check_result["label"]
        self.label_name = check_result["label_name"]
        self.user_top_words = check_result["user_top_words"]
        self.unit_top_words_frequence = json.loads(check_result["unit_top_words_frequence"])
        self.unit_top_words_frequence_diff = json.loads(check_result["unit_top_words_frequence_diff"])
        self.average = check_result["average"]
        self.std = check_result["std"]
        self.evidence = json.loads(check_result["evidence"])

    def convert_to_dict(self):
        """dumps enty to dict
        """
        check_result = {}
        check_result["label"] = self.label
        check_result["label_name"] = self.label_name
        check_result["user_top_words"] = self.user_top_words
        check_result["unit_top_words_frequence"] = self.unit_top_words_frequence
        check_result["unit_top_words_frequence_diff"] = self.unit_top_words_frequence_diff
        check_result["average"] = self.average
        check_result["std"] = self.std
        check_result["evidence"] = self.evidence
        
        return check_result


class ReviewUserObj(object):
    """�˻�ά����Ϣ
    """
    def __init__(self):
        """init
        """
        self.check_result = []

    def init(self, parts):
        """self init
        """
        self.userid = parts[0]
        self.text_info = json.loads(parts[1], encoding = 'unicode_escape')

    def add_result(self, model_conf, check_result):
        """����ģ�� check ���
        """
        result = {}
        result["model_id"] = model_conf["model_id"]
        result["model_name"] = model_conf["model_name"]
        result["model_result"] = check_result

        self.check_result.append(result)
    
    def conver_to_dict(self):
        """dumps object to dict
        """
        result = {}
        result["userid"] = self.userid
        result["check_result"] = self.check_result

        return result




if __name__ == "__main__":
    pass


