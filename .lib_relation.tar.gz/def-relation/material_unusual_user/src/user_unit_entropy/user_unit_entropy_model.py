#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/04/30 10:45:20
Desc  :   
"""
import os
import sys
import random
import re
import numpy as np
import math
import time

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object


class UserUnitEntropy(object):
    """ʾ��ģ��
    """
    def __init__(self):
        """init"""
        pass

    def init(self, stopword_file, word_segger, model_conf):
        """��ʼ��ģ��
        [in]  word_segger: �д�
              stopword_file: ͣ�ô��ļ�
              model_conf: ģ������
        [out] None
        """
        self.word_segger = word_segger
        self.stopword_file = stopword_file
        self.model_conf = model_conf


    def check(self, r_obj):
        """����, Ԥ��
        ��ȡ�˻�����Ϣ�������(��ֵ + n*��׼��)�ĵ�Ԫ,�Լ�top20�������
        [in]  r_obj: ��Ԥ��Ķ���
        [out] UserUnitEntropy  ���� �˻���Ϣ�ء�����Ԫ��Ϣ���桢�쳣��Ԫ��Ϣ����
                ��Ϣ����ƽ��ֵ����Ϣ�����׼�����Ԫ��ÿ���ʵĴ�Ƶ������Ԫ���������Ϣ����
        """
        check_result_obj = review_object.UserUnitEntropy()
        start_time = time.time()

        user_info = r_obj.text_info
        unit = {}
        for eachline in user_info:
            line = eachline
            userid = line[0]
            unitid = line[1]
            word = line[2]
            wordseg = line[3]
            if unitid not in unit:
                unit[unitid] = []
            unit[unitid].append([word, wordseg])

        # ɾ������С�� least_words_unit �ĵ�Ԫ
        keys = unit.keys()
        for unitid in keys:
            if len(unit[unitid]) < self.model_conf["least_words_unit"]:
                del unit[unitid]

        # �������unit_sample_size����Ԫ
        SAMPLE_UNITS = self.model_conf["unit_sample_size"]
        keys = unit.keys()
        if len(keys) > SAMPLE_UNITS:
            use_keys = set(random.sample(keys, SAMPLE_UNITS))
            for key in keys:
                if key not in use_keys:
                    del unit[key]


        sys.stderr.write("create unit[unitid]  use %s seconds \n" % (time.time() - start_time))
        sys.stderr.write("------------------------------------------------\n")

        all_words = {}
        unit_words_count = {}
        N = 0
        for uid in unit:
            for item in unit[uid]:
                words = item[1].split("\x02")
                for w in words:
                    if w not in all_words:
                        all_words[w] = {}
                        all_words[w][uid] = 0
                    elif uid not in all_words[w]:
                        all_words[w][uid] = 0
                    all_words[w][uid] += 1

                    if uid not in unit_words_count:
                        unit_words_count[uid] = 0
                    unit_words_count[uid] += 1


        sys.stderr.write("to create all_words[w][uid]  use %s seconds \n" % (time.time() - start_time))
        sys.stderr.write("------------------------------------------------\n")

        user_entropy = 0.0
        all_words_count = sum(unit_words_count.values())
        for w in all_words:
            p = (sum(all_words[w].values()) + 0.0) / all_words_count
            # �˻���Ϣ��
            user_entropy -= p * math.log(p, 2)

        sys.stderr.write("to get user_entropy  use %s seconds \n" % (time.time() - start_time))
        sys.stderr.write("------------------------------------------------\n")
        # ��Ԫ��Ϣ����
        shannon_except_unit = {}
        for e_uid in unit:
            entropy = 0.0
            e_unit_count = 0
            e_unit_count = sum(unit_words_count.values()) - unit_words_count[e_uid]

            if e_unit_count == 0:
                continue

            for w in all_words:
                e_w_count = 0
                e_w_count = sum(list(all_words[w].values())) - all_words[w].get(e_uid, 0)

                if e_w_count == 0:
                    continue
                p = (e_w_count + 0.0) / e_unit_count
                entropy -= p * math.log(p, 2)

            shannon_except_unit[e_uid] = user_entropy - entropy
        if not shannon_except_unit:
            return None

        avr = np.mean(list(shannon_except_unit.values()))
        std = np.std(list(shannon_except_unit.values()))

        Flag = False
        shannon_except_unit_diff = {}
        for unitid in shannon_except_unit:
            if shannon_except_unit[unitid] > (avr + self.model_conf["std_times"] * std):
                Flag = True
                shannon_except_unit_diff[unitid] = shannon_except_unit[unitid]

        sys.stderr.write("to res ��Ԫ��Ϣ����  use %s seconds \n" % (time.time() - start_time))
        sys.stderr.write("------------------------------------------------\n")

        if Flag:
            unusual_words = {}

            item_e = {}
            for e_uid in shannon_except_unit_diff:
                unusual_words[e_uid] = []
                e_unit_count = sum(unit_words_count.values()) - unit_words_count[e_uid]
                for item in unit[e_uid]:
                    aeu = {}
                    NNN = 0
                    words = item[1].split("\x02")
                    for w in words:
                        if w not in aeu:
                            aeu[w] = 0
                        aeu[w] += 1
                        NNN += 1

                    words_entopy_gain = 0.0
                    for w in aeu:
                        if w in all_words and  len(set(all_words[w].keys()) - set([e_uid])) > 0:
                            word_count = 0
                            word_count = sum(list(all_words[w].values()))
                            word_count_except_cur_unit = word_count - all_words[w].get(e_uid, 0)

                            p_w_old = word_count_except_cur_unit / float(e_unit_count)
                            assert p_w_old > 0, "p_w_old should > 0, but are %f" % (p_w_old)
                            p_w_old_entopy = -1 * p_w_old * math.log(p_w_old, 2)

                            p_w_new = float(word_count_except_cur_unit + aeu[w]) / (e_unit_count + NNN)
                            assert p_w_new > 0, "p_w_new should > 0, but are %f" % (p_w_new)
                            p_w_new_entopy = -1 * p_w_new * math.log(p_w_new, 2)

                            cur_word_entopy_gain = p_w_new_entopy - p_w_old_entopy
                        else:
                            p_w_new = float(aeu[w]) / (e_unit_count + NNN)
                            assert p_w_new > 0, "p_w_new should > 0, but are %f" % (p_w_new)
                            cur_word_entopy_gain = -1 * p_w_new * math.log(p_w_new, 2)

                        words_entopy_gain += cur_word_entopy_gain


                    #e = 0.0
                    #w_set = set(aeu.keys()) | set(all_words.keys())
                    #for w in w_set:
                    #    e_w_count = 0
                    #    for cur_unit in all_words.get(w, []):
                    #        if cur_unit == e_uid:
                    #            continue
                    #        e_w_count += all_words[w][cur_unit]
                    #    p_z = aeu.get(w, 0) + e_w_count + 0.0
                    #    p_m = NNN + e_unit_count
                    #    if p_z == 0 or p_m == 0:
                    #        continue
                    #    p = p_z / p_m
                    #    e -= p * math.log(p, 2)

                    item_e[item[0]] = words_entopy_gain
                item_e_sort = sorted(item_e.items(), key = lambda x: x[1], reverse = True)
                for ele in item_e_sort[:20]:
                    unusual_words[e_uid].append(ele[0])

            evidence = {}
            evidence["usual"] = []
            evidence["unusual"] = []
            keys = list(set(unit.keys()) - set(unusual_words.keys()))
            if len(keys) > 5:
                keys = random.sample(keys, 5)
            for unitid in keys:
                evidence["usual"].extend([ele[0] for ele in unit[unitid][:5]])
            for unitid in unusual_words:
                evidence["unusual"].extend(unusual_words[unitid])


            check_result_obj.init(user_entropy, shannon_except_unit, shannon_except_unit_diff, avr, std, \
                    evidence, unusual_words)
            check_result_obj.label = "1"
            check_result_obj.label_name = u"��Ԫ��Ϣ�طֲ��쳣"
        else:
            return None
        sys.stderr.write("to res �����  use %s seconds \n" % (time.time() - start_time))
        sys.stderr.write("------------------------------------------------\n")
        return check_result_obj.convert_to_dict()



if __name__ == "__main__":
    pass


