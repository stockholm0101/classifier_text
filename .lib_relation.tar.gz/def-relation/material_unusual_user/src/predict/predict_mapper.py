#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/04/29 17:12:09
Desc  :   
"""
import sys
reload(sys)
sys.setdefaultencoding("gb18030")
import os
import random
import json
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import word_seg
import conf.conf as conf
import review_object.review_object as review_object

class Predicter(object):
    """Ԥ����,���ø�ģ�ͽӿ�
    """
    def __init__(self):
        """init
        """

    def init(self, stopword_file, segdict_path):
        """��ʼ��,���ظ�ģ�Ͳ���
        [in]  stopword_file : ͣ�ô�  string
              segdict_path : �дʴʵ�  string
        [out] None
        """
        self.stopword_file = stopword_file
        self.segdict_path = segdict_path

        self.word_seg = word_seg.WordSeg(segdict_path)
        self.word_seg.init_wordseg_handle()

        self.model_obj = {}
        for k in conf.models:
            model_conf = conf.models[k]
            if not model_conf["enable"]:
                continue
            self.model_obj[k] = {}
            self.model_obj[k]["model_conf"] = model_conf
            m_module = __import__(model_conf["module_name"], fromlist = ['default'])
            m_class = getattr(m_module, model_conf["class_name"])
            m_obj = m_class()
            self.model_obj[k]["m_obj"] = m_obj

        self.init_models()

    def init_models(self):
        """��ʼ��ģ��
        """
        for k in self.model_obj:
            model_conf = self.model_obj[k]["model_conf"]
            m_obj = self.model_obj[k]["m_obj"]
            m_obj.init(self.stopword_file, self.word_seg, model_conf)

    def destroy(self):
        """�ͷ��д�
        """
        self.word_seg.destroy_wordseg_handle()


if __name__ == "__main__":
    segdict_path = "dict/chinese_gbk"
    stopword_file = "data/stopword.txt"
    p = Predicter()
    p.init(stopword_file, segdict_path)

    for line in sys.stdin:
        parts = line.strip("\n").lower().decode("gb18030", "ignore").split("\t")
        r_obj = review_object.ReviewUserObj()
        r_obj.init(parts)

        for k in p.model_obj:
            m_obj = p.model_obj[k]["m_obj"]
            check_result = m_obj.check(r_obj)
            if check_result:
                r_obj.add_result(p.model_obj[k]["model_conf"], check_result)
        if r_obj.check_result:
            result = r_obj.conver_to_dict()
            print("%d\t%s" % (random.randint(0, 100000), json.dumps(result, encoding = "gb18030")))
    p.destroy()



