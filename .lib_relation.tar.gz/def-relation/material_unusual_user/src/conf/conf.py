#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/04/29 16:43:06
Desc  :   
"""
import sys

UserSampleSize = 100000

models = {}

models[1] = {"enable": True,
        "model_id": 1,
        "model_name": u"�˻��¸���Ԫ��Ϣ�طֲ�",
        "module_name": "user_unit_entropy.user_unit_entropy_model",
        "class_name": "UserUnitEntropy",
        "std_times": 2,                                            #��׼���
        "least_words_unit": 10,
        "unit_sample_size": 5000
        }

models[2] = {"enable": True,
        "model_id": 2,
        "model_name": u"�˻�top���ڵ�Ԫ�ڳ���Ƶ�ηֲ�",
        "module_name": "user_unit_words_frequence.user_unit_words_frequence_model",
        "class_name": "UserUnitWordFrequence",
        "std_times": 2,                                            #��׼���
        "top_words_frequence": 20                                  #ѡȡ�˻���top���ٴ���Ϊ��׼
        }
