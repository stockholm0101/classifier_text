# 账户关联
关联属性
---
- 单元信息熵分布
- 乱买词
- 设备号
- IP地址
- 消费信息

目录结构
---
```
|--src:关联代码目录
|   |--***
|--bin:调度入口
|   |--***
|--test:单测目录
|   |--***
|--README.md:介绍文档
```


快速开始
---
```
cd ${root}/bin & sh run.sh
```

测试
---
```
cd ${root}/test 
```

如何贡献
---
贡献patch流程及质量要求

版本信息
---
本项目的各版本信息和变更历史可以在[这里][changelog]查看。

维护者
---
### owners
* zhubenchang(zhubenchang@baidu.com)

### committers
* zhubenchang(zhubenchang@baidu.com)

讨论
---
百度Hi交流群：群号


[changelog]: http://icode.baidu.com/repos/baidu/fengkong/def-relation/blob/master:CHANGELOG.md
